#!/usr/bin/env python3
"""Collect only explicitly linked public static assets; never execute client code."""
import concurrent.futures
import datetime
import hashlib
import html
import json
from pathlib import Path
import re
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = 'https://historique-luckyjet.shop'
ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT/'original'
META = ROOT/'metadata'
ORIGINAL.mkdir(parents=True,exist_ok=True)
META.mkdir(parents=True,exist_ok=True)
MAX_FILES, MAX_BYTES, MAX_RESPONSE = 400, 40*1024*1024, 8*1024*1024
STATIC = re.compile(r'\.(?:m?js|css|map|json|webmanifest|png|jpe?g|svg|ico|gif|webp|avif|woff2?|ttf|otf|eot)(?:[?#].*)?$', re.I)
seeds = [('initial page', BASE+'/'),('initial login',BASE+'/login'),
         ('user URL',BASE+'/~flock.js'),('user URL',BASE+'/assets/analysis-data-BaiXRb_2.js'),
         ('user URL',BASE+'/manifest.webmanifest'),('user URL GET only',BASE+'/~api/analytics')]
historical = ROOT/'original/assets'
for p in sorted(historical.glob('*')):
    if p.is_file() and STATIC.search(p.name):
        seeds.append(('historically observed public asset',BASE+'/assets/'+p.name))

pending = {}
discovered_from = {}
references = []
fetched = set()
records = []
started = time.monotonic()

def resolve(raw, parent):
    raw = html.unescape(raw).replace('\\/','/').strip()
    if not raw or raw.startswith(('data:','blob:','javascript:','#')):
        return None
    # Vite's dependency arrays contain origin-relative "assets/chunk.js" strings.
    if raw.startswith('assets/'):
        raw='/'+raw
    try:
        url=urllib.parse.urljoin(parent,raw)
        parsed=urllib.parse.urlsplit(url)
    except ValueError:
        return None
    if parsed.scheme!='https':return None
    if parsed.netloc!=urllib.parse.urlsplit(BASE).netloc:
        if raw.startswith(('http://','https://','//')):
            references.append({'parent':parent,'reference':raw,'reason':'external reference, not requested'})
        return None
    url=urllib.parse.urlunsplit((parsed.scheme,parsed.netloc,parsed.path,parsed.query,''))
    if STATIC.search(parsed.path):return url
    if any(token in parsed.path for token in ('_serverFn','~api','/api/')):
        references.append({'parent':parent,'reference':url,'reason':'backend reference, not invoked'})
    return None

def add(url,parent):
    discovered_from.setdefault(url,set()).add(parent)
    if url in fetched:return
    pending.setdefault(url,set()).add(parent)

for parent,url in seeds:add(url,parent)

def destination(url):
    path=urllib.parse.unquote(urllib.parse.urlsplit(url).path)
    if path=='/':path='/index.html'
    if path=='/login':path='/login/index.html'
    if '..' in Path(path).parts:raise ValueError('unsafe path')
    if path=='/~api/analytics':return META/'analytics-get-response.html'
    result=ORIGINAL/path.lstrip('/')
    query=urllib.parse.urlsplit(url).query
    if query:
        result=result.with_name(result.name+'.query-'+hashlib.sha256(query.encode()).hexdigest()[:12])
    return result

def get(url):
    result={'url':url,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    for attempt in range(2):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Accept':'*/*'})
            try:response=urllib.request.urlopen(req,timeout=25)
            except urllib.error.HTTPError as error:response=error
            with response:
                data=response.read(MAX_RESPONSE+1)
                result.update(status=response.status,content_type=response.headers.get('Content-Type',''),
                              final_url=response.url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
            if len(data)>MAX_RESPONSE:
                result['error']='response exceeds 8 MiB cap';return result,b''
            if result['status'] in (429,502,503,504) and attempt==0:
                time.sleep(1);continue
            return result,data
        except Exception as error:
            if attempt==0:continue
            result['error']=f'{type(error).__name__}: {error}'
            return result,b''

def discover(data,url,ctype):
    if not any(x in ctype for x in ('javascript','json','text/','xml')):return
    text=data.decode('utf-8','replace')
    candidates=[]
    # Explicit HTML attributes and CSS url() tokens.
    candidates += re.findall(r'\b(?:src|href)\s*=\s*["\']([^"\']+)["\']',text,re.I)
    candidates += re.findall(r'url\(\s*["\']?([^\s\)"\']+)',text,re.I)
    # JS import paths, dynamic imports, dependency maps, and embedded asset paths.
    candidates += re.findall(r'["\'`]((?:https?://|//|/|\./|\.\./|assets/)[^\s"\'`<>]+?\.(?:m?js|css|map|json|webmanifest|png|jpe?g|svg|ico|gif|webp|avif|woff2?|ttf|otf|eot)(?:\?[^\s"\'`<>]*)?)["\'`]',text,re.I)
    candidates += re.findall(r'sourceMappingURL\s*=\s*([^\s*]+)',text)
    # Record server function references without invoking them.
    for backend in re.findall(r'/(?:_serverFn|~api|api)/[a-zA-Z0-9_?=/&.:-]+',text):
        references.append({'parent':url,'reference':backend,'reason':'backend reference, not invoked'})
    for raw in candidates:
        resolved=resolve(raw,url)
        if resolved:add(resolved,url)

total_bytes=0
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    while pending and len(fetched)<MAX_FILES and total_bytes<MAX_BYTES:
        batch=list(pending)[:4]
        parents={url:sorted(pending.pop(url)) for url in batch}
        fetched.update(batch)
        for result,data in executor.map(get,batch):
            result['parents']=parents[result['url']]
            if data:
                target=destination(result['url'])
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(data)
                result['saved_path']=str(target.relative_to(ROOT))
                total_bytes+=len(data)
                is_html=bool(re.match(rb'\s*(?:<!doctype|<html)',data,re.I))
                expected_static=bool(STATIC.search(urllib.parse.urlsplit(result['url']).path))
                if expected_static and is_html:
                    result['error']='HTML returned for a static asset; not treated as client code'
                if result.get('status')==200 and not (expected_static and is_html):
                    discover(data,result['final_url'],result['content_type'])
            records.append(result)
        if len(records)%20<4:
            print(json.dumps({'progress':len(records),'pending':len(pending),'bytes':total_bytes}),flush=True)

summary={'started_from':[{'url':u,'provenance':p} for p,u in seeds],
         'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'requests':len(records),'bytes':total_bytes,'elapsed_seconds':round(time.monotonic()-started,2),
         'successes':sum(r.get('status')==200 and not r.get('error') for r in records),
         'failures':[{k:r.get(k) for k in ('url','status','error')} for r in records if r.get('status')!=200 or r.get('error')],
         'limits':{'max_files':MAX_FILES,'max_bytes':MAX_BYTES,'max_response':MAX_RESPONSE},
         'unfetched':list(pending)}
for record in records:
    record['parents']=sorted(discovered_from.get(record['url'],set(record.get('parents',[]))))
(META/'downloads.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
(META/'dependency-graph.json').write_text(json.dumps({r['url']:{'parents':r.get('parents',[]),'status':r.get('status'),'saved_path':r.get('saved_path')} for r in records},ensure_ascii=False,indent=2)+'\n')
(META/'references-not-invoked.json').write_text(json.dumps(references,ensure_ascii=False,indent=2)+'\n')
(META/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('started_from','unfetched')},ensure_ascii=False),flush=True)
