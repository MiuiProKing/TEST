"""Extract public client code. Never requests paid server functions or changes access checks."""
from pathlib import Path
import json
import re

root = Path(__file__).parent
assets = root / 'original/assets'
out = root / 'extracted'
out.mkdir(exist_ok=True)
premium = (assets / 'premium._game-yGdvscKg.js').read_text()
main = (assets / 'index-C5ThNCN-.js').read_text()
trajectory = premium[premium.index('function re('):premium.index('function _e(')]
(out / 'trajectory.mjs').write_text('// Exact public trajectory function, isolated from application dependencies.\n' + trajectory + '\nexport { re as spiderPose };\n')
vortex = (assets / 'vortex-scene-BPgrQS3F.js').read_text()
vortex = re.sub(r'^import.*?;const ks=', 'import { spiderPose as ma } from "./trajectory.mjs";\nconst ks=', vortex, count=1)
(out / 'vortex-local.mjs').write_text('// Original public WebGL bundle; only imports were replaced to isolate the graphics.\n' + vortex)
fallback = premium[premium.index('function _e('):premium.index('function Fe(')]
(out / 'canvas-fallback-original.js').write_text('// Original React component; references React and JSX runtime from original app.\n' + fallback)
normalizer = (assets / 'analysis-data-BaiXRb_2.js').read_text()
normalizer = normalizer[:normalizer.index('export{')]
validation = premium[premium.index('function Te('):premium.index('function Ge(')]
(out / 'signal-validation.mjs').write_text('// Exact public normalization and signal state machine. ze aliases the original normalizer.\n' + normalizer + '\nconst ze = m;\n' + validation + '\nexport { Te as bestInWindow, We as resolveWindow, De as advanceState, le as initialState };\n')
basic = (assets / 'PredictionPanel-BwmEfDz4.js').read_text()
algorithm = basic[basic.index('const l=6e4'):basic.index('function _(')]
(out / 'basic-forecast.mjs').write_text('// Exact public BASIC forecast, distinct from the VIP server model.\n' + normalizer + '\nconst Z=m, Fe=f;\n' + algorithm + '\nexport { Pe as forecastBasic };\n')
# Preserve actual full JSX layout and polling code separately from the isolated preview.
(out / 'premium-layout-original.js').write_text('// Exact public React layout; unresolved symbols are supplied by the original application.\n' + premium[premium.index('function Ee('):premium.index('function Xe(')])
start = main.index('const Vc=20')
end = main.index('const Jz=', start)
(out / 'luckyjet-feed-original.js').write_text('// Original Lucky Jet hook and deduplication; application dependencies remain in original bundle.\n' + main[start:end])
contracts = {
 'premium_url': 'https://historique-luckyjet.shop/premium/luckyjet',
 'premium_statistics': {'method': 'GET', 'path': '/_serverFn/29562702b4fe653955ae9aa27f6e70343c1cbcbe33b76ba3f05a73550d2b849c', 'input': {'game':'luckyjet'}, 'poll_ms':30000,
  'response_fields_observed_in_client':['sampleSize','fresh','dataCutoff','avgRoundSeconds','thresholds[].threshold','thresholds[].count','thresholds[].estimatedNextAt','thresholds[].probNext3MinPct','thresholds[].frequencyPct','thresholds[].avgGapMinutes'], 'server_implementation_available':False, 'endpoint_called_in_this_analysis':False},
 'ai_analysis': {'method':'POST','path':'/_serverFn/ddbd425daedaba6871a9a8a60c6c943415250e22750ffa1255ea8a5406ee7d49','input':{'game':'game name','rounds':'up to 200 past coefficient/timestamp records'},'poll_ms':45000, 'endpoint_called_in_this_analysis':False},
 'luckyjet_refresh': {'method':'GET','path':'/_serverFn/63f8aa5623bd8fe398e01ce3284f1ebb818b60544c17b7511499bd3fad0034ce','poll_ms':60000,'endpoint_called_in_this_analysis':False},
 'access': {'storage_key':'lj_access_token', 'check':'server-validated subscription token; not supplied, fabricated, or bypassed'},
 'rounds': {'table':'luckyjet_rounds','fields':['id','coefficient','color','played_at'],'initial_query_limit':40,'display_limit':20,'dedup_equal_coefficient_within_ms':12000,'live':'INSERT subscription'}
}
(root / 'contracts.json').write_text(json.dumps(contracts, ensure_ascii=False, indent=2))
print('Extracted animation, validation, basic model, layout, feed and contracts.')
