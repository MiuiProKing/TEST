// Original Lucky Jet hook and deduplication; application dependencies remain in original bundle.
const Vc = 20,
  Gz = 6e4,
  Kz = 12e3;
function r_(e, t) {
  return e.some(
    (n) =>
      n.coefficient === t.coefficient &&
      Math.abs(n.timestamp - t.timestamp) < Kz,
  );
}
function Yz() {
  const [e, t] = M.useState([]),
    [n, s] = M.useState("connecting"),
    [a, l] = M.useState(null),
    c = M.useRef(new Set()),
    f = wi(Fz);
  return (
    M.useEffect(() => {
      let d = !1;
      return (
        (async () => {
          const { data: h } = await gt
            .from("luckyjet_rounds")
            .select("id,coefficient,color,played_at")
            .order("played_at", { ascending: !1 })
            .limit(Vc * 2);
          if (d || !h) return;
          const g = [];
          for (const y of h) {
            const v = {
              id: y.id,
              coefficient: Number(y.coefficient),
              color: y.color ?? Gs(Number(y.coefficient)),
              timestamp: new Date(y.played_at).getTime(),
            };
            if (!r_(g, v) && (g.push(v), g.length >= Vc)) break;
          }
          (g.forEach((y) => c.current.add(y.id)), t(g));
        })(),
        () => {
          d = !0;
        }
      );
    }, []),
    M.useEffect(() => {
      const d = gt
        .channel(`luckyjet_rounds_rt_${Math.random().toString(36).slice(2)}`)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "luckyjet_rounds" },
          (h) => {
            const g = h.new;
            if (c.current.has(g.id)) return;
            c.current.add(g.id);
            const y = {
              id: g.id,
              coefficient: Number(g.coefficient),
              color: g.color,
              timestamp: new Date(g.played_at).getTime(),
            };
            t((v) => (r_(v, y) ? v : (l(y.id), [y, ...v].slice(0, Vc))));
          },
        )
        .subscribe();
      return () => {
        gt.removeChannel(d);
      };
    }, []),
    M.useEffect(() => {
      let d = !1,
        h;
      const g = async () => {
        try {
          const y = await f();
          if (d) return;
          s(y?.ok ? "live" : "error");
        } catch {
          d || s("error");
        } finally {
          d || (h = setTimeout(g, Gz));
        }
      };
      return (
        g(),
        () => {
          ((d = !0), clearTimeout(h));
        }
      );
    }, [f]),
    { rounds: e, status: n, newestId: a, max: Vc }
  );
}
