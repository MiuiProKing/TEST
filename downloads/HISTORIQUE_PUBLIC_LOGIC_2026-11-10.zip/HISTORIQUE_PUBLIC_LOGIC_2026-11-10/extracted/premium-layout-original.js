// Exact public React layout; unresolved symbols are supplied by the original application.
function Ee({ results: n }) {
  return e.jsx("div", {
    role: "status",
    "aria-live": "polite",
    "aria-atomic": "true",
    className:
      "pointer-events-none flex w-full max-w-md flex-col items-center gap-3 px-4 text-center",
    children: n.map((o) => {
      const i = o.status === "validated",
        u = i ? Pe : Re;
      return e.jsxs(
        "div",
        {
          className: "w-full bg-background/85 px-4 py-3 backdrop-blur-sm",
          children: [
            e.jsxs("p", {
              className: `flex items-center justify-center gap-2 text-sm font-bold ${i ? "text-neon-green" : "text-destructive"}`,
              children: [
                e.jsx(u, { className: "h-5 w-5 shrink-0" }),
                " ",
                o.target,
                "x — ",
                i ? "VALIDÉ" : "ÉCHEC",
              ],
            }),
            e.jsxs("p", {
              className: "mt-1 font-mono text-lg font-bold text-foreground",
              children: [
                i ? "Coefficient sorti" : "Meilleur coefficient",
                " : ",
                o.coefficient.toFixed(2),
                "x",
              ],
            }),
          ],
        },
        `${o.target}:${o.at}`,
      );
    }),
  });
}
function Te(n, o, i, u) {
  const l = i + u,
    a = n
      .filter(
        (s) =>
          Number.isFinite(s.coefficient) &&
          s.coefficient >= 1 &&
          Number.isFinite(s.timestamp) &&
          s.timestamp >= i &&
          s.timestamp <= l,
      )
      .reduce((s, t) => (!s || t.coefficient > s.coefficient ? t : s), null);
  return {
    reached: !!a && a.coefficient >= o,
    best: a?.coefficient ?? null,
    bestAt: a?.timestamp ?? null,
  };
}
const L = 18e4;
function We(n, o, i, u) {
  const l = ze(o, o.length, i).reverse(),
    c = Te(l, n.target, n.start, n.end - n.start);
  if (c.reached && c.best !== null && c.bestAt !== null)
    return {
      target: n.target,
      status: "validated",
      coefficient: c.best,
      at: c.bestAt,
    };
  if (i <= n.end || c.best === null) return null;
  const a = l.filter((d) => d.timestamp <= n.start).at(-1),
    s = l.find((d) => d.timestamp >= n.end);
  if (!a || !s) return null;
  const t = l.filter(
      (d) => d.timestamp >= a.timestamp && d.timestamp <= s.timestamp,
    ),
    r = Math.min(18e4, Math.max(6e4, u * 3e3));
  return !Number.isFinite(r) ||
    t.some(
      (d, f) => f > 0 && d.timestamp - (t[f - 1]?.timestamp ?? d.timestamp) > r,
    )
    ? null
    : { target: n.target, status: "failed", coefficient: c.best, at: n.end };
}
const Oe = 4e4;
function le() {
  return {
    windows: [],
    lockedWindows: [],
    lastStarts: {},
    pending: [],
    rounds: [],
    messages: [],
  };
}
function De(n, o, i, u, l, c) {
  const a = {
    ...n,
    windows: n.windows.filter((t) => i < t.end),
    lockedWindows: [...n.lockedWindows, ...n.windows.filter((t) => i >= t.end)],
    lastStarts: { ...n.lastStarts },
    pending: [...n.pending],
    messages: n.messages.filter((t) => i < t.expiresAt),
  };
  u &&
    [40, 200, 500].every((t) => a.lockedWindows.some((r) => r.target === t)) &&
    (a.lockedWindows = []);
  const s = new Map();
  for (const t of [...n.rounds, ...o])
    t.timestamp >= i - L * 3 &&
      t.timestamp <= i &&
      s.set(t.id ?? `${t.timestamp}:${t.coefficient}`, t);
  if (((a.rounds = [...s.values()]), u))
    for (const t of c) {
      const r = t.estimatedNextAt;
      if (
        r === null ||
        !Number.isFinite(r) ||
        r < i ||
        r <= (a.lastStarts[t.threshold] ?? 0) ||
        a.windows.some((f) => f.target === t.threshold) ||
        a.lockedWindows.some((f) => f.target === t.threshold)
      )
        continue;
      const d = { target: t.threshold, start: r, end: r + L };
      (a.windows.push(d), a.pending.push(d), (a.lastStarts[t.threshold] = r));
    }
  return (
    (a.pending = a.pending.filter((t) => {
      const r = We(t, a.rounds, i, l);
      return (
        r && a.messages.push({ result: r, expiresAt: i + Oe }),
        !r && i <= t.end + L
      );
    })),
    a
  );
}
function Ge(n, o) {
  const i = p.useRef(le()),
    u = p.useRef(30),
    [l, c] = p.useState(le),
    [a, s] = p.useState(0);
  return (
    p.useEffect(() => {
      s(Date.now());
      const t = setInterval(() => s(Date.now()), 1e3);
      return () => clearInterval(t);
    }, []),
    p.useEffect(() => {
      const t = Date.now(),
        r =
          !!n?.fresh &&
          n.sampleSize >= 200 &&
          n.dataCutoff !== null &&
          t - n.dataCutoff <= L &&
          !!n.avgRoundSeconds;
      (n?.avgRoundSeconds && (u.current = n.avgRoundSeconds),
        (i.current = De(i.current, o, t, r, u.current, n?.thresholds ?? [])),
        c(i.current));
    }, [n, o, a]),
    {
      results: l.messages.map((t) => t.result),
      windows: l.windows,
      lockedWindows: l.lockedWindows,
    }
  );
}
function ee(n) {
  return new Date(n).toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}
function Le({ r: n, isNew: o }) {
  const i = n.coefficient >= 10;
  return e.jsxs(Z.div, {
    initial: o ? { scale: 0.6, opacity: 0, y: -12 } : !1,
    animate: { scale: 1, opacity: 1, y: 0 },
    transition: { type: "spring", stiffness: 320, damping: 22 },
    className: `flex flex-col items-center rounded-xl border px-3 py-1.5 min-w-[64px] backdrop-blur-sm ${i ? "border-fuchsia-400/60 bg-fuchsia-400/10 shadow-[0_0_18px_rgba(217,70,239,0.35)]" : "border-purple-400/30 bg-purple-400/[0.07]"}`,
    children: [
      e.jsxs("span", {
        className: `font-mono font-black text-sm ${i ? "text-fuchsia-300" : "text-purple-200"}`,
        children: [n.coefficient.toFixed(2), "x"],
      }),
      e.jsx("span", {
        className: "text-[9px] font-mono text-white/40",
        children: ee(n.timestamp),
      }),
    ],
  });
}
function Ve({ game: n, onStats: o, windows: i, lockedWindows: u }) {
  const [l, c] = p.useState(null),
    [a, s] = p.useState(() => Date.now());
  return (
    p.useEffect(() => {
      let t = !1;
      const r = async () => {
        try {
          const f = await $e({ data: { game: n } });
          t || (c(f), o(f));
        } catch {
          t || (c(null), o(null));
        }
      };
      r();
      const d = setInterval(r, 3e4);
      return () => {
        ((t = !0), clearInterval(d));
      };
    }, [n, o]),
    p.useEffect(() => {
      const t = setInterval(() => s(Date.now()), 1e3);
      return () => clearInterval(t);
    }, []),
    !l || l.sampleSize < 200
      ? e.jsx("p", {
          className: "text-center text-[11px] text-white/40 px-4",
          children:
            "Analyse des tendances en cours… (échantillon insuffisant pour le moment)",
        })
      : e.jsx("div", {
          className: "mx-auto w-full max-w-2xl px-4",
          children: e.jsxs("div", {
            className:
              "rounded-2xl border border-purple-400/20 bg-purple-950/20 backdrop-blur-sm p-3 sm:p-4",
            children: [
              e.jsxs("p", {
                className:
                  "text-[10px] font-black uppercase tracking-[0.15em] text-purple-200/60 mb-2.5",
                children: [
                  "Grosses cotes · ",
                  l.sampleSize.toLocaleString("fr-FR"),
                  " tours analysés",
                ],
              }),
              e.jsx("div", {
                className: "grid grid-cols-3 gap-2",
                children: l.thresholds.map((t) => {
                  const r =
                      l.fresh &&
                      l.dataCutoff !== null &&
                      a - l.dataCutoff <= 18e4,
                    d = u.find((y) => y.target === t.threshold),
                    f = !d && r && (t.probNext3MinPct ?? 0) >= 50,
                    b =
                      (i.find((y) => y.target === t.threshold) ?? d)?.start ??
                      t.estimatedNextAt,
                    m = !d && r && b !== null ? b - a : null,
                    w = m !== null ? Math.max(0, Math.round(m / 1e3)) : null,
                    h =
                      w !== null
                        ? `${String(Math.floor(w / 3600)).padStart(2, "0")}:${String(Math.floor((w % 3600) / 60)).padStart(2, "0")}:${String(w % 60).padStart(2, "0")}`
                        : null;
                  return e.jsxs(
                    "div",
                    {
                      className: `rounded-xl border px-2.5 py-2 text-center ${f ? "border-fuchsia-400/60 bg-fuchsia-400/10 shadow-[0_0_16px_rgba(217,70,239,0.25)]" : "border-white/[0.08] bg-black/30"}`,
                      children: [
                        e.jsxs("p", {
                          className: `font-mono font-black text-base ${f ? "text-fuchsia-300" : "text-white/85"}`,
                          children: [t.threshold, "x+"],
                        }),
                        d &&
                          e.jsxs("p", {
                            className:
                              "mt-1 flex items-center justify-center gap-1 text-[10px] text-muted-foreground",
                            children: [
                              e.jsx(Ie, { className: "size-3" }),
                              " Verrouillé",
                            ],
                          }),
                        t.count === 0
                          ? e.jsx("p", {
                              className: "text-[9px] text-white/40 mt-1",
                              children: "Jamais vu sur l'échantillon",
                            })
                          : e.jsxs(e.Fragment, {
                              children: [
                                r &&
                                  b !== null &&
                                  e.jsx("p", {
                                    className: `text-[10px] font-mono font-bold mt-1 ${f ? "text-fuchsia-300 animate-pulse" : "text-purple-200"}`,
                                    children: `Repère médian ${ee(b)}`,
                                  }),
                                h !== null &&
                                  !f &&
                                  e.jsxs("p", {
                                    className:
                                      "text-[9px] font-mono text-white/50 mt-0.5",
                                    children: ["dans ", h],
                                  }),
                              ],
                            }),
                        e.jsxs("p", {
                          className: "text-[8px] text-white/35 mt-1",
                          children: [
                            r &&
                              t.probNext3MinPct !== null &&
                              `Modèle : ${t.probNext3MinPct.toFixed(0)}% en 3 min · `,
                            t.frequencyPct.toFixed(2),
                            "% des tours",
                            t.avgGapMinutes !== null &&
                              ` · 1×/${t.avgGapMinutes} min`,
                          ],
                        }),
                        !r &&
                          e.jsx("p", {
                            className: "text-[10px] text-muted-foreground mt-1",
                            children:
                              "Collecte ancienne — estimation suspendue",
                          }),
                      ],
                    },
                    t.threshold,
                  );
                }),
              }),
            ],
          }),
        })
  );
}
function qe({ label: n, game: o, rounds: i, status: u, newestId: l }) {
  const [c, a] = p.useState(!1),
    [s, t] = p.useState(0),
    [r, d] = p.useState(null),
    { results: f, windows: g, lockedWindows: b } = Ge(r, i);
  p.useEffect(() => {
    if (!l) return;
    t(1);
    const h = setTimeout(() => t(0), 2500);
    return () => clearTimeout(h);
  }, [l]);
  const m = i.slice(0, 5),
    w =
      u === "live"
        ? "Analyse en cours — détermination de la fenêtre"
        : u === "connecting"
          ? "Connexion au flux en direct…"
          : "Flux interrompu — nouvelle tentative…";
  return e.jsxs("div", {
    className:
      "relative min-h-screen text-white flex flex-col overflow-hidden bg-[#0a0618]",
    children: [
      e.jsxs("div", {
        className: "pointer-events-none absolute inset-0",
        "aria-hidden": "true",
        children: [
          e.jsx("div", {
            className:
              "absolute -top-32 left-1/2 -translate-x-1/2 h-96 w-[42rem] rounded-full bg-purple-600/20 blur-3xl",
          }),
          e.jsx("div", {
            className:
              "absolute bottom-0 -left-24 h-72 w-72 rounded-full bg-fuchsia-600/10 blur-3xl",
          }),
          e.jsx("div", {
            className:
              "absolute bottom-10 -right-24 h-72 w-72 rounded-full bg-blue-600/10 blur-3xl",
          }),
        ],
      }),
      e.jsx("div", {
        className: "pointer-events-none absolute inset-0 contents",
        children: e.jsx(Fe, { pulse: s }),
      }),
      e.jsxs("header", {
        className:
          "relative flex items-center justify-between px-4 sm:px-6 pt-5",
        children: [
          e.jsxs("div", {
            children: [
              e.jsxs("h1", {
                className:
                  "font-display italic font-black text-lg sm:text-2xl tracking-tight",
                children: [
                  "GOD",
                  " ",
                  e.jsx("span", {
                    className:
                      "bg-gradient-to-r from-purple-400 to-fuchsia-500 bg-clip-text text-transparent",
                    children: "PREDITOR",
                  }),
                ],
              }),
              e.jsxs("p", {
                className:
                  "text-[11px] sm:text-xs font-mono tracking-[0.25em] text-purple-200/50",
                children: ["· ", n],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsxs(ve, {
                to: "/jeux",
                className:
                  "inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.04] px-3 py-1.5 text-xs text-white/70 hover:bg-white/10 transition-colors",
                children: [e.jsx(ye, { className: "w-3.5 h-3.5" }), " Jeux"],
              }),
              e.jsxs("button", {
                type: "button",
                onClick: () => a(!0),
                className:
                  "inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.04] px-3 py-1.5 text-xs text-white/70 hover:bg-white/10 transition-colors",
                children: [
                  e.jsx(Ce, { className: "w-3.5 h-3.5" }),
                  " Historique",
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsx("div", {
        className:
          "relative flex justify-center gap-2 sm:gap-3 px-4 mt-5 flex-wrap",
        children:
          m.length === 0
            ? Array.from({ length: 5 }).map((h, y) =>
                e.jsxs(
                  "div",
                  {
                    className:
                      "rounded-xl border border-white/10 bg-white/[0.03] px-3 py-1.5 min-w-[64px] animate-pulse",
                    children: [
                      e.jsx("div", {
                        className: "h-4 w-10 bg-white/10 rounded mx-auto",
                      }),
                      e.jsx("div", {
                        className: "h-2 w-12 bg-white/5 rounded mx-auto mt-1",
                      }),
                    ],
                  },
                  y,
                ),
              )
            : m.map((h) => e.jsx(Le, { r: h, isNew: h.id === l }, h.id)),
      }),
      e.jsx("div", {
        className:
          "relative z-[35] flex flex-1 min-h-[300px] sm:min-h-[380px] items-center justify-center",
        children: e.jsx(Ee, { results: f }),
      }),
      e.jsx("div", {
        className: "relative",
        children: e.jsx(Ve, {
          game: o,
          onStats: d,
          windows: g,
          lockedWindows: b,
        }),
      }),
      e.jsxs("div", {
        className: "relative flex items-center justify-center gap-2 pb-8 pt-2",
        children: [
          e.jsxs("span", {
            className: "relative flex h-2 w-2",
            children: [
              e.jsx("span", {
                className:
                  "animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75",
              }),
              e.jsx("span", {
                className:
                  "relative inline-flex rounded-full h-2 w-2 bg-purple-400",
              }),
            ],
          }),
          e.jsx("span", { className: "text-xs text-white/60", children: w }),
        ],
      }),
      e.jsx(Ne, {
        children:
          c &&
          e.jsxs(e.Fragment, {
            children: [
              e.jsx(Z.div, {
                initial: { opacity: 0 },
                animate: { opacity: 1 },
                exit: { opacity: 0 },
                className: "fixed inset-0 bg-black/60 z-40",
                onClick: () => a(!1),
              }),
              e.jsxs(Z.aside, {
                initial: { x: "100%" },
                animate: { x: 0 },
                exit: { x: "100%" },
                transition: { type: "spring", stiffness: 300, damping: 30 },
                className:
                  "fixed right-0 top-0 bottom-0 w-full max-w-sm bg-zinc-950 border-l border-white/10 z-50 flex flex-col",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between px-4 py-3 border-b border-white/10",
                    children: [
                      e.jsx("h2", {
                        className: "font-display font-bold text-sm",
                        children: "Historique des tours",
                      }),
                      e.jsx("button", {
                        type: "button",
                        onClick: () => a(!1),
                        className:
                          "p-1.5 rounded-full hover:bg-white/10 transition-colors",
                        "aria-label": "Fermer",
                        children: e.jsx(Me, { className: "w-4 h-4" }),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex-1 overflow-y-auto p-3 space-y-1.5",
                    children: [
                      i.length === 0 &&
                        e.jsx("p", {
                          className: "text-xs text-white/40 text-center py-8",
                          children: "Aucun tour chargé pour le moment.",
                        }),
                      i.map((h) => {
                        const y = h.coefficient >= 10,
                          D = h.coefficient >= 2 && !y;
                        return e.jsxs(
                          "div",
                          {
                            className:
                              "flex items-center justify-between rounded-lg border border-white/[0.06] bg-white/[0.03] px-3 py-2",
                            children: [
                              e.jsxs("span", {
                                className: `font-mono font-bold text-sm ${y ? "text-amber-300" : D ? "text-fuchsia-300" : "text-sky-300"}`,
                                children: [h.coefficient.toFixed(2), "x"],
                              }),
                              e.jsx("span", {
                                className:
                                  "text-[10px] font-mono text-white/40",
                                children: ee(h.timestamp),
                              }),
                            ],
                          },
                          h.id,
                        );
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
      }),
    ],
  });
}
