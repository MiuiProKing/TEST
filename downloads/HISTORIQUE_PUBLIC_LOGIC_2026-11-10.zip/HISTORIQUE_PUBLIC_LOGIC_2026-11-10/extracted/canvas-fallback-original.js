// Original React component; references React and JSX runtime from original app.
function _e({ pulse: n = 0 }) {
  const o = p.useRef(null),
    i = p.useRef(null),
    u = p.useRef(n);
  return (
    (u.current = n),
    p.useEffect(() => {
      const l = o.current,
        c = i.current,
        a = l?.getContext("2d"),
        s = c?.getContext("2d");
      if (!l || !c || !a || !s) return;
      const t = getComputedStyle(l),
        r = (k) => t.getPropertyValue(`--robot-${k}`).trim(),
        d = (k, S = 1) => `rgba(${r(k)},${S})`,
        f = ["violet", "blue", "pink", "violet"].map((k) =>
          r(k).split(",").map(Number),
        ),
        g = window.matchMedia("(prefers-reduced-motion: reduce)");
      let b = 0,
        m = 0,
        w = 0,
        h = 0,
        y = 0,
        D = 0,
        V,
        q,
        $ = 0;
      const I = Math.min(2, window.devicePixelRatio || 1),
        te = () => {
          const k = l.getBoundingClientRect();
          ((b = k.width), (m = k.height));
          for (const S of [l, c]) ((S.width = b * I), (S.height = m * I));
          (a.setTransform(I, 0, 0, I, 0, 0), s.setTransform(I, 0, 0, I, 0, 0));
        };
      te();
      const se = new ResizeObserver(te);
      se.observe(l);
      const ce = Array.from({ length: 1100 }, () => ({
          theta: Math.random() * Math.PI * 2,
          phi: Math.random() * Math.PI * 2,
          speed: 0.2 + Math.random() * 0.8,
          alpha: 0.25 + Math.random() * 0.5,
        })),
        X = (k) => {
          const S = h ? Math.min((k - h) / 1e3, 0.05) : 0;
          ((h = k),
            g.matches || (y += S),
            a.clearRect(0, 0, b, m),
            s.clearRect(0, 0, b, m));
          const G = b / 2,
            H = m * 0.38,
            E = Math.min(b * 0.34, 240),
            Y = E * 0.52,
            de = 1 + u.current * 0.25;
          a.globalCompositeOperation = "lighter";
          for (const x of ce) {
            g.matches ||
              ((x.theta += S * 1.2 * x.speed * de),
              (x.phi += S * 0.24 * x.speed));
            const N = (((x.phi + y * 0.12) / (Math.PI * 2)) % 1) * f.length,
              M = Math.floor(N),
              P = N - M,
              C = f[M] ?? f[0] ?? [0, 0, 0],
              T = f[(M + 1) % f.length] ?? C,
              K = C.map((v, R) => Math.round(v + ((T[R] ?? v) - v) * P));
            ((a.strokeStyle = `rgba(${K.join(",")},${x.alpha})`),
              (a.lineWidth = 0.9),
              a.beginPath());
            for (let v = 0; v <= 5; v++) {
              const R = x.theta + v * 0.07,
                _ = (E + Y * Math.cos(R)) * Math.cos(x.phi),
                W = Y * Math.sin(R),
                F = (E + Y * Math.cos(R)) * Math.sin(x.phi),
                O = W * Math.cos(0.45) - F * Math.sin(0.45),
                A = 700 / (700 + (W * Math.sin(0.45) + F * Math.cos(0.45)));
              v
                ? a.lineTo(G + _ * A, H + O * A)
                : a.moveTo(G + _ * A, H + O * A);
            }
            a.stroke();
          }
          ((a.globalCompositeOperation = "source-over"),
            (a.strokeStyle = d("violet", 0.16)),
            a.beginPath());
          for (let x = 0; x <= 30; x++) {
            const N = (x / 30) * Math.PI * 2 + y * 0.04,
              M = G + Math.cos(N) * E * 1.5,
              P = H + Math.sin(N) * E;
            x ? a.lineTo(M, P) : a.moveTo(M, P);
          }
          a.stroke();
          const z = re(y, b, m),
            ae = re(y + 0.01, b, m),
            j = (z.size * 38) / 50,
            J = G + z.x,
            B = m / 2 - z.y,
            U = Math.atan2(-(ae.y - z.y), ae.x - z.x);
          if (V === void 0 || q === void 0) $ = U;
          else {
            const x = Math.atan2(Math.sin(U - $), Math.cos(U - $));
            (($ += x * (1 - Math.exp(-12 * S))),
              (D += Math.hypot(J - V, B - q)));
          }
          ((V = J), (q = B));
          const ie = D / (14 * z.size);
          (s.save(),
            s.translate(J, B + Math.sin(ie * Math.PI * 4) * j * 0.45),
            s.rotate($ + Math.PI / 2),
            (s.globalAlpha = z.z < 0 ? 0.45 : 1),
            (s.lineCap = "round"),
            (s.lineJoin = "round"));
          for (let x = 0; x < 8; x++) {
            const N = x < 4 ? -1 : 1,
              M = x % 4,
              P = (ie + ((M + (N > 0 ? 1 : 0)) % 2) * 0.5) % 1,
              C = P >= 0.62,
              T = C ? (P - 0.62) / 0.38 : P / 0.62,
              K = (C ? 1 - T * 2 : -1 + T * 2) * 6 * j,
              v = C ? Math.sin(T * Math.PI) : 0,
              R = N * 4.8 * j,
              _ = (M - 1.5) * 3 * j,
              W = N * (25 - v * 3) * j,
              F = (M - 1.5) * 12 * j + K,
              O = N * (14 + v * 2) * j,
              Q = _ + (M - 1.5) * 6 * j - v * 4 * j,
              A = N * (21 - v) * j,
              oe = F - 2.5 * j - v * 3 * j;
            ((s.fillStyle = d("shadow", C ? 0.15 : 0.5)),
              s.beginPath(),
              s.ellipse(W, F + v * 5 * j, 2.5 * j, 1.4 * j, 0, 0, Math.PI * 2),
              s.fill());
            const ue = () => {
              (s.beginPath(),
                s.moveTo(R, _),
                s.lineTo(O, Q),
                s.lineTo(A, oe),
                s.lineTo(W, F),
                s.stroke());
            };
            ((s.strokeStyle = d("highlight")), (s.lineWidth = 1), ue());
            for (const [me, fe] of [
              [R, _],
              [O, Q],
              [A, oe],
            ])
              ((s.strokeStyle = d("highlight")),
                s.beginPath(),
                s.arc(me, fe, 0.5 * j, 0, Math.PI * 2),
                s.stroke());
          }
          ((s.strokeStyle = d("highlight", 0.9)), (s.lineWidth = 0.8));
          for (const [x, N, M] of [
            [6, 5, 7],
            [-4, 3, 3],
          ])
            (s.beginPath(),
              s.ellipse(0, x * j, N * j, M * j, 0, 0, Math.PI * 2),
              s.stroke());
          (s.restore(), g.matches || (w = requestAnimationFrame(X)));
        },
        ne = () => {
          (cancelAnimationFrame(w), (h = 0), (w = requestAnimationFrame(X)));
        };
      return (
        g.addEventListener("change", ne),
        (w = requestAnimationFrame(X)),
        () => {
          (cancelAnimationFrame(w),
            se.disconnect(),
            g.removeEventListener("change", ne));
        }
      );
    }, []),
    e.jsxs(e.Fragment, {
      children: [
        e.jsx("canvas", {
          ref: o,
          className: "absolute inset-0 w-full h-full pointer-events-none",
          "aria-hidden": "true",
        }),
        e.jsx("canvas", {
          ref: i,
          className: "absolute inset-0 z-30 w-full h-full pointer-events-none",
          "aria-hidden": "true",
        }),
      ],
    })
  );
}
