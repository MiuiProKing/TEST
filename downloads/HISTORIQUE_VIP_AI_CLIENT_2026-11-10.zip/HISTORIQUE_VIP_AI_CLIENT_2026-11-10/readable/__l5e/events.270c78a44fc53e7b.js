(() => {
  ((
    c,
    Ye,
    Yn,
    Qn = 50,
    Pt = 50 * 1024,
    Qe = 512 * 1024,
    Ae = 100,
    Zn = 5 * 1024 * 1024,
    Ie = 50,
    jt = 600 * 1e3,
    er = 2e3,
  ) => {
    const Ft = c.__lovableEvents || {};
    if (Ft.__userAppEventsSdkVersion) return;
    const m = c.document,
      ue = c.navigator || {},
      Ut = ue.webdriver === !0 || !!c.Cypress || !!c.__nightmare,
      T = c.performance || { now: () => Date.now() },
      I = c.location || { pathname: "", href: "", search: "" },
      ee = () =>
        c.setTimeout || (typeof setTimeout == "function" ? setTimeout : null),
      fe = () =>
        c.clearTimeout ||
        (typeof clearTimeout == "function" ? clearTimeout : null),
      Ot = () => c.fetch || (typeof fetch == "function" ? fetch : null);
    if (
      ((e) => e === "/__codex_token_check" || e.startsWith("/__l5e/"))(
        I.pathname,
      )
    )
      return;
    const x = m && m.currentScript,
      Nt = x
        ? {
            kind: x.getAttribute("data-artifact-kind") || null,
            id: x.getAttribute("data-artifact-id") || null,
            commit_sha: x.getAttribute("data-commit-sha") || null,
            context_token: x.getAttribute("data-context-token") || null,
          }
        : {},
      Vt = x?.getAttribute("data-replay") || null,
      Ze = (() => {
        try {
          const e = new URL(x?.src || "").pathname,
            t = e.lastIndexOf("/__l5e/");
          return t > 0 ? e.slice(0, t) : "";
        } catch {
          return "";
        }
      })(),
      tr = x?.getAttribute("data-track-url") || `${Ze}/__l5e/trackevents`,
      nr = x?.getAttribute("data-replay-url") || `${Ze}/__l5e/replay`,
      rr =
        x?.getAttribute("data-replay-script-url") ||
        `${Ze}/__l5e/rrweb-record.js`,
      Bt = (e) => {
        const t = typeof e == "string" ? Number(e) : 0;
        return !Number.isFinite(t) || t <= 0 ? 0 : t >= 1 ? 1 : t;
      },
      et = Bt(x?.getAttribute("data-replay-sample-rate") || null),
      tt = Bt(x?.getAttribute("data-replay-crash-sample-rate") || null),
      or = x?.getAttribute("data-autocapture") === "1",
      nt = x?.getAttribute("data-consent") === "1";
    let de = null,
      rt = !1,
      Pe = !1;
    const Dt = (e) => {
        const t = new Uint8Array(e);
        if (c.crypto && typeof c.crypto.getRandomValues == "function")
          c.crypto.getRandomValues(t);
        else
          for (let n = 0; n < t.length; n++)
            t[n] = Math.floor(Math.random() * 256);
        return t;
      },
      $t = (e) =>
        Array.from(e, (t) => t.toString(16).padStart(2, "0")).join(""),
      M = () => {
        if (c.crypto && typeof c.crypto.randomUUID == "function")
          return c.crypto.randomUUID();
        const e = Dt(16);
        ((e[6] = (e[6] & 15) | 64), (e[8] = (e[8] & 63) | 128));
        const t = $t(e);
        return `${t.slice(0, 8)}-${t.slice(8, 12)}-${t.slice(12, 16)}-${t.slice(16, 20)}-${t.slice(20)}`;
      },
      ot = (e) => {
        const t = Dt(e);
        return (t.every((n) => n === 0) && (t[t.length - 1] = 1), $t(t));
      },
      zt = () => ({ traceId: ot(16), rootSpanId: ot(8) }),
      at = M();
    let lt = null,
      je = M(),
      st = 0,
      pe = zt(),
      it = 0,
      te = null;
    const qt = [1e4, 3e4, 6e4, 3e5];
    let ct = 0,
      Fe = null;
    const ar = 144e5;
    let ut = 0,
      Ue = !1;
    const Ht = 18e5;
    let ne = null,
      Oe = 0,
      Wt = 0,
      he = !1;
    const Jt = ((e) => {
        let t = 2166136261;
        for (let n = 0; n < e.length; n++)
          ((t ^= e.charCodeAt(n)), (t = Math.imul(t, 16777619)));
        return (t >>> 0) / 4294967296;
      })(at),
      q = et > 0 && Jt < et,
      lr = tt > 0 && Jt < tt,
      Gt = q || lr,
      Kt = q ? et : tt;
    let _ = null,
      j = 0,
      ft = 0,
      S = !1,
      Ne = null,
      B = 0,
      me = 0,
      ge = 0,
      ye = null,
      Y = 0,
      be = null,
      Ve = null,
      _e = !1,
      Be = !1,
      H = !1,
      D = q,
      $ = q ? "sampled" : null,
      De = null,
      $e = null,
      dt = !1;
    const R = [],
      sr = Math.max(Ae, Ae * Ie),
      ir = [
        "[data-lovable-mask]",
        "[data-sensitive]",
        "[data-private]",
        "[data-auth]",
        "[data-payment]",
        "[contenteditable]",
        "[autocomplete]",
        "[name*='email' i]",
        "[name*='phone' i]",
        "[name*='address' i]",
        "[name*='token' i]",
        "[name*='secret' i]",
      ].join(","),
      cr = [
        "canvas",
        "embed",
        "iframe",
        "object",
        "video",
        "[data-lovable-block]",
        ".rr-block",
        "[data-payment]",
        "[data-auth]",
        "[data-private]",
      ].join(","),
      ur = "[data-lovable-ignore],.rrweb-ignore",
      fr =
        "h1,h2,h3,h4,h5,h6,p,span,a,button,li,label,dt,dd,th,figcaption,small,strong,em",
      Xt = (e) => e.replace(/[^\s]/gu, "*"),
      dr = (e, t) => {
        if (
          typeof t?.tagName == "string" &&
          t.tagName.toUpperCase() === "STYLE"
        )
          return e;
        const n =
          t && typeof t.closest == "function" ? t.closest.bind(t) : null;
        return n?.("[data-lovable-unmask]")?.matches?.(fr) &&
          !n?.(`.rr-mask,${ir}`)
          ? e
          : Xt(e);
      },
      F = [],
      N = [],
      re = [],
      pr = 500;
    let pt = null;
    const Yt = 1800;
    let ht = Yt,
      ze = null;
    const oe = new Map(),
      Qt = new WeakSet(),
      Zt = new WeakSet();
    let mt = 0,
      en = 0,
      tn = !1,
      ve = null,
      ke = !1,
      nn = !1,
      rn = !1,
      Q = !1,
      on = 0,
      hr = 0;
    const gt = Math.max(1, Qn),
      mr = 5,
      gr = 200,
      yr = /^project\.[a-z][a-z0-9_]{0,63}(\.[a-z][a-z0-9_]{0,63})*$/u,
      br = (e) => {
        const t = Yn[e];
        return typeof t == "number" && t > 0 ? t : yr.test(e) ? 1 : null;
      },
      an = typeof TextEncoder == "function" ? new TextEncoder() : null,
      W = (e) => (an ? an.encode(e).length : e.length),
      ln = (e) =>
        JSON.stringify({
          envelope_schema_version: 1,
          batch_id: M(),
          sent_at: new Date().toISOString(),
          sdk: { name: "lovable-user-app-events", version: Ye },
          automated: Ut,
          artifact: Nt,
          events: e,
        }),
      sn = (e) => {
        const t = c.console;
        t &&
          typeof t.debug == "function" &&
          t.debug(`[lovable-analytics] ${e}`);
      },
      _r = (e, t) => {
        if ((e === 403 || e === 404) && t === "rejected") {
          ((ke = !0),
            (F.length = 0),
            (N.length = 0),
            (re.length = 0),
            rn ||
              ((rn = !0),
              sn(`events disabled for this page load (HTTP ${e})`)));
          return;
        }
        nn || ((nn = !0), sn(`event batch rejected (HTTP ${e})`));
      },
      cn = 64 * 1024,
      un = 16 * 1024;
    let Se = 0,
      yt = 0;
    const fn = () => {
        ((Se -= yt), (yt = 0));
      },
      dn = (e, t, n) => {
        const r = W(t),
          s = cn - (n.reserveBytes || 0),
          o = !!n.keepalive && Se + r <= s;
        o && (Se += r);
        let l = o;
        const i = () => {
            l && ((l = !1), (Se -= r));
          },
          g = c.Blob || (typeof Blob == "function" ? Blob : null);
        if (o && n.beacon && ue.sendBeacon && g)
          try {
            if (ue.sendBeacon(e, new g([t], { type: "application/json" }))) {
              ((yt += r), (l = !1));
              return;
            }
          } catch {}
        const b = Ot();
        if (!b) {
          (i(), n.onNetworkError?.());
          return;
        }
        try {
          Promise.resolve(
            b(e, {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: t,
              ...(o ? { keepalive: !0 } : {}),
            }),
          )
            .then(
              (E) => {
                (i(), n.onResponse?.(E));
              },
              () => {
                (i(), n.onNetworkError?.());
              },
            )
            .catch(() => {});
        } catch {
          (i(), n.onNetworkError?.());
        }
      },
      vr = () => {
        if (rt) return;
        rt = !0;
        const e = (n) => {
            ((de = n), (Pe = !0), (N.length > 0 || re.length > 0) && J());
          },
          t = Ot();
        if (!t) {
          Pe = !0;
          return;
        }
        try {
          Promise.resolve(t("/cdn-cgi/trace", {}))
            .then((n) => (n && n.ok ? n.text() : ""))
            .then((n) => {
              const r = typeof n == "string" ? n : "",
                s = /^h=(.+)$/m
                  .exec(r)?.[1]
                  ?.trim()
                  .toLowerCase()
                  .replace(/:\d+$/, "");
              if (!s || s !== (I.hostname || "").toLowerCase()) return e(null);
              const o = /^loc=([A-Z0-9]{2})$/m.exec(r)?.[1] ?? null;
              e(o === "XX" || o === "T1" ? null : o);
            })
            .catch(() => e(null));
        } catch {
          e(null);
        }
      },
      pn = (e, t) => {
        const n = e.filter((s) => {
          try {
            return (JSON.stringify(s), !0);
          } catch {
            return !1;
          }
        });
        let r = 0;
        for (; r < n.length;) {
          let s = n.length,
            o = ln(n.slice(r, s));
          const l = cn - Se,
            i = t && l >= un ? Math.min(Pt, l) : Pt;
          for (; s - r > 1 && W(o) > i;)
            ((s = r + Math.max(1, Math.floor((s - r) / 2))),
              (o = ln(n.slice(r, s))));
          (dn(tr, o, {
            keepalive: !0,
            beacon: t,
            onResponse: (g) => {
              !g ||
                g.ok !== !1 ||
                _r(g.status, g.headers?.get?.("x-lovable-events") ?? null);
            },
          }),
            (r = s));
        }
      },
      bt = (e, t, n) =>
        _
          ? JSON.stringify({
              envelope_schema_version: 1,
              replay_schema_version: 1,
              replay_id: _,
              chunk_id: t,
              chunk_sequence: n,
              sent_at: new Date().toISOString(),
              sdk: { name: "lovable-user-app-events", version: Ye },
              automated: Ut,
              artifact: Nt,
              session_id: at,
              page_view_id: je,
              events: e,
            })
          : null,
      kr = (e) => {
        const t = bt([e], "00000000-0000-4000-8000-000000000000", B);
        return !!t && W(t) <= Qe;
      },
      hn = (e) => {
        const t = e && typeof e == "object" ? e : null;
        return typeof t?.type == "number" ? t.type : null;
      },
      _t = () => Math.max(0, T.now() - ft),
      mn = () => {
        if (!be) return;
        const e = fe();
        (e && e(be), (be = null));
      },
      qe = () => {
        if (!Ve) return;
        const e = fe();
        (e && e(Ve), (Ve = null));
      },
      vt = () => {
        try {
          Ne?.();
        } catch {
        } finally {
          ((Ne = null), (_e = !1));
        }
      },
      Sr = (e) => {
        switch (e) {
          case "recorder_script_failed":
            return "recorder_script";
          case "recorder_start_failed":
            return "recorder_start";
          case "recorder_runtime_error":
            return "recorder_runtime";
          case "missing_full_snapshot":
          case "full_snapshot_too_large":
            return "snapshot";
          case "upload_failed":
            return "upload";
          default:
            return null;
        }
      },
      gn = (e, t, n, r, s, o) => {
        const l = Sr(t);
        l &&
          C("lovable.replay_error", {
            replay_id: e,
            reason: t,
            stage: l,
            recorder: "rrweb",
            sample_rate: Kt,
            event_count: n,
            duration_ms: r,
            chunk_count: s,
            uploaded_bytes: o,
          });
      },
      Tr = () =>
        !$ || $ === "sampled"
          ? {}
          : { capture_reason: $, trigger_event_id: De, trigger_event_name: $e },
      yn = (e, t, n, r, s, o, l) => {
        (C("lovable.session_replay", {
          replay_id: e,
          status: t,
          reason: n,
          recorder: "rrweb",
          sample_rate: Kt,
          event_count: r,
          duration_ms: s,
          chunk_count: o,
          uploaded_bytes: l,
          ...Tr(),
        }),
          gn(e, n, r, s, o, l));
      },
      kt = (e, t) => {
        _ && yn(_, e, t, j, _t(), B, Y);
      },
      St = () => D || $ === "sampled",
      Tt = (e, t, n, r, s, o, l) => {
        St() ? yn(e, t, n, r, s, o, l) : gn(e, n, r, s, o, l);
      },
      z = (e, t = !1) => {
        !_ ||
          S ||
          (vt(),
          qe(),
          t && ((R.length = 0), mn()),
          St() && kt("stopped", e),
          (S = !0));
      },
      bn = () => {
        if (!(!_ || S)) {
          if (!D) {
            (vt(), qe());
            return;
          }
          z("duration_limit", !0);
        }
      },
      _n = (e) => {
        !_ ||
          S ||
          $ === "client_error" ||
          ((D = !0),
          ($ = "client_error"),
          (De = e),
          ($e = "lovable.client_error"),
          vn());
      },
      Er = () => R.length > 0 || B > 0 || Y > 0,
      vn = () =>
        !_ || S || $ !== "client_error" || dt || !H || !Er()
          ? !1
          : ((dt = !0), kt("captured", "client_error"), ae(!0), !0),
      kn = (e) => {
        if (ge > 0) {
          ye = e;
          return;
        }
        z(e, !0);
      },
      Sn = () => {
        if ((ge--, S || ge > 0 || !ye)) return;
        const e = ye;
        ((ye = null), me > 0 ? Tn() : z(e, !0));
      },
      ae = (e = !1) => {
        if ((mn(), !(!D || !_ || R.length === 0 || !H)))
          for (; !S && R.length > 0;) {
            let t = Math.min(R.length, Ae);
            const n = M(),
              r = B;
            let s = bt(R.slice(0, t), n, r);
            for (; s && t > 1 && W(s) > Qe;)
              ((t = Math.max(1, Math.floor(t / 2))),
                (s = bt(R.slice(0, t), n, r)));
            if (!s) return;
            const o = W(s);
            if (o > Qe) {
              (R.shift(), (j = Math.max(0, j - 1)));
              continue;
            }
            const l = B - me;
            if (l >= Ie || Y + o > Zn) {
              kn(l >= Ie ? "chunk_limit" : "size_limit");
              return;
            }
            if (
              (R.splice(0, t),
              B++,
              (Y += o),
              ge++,
              dn(nr, s, {
                keepalive: e,
                reserveBytes: un,
                onResponse: (i) => {
                  const g = i?.status === 429;
                  if (
                    (g && (me++, (Y -= o), (j = Math.max(0, j - t))),
                    Sn(),
                    g || (i && i.ok !== !1))
                  )
                    return;
                  const b = i?.headers?.get?.("x-lovable-events");
                  z(
                    b === "unavailable"
                      ? "upload_unavailable"
                      : b === "rejected"
                        ? "upload_rejected"
                        : "upload_failed",
                    !0,
                  );
                },
                onNetworkError: () => {
                  (z("upload_failed", !0), Sn());
                },
              }),
              S)
            )
              return;
            if (B - me >= Ie) {
              kn("chunk_limit");
              return;
            }
          }
      },
      Tn = () => {
        if (be) return;
        const e = ee();
        if (!e) {
          ae();
          return;
        }
        be = e(ae, er);
      },
      wr = {
        "lovable.session_started": !0,
        "lovable.page_viewed": !0,
        "lovable.page_engagement": !0,
        "lovable.web_vital": !0,
        "lovable.client_error": !0,
        "lovable.resource_error": !0,
      },
      xr = (e, t) => {
        if (e == null) return 0;
        const n = (Array.isArray(e) ? e : [e]).map((r) =>
          String(r).toUpperCase(),
        );
        return de && n.includes(de)
          ? 1
          : t !== "denied"
            ? -1
            : de
              ? n.some((r) => r.startsWith(`${de}-`))
                ? 2
                : -1
              : 1;
      },
      le = () => {
        try {
          if (ue.globalPrivacyControl === !0) return "denied";
          const e = c.dataLayer;
          let t = null;
          for (let l = 0; Array.isArray(e) && l < e.length; l++) {
            const i = e[l];
            if (!i || typeof i != "object" || i[0] !== "consent") continue;
            const g = i[2],
              b = g && typeof g == "object" ? g.analytics_storage : null;
            if (!(b !== "granted" && b !== "denied")) {
              if (i[1] === "update") ((t = b), Zt.has(i) || (Zt.add(i), mt++));
              else if (i[1] === "default" && !Qt.has(i)) {
                Qt.add(i);
                const E = g?.region,
                  se =
                    E == null
                      ? ""
                      : JSON.stringify(
                          (Array.isArray(E) ? E : [E])
                            .map((G) => String(G).toUpperCase())
                            .sort(),
                        );
                (oe.delete(se),
                  oe.set(se, { region: E, value: b }),
                  oe.size > 100 && oe.delete(oe.keys().next().value));
              }
            }
          }
          if (((ze = t ?? ze), ze)) return ze;
          const n = Array.from(oe.values()),
            r = (l) => l.region !== void 0 && l.region !== null;
          n.some(r) &&
            (n.some((l) => l.value !== n[0].value) ||
              (n.every(r) && n[0].value === "denied")) &&
            vr();
          let s = null,
            o = -1;
          for (const l of n) {
            const i = xr(l.region, l.value);
            i >= 0 && i >= o && ((o = i), (s = l.value));
          }
          return s ?? (tn ? "denied" : null);
        } catch {
          return ((tn = !0), "denied");
        }
      },
      En = (e) => {
        try {
          return JSON.parse(JSON.stringify(e));
        } catch {
          return null;
        }
      },
      Et = (e) => {
        const t = e.properties;
        return t.context === void 0
          ? e
          : { ...e, properties: { ...t, context: {} } };
      },
      Mr = () => {
        if (re.length === 0) return;
        const e = le() === "denied";
        for (const t of re.splice(0)) F.push(e ? Et(t) : t);
      },
      Rr = () => {
        N.length === 0 ||
          le() === "denied" ||
          F.unshift(...N.splice(0, N.length));
      },
      wn = () => {
        ht = Yt;
      },
      xn = () => ht < 0,
      Mn = () => {
        if (pt) return;
        if (ht-- <= 0) {
          ((N.length = 0), (en = mt));
          return;
        }
        const e = ee();
        e &&
          (pt = e(() => {
            if (((pt = null), !ke)) {
              if (le() === "denied") {
                N.length > 0 && Mn();
                return;
              }
              (wn(), N.length > 0 && J());
            }
          }, 1e3));
      },
      Cr = () => {
        if (!ve) return;
        const e = fe();
        (e && e(ve), (ve = null));
      },
      J = (e = !1) => {
        if (
          (Cr(),
          re.length > 0 && (Pe || e || Q || le() !== "denied") && Mr(),
          Rr(),
          ke || F.length === 0)
        )
          return;
        if (e || Q) {
          for (; F.length > 0;) pn(F.splice(0, gt), !0);
          return;
        }
        const t = F.splice(0, gt);
        (pn(t, !1), F.length > 0 && Rn());
      },
      Rn = () => {
        if (ve || ke) return;
        const e = ee();
        if (!e) {
          J();
          return;
        }
        ve = e(J, 250);
      },
      Lr = () => {
        te === null && (te = T.now());
      },
      He = () => {
        te = null;
      },
      Te = () => {
        const e = fe();
        (Fe !== null && e && e(Fe), (Fe = null));
      },
      Ar = () => {
        if (te !== null) {
          const t = T.now();
          ((it += t - te), (te = t));
        }
        const e = Math.round(it);
        return ((it = 0), e);
      },
      Ee = (e) => {
        const t = Ar();
        if (t <= 0) return;
        ut += t;
        const n = ut >= ar;
        (n && ((Ue = !0), He(), Te()),
          C("lovable.page_engagement", {
            reason: n ? "capped" : e,
            engagement_time_ms: t,
          }));
      },
      Cn = () => {
        Te();
        const e = ee();
        if (!e) return;
        const t = qt[Math.min(ct, qt.length - 1)];
        Fe = e(() => {
          (ct++, Ee("threshold"), !Ue && Cn());
        }, t);
      },
      wt = () => {
        const e = fe();
        (ne !== null && (e && e(ne), (Oe += Math.max(0, T.now() - Wt))),
          (ne = null));
      },
      Ln = () => {
        (wt(), (Oe = 0));
      },
      An = () => {
        if (
          ne !== null ||
          !m ||
          m.visibilityState === "hidden" ||
          m.hasFocus?.() !== !1
        )
          return;
        const e = ee();
        e &&
          ((Wt = T.now()),
          (ne = e(
            () => {
              ((ne = null), (Oe = Ht), (he = !0), Ee("unfocused"), He(), Te());
            },
            Math.max(0, Ht - Oe),
          )));
      },
      we = () => {
        (m && m.visibilityState === "hidden") ||
          he ||
          Ue ||
          (Lr(), (ct = 0), Cn(), An());
      },
      In = () => (
        Ee("navigation"),
        (ut = 0),
        (Ue = !1),
        we(),
        (je = M()),
        (pe = zt()),
        (st = 0),
        je
      ),
      Ir = (e) =>
        e === "lovable.page_viewed"
          ? { trace_id: pe.traceId, span_id: pe.rootSpanId }
          : {
              trace_id: pe.traceId,
              span_id: ot(8),
              parent_span_id: pe.rootSpanId,
            },
      Pr = (e) =>
        e === "lovable.client_error" ||
        e === "lovable.resource_error" ||
        e === "lovable.replay_error",
      jr = (e, t, n = {}) => {
        if (ke) return null;
        const r = e === "lovable.client_error";
        if (Pr(e) && ++hr > gr) return (r && _n(null), null);
        const s = r && on < mr,
          o = M(),
          l = _ && !S && (D || r) ? _ : null;
        let i = {
          event_id: o,
          event_name: e,
          event_schema_version: t,
          event_time: new Date().toISOString(),
          session_id: at,
          page_view_id: je,
          ...Ir(e),
          properties: n,
        };
        l && (i.replay_id = l);
        const g = nt && (r || wr[e] !== !0) && le() === "denied";
        if (r && g) {
          if (n.context !== void 0 && rt && !Pe)
            return (re.push(En(i) ?? Et(i)), o);
          i = Et(i);
        }
        if (g && !r) {
          const b = En(i);
          return (
            xn() && mt > en && wn(),
            !b || N.length >= pr || xn() || ue.globalPrivacyControl === !0
              ? null
              : (N.push(b), Mn(), o)
          );
        }
        return (
          s ? (on++, F.unshift(i)) : F.push(i),
          r && _n(o),
          s || F.length >= gt ? J() : Rn(),
          o
        );
      },
      C = (e, t = {}) => {
        const n = typeof e == "string" ? br(e) : null;
        return n === null ? null : jr(e, n, t);
      };
    let xe = I.pathname;
    const Fr = (e, t = {}) => (
        e === "lovable.page_viewed" &&
          (In(), typeof t.url_path == "string" && (xe = t.url_path)),
        C(e, t)
      ),
      Ur =
        /(^|[^a-z0-9_.-])([a-z0-9_.-]*(token|secret|password|passwd|key)|token_hash|code|email)(=|%3d)/iu,
      xt = (e) => (Ur.test(e) ? "/" : e),
      Mt = (e) => {
        try {
          const t = new URL(e, I.href);
          return t.protocol === "http:" || t.protocol === "https:"
            ? xt(t.pathname)
            : t.pathname;
        } catch {
          return null;
        }
      },
      Pn = (e) => {
        try {
          return new URL(e, I.href).host.replace(/^www\./iu, "");
        } catch {
          return null;
        }
      },
      Or = (e) => {
        try {
          return new URL(e, I.href).protocol.replace(/:$/u, "");
        } catch {
          return null;
        }
      },
      Nr = [
        ["utm_source", "campaign_source"],
        ["utm_medium", "campaign_medium"],
        ["utm_campaign", "campaign_name"],
        ["utm_term", "campaign_term"],
        ["utm_content", "campaign_content"],
        ["utm_id", "campaign_id"],
      ],
      Vr = [
        ["gclid"],
        ["dclid"],
        ["gbraid"],
        ["wbraid"],
        ["msclkid"],
        ["ttclid"],
        ["twclid"],
        ["li_fat_id"],
        ["fbclid"],
        ["oppref"],
        ["ko_click_id"],
        ["irclickid", "im_ref"],
        ["via"],
      ],
      Br = 128,
      Dr = (e, t) => {
        const n = {};
        try {
          const r = new URLSearchParams(
            typeof e == "string" ? e.replace(/;/gu, "&") : "",
          );
          for (const [l, i] of Nr) {
            const g = r.get(l);
            if (typeof g != "string") continue;
            const b = g.trim();
            b && W(b) <= Br && (n[i] = b);
          }
          const s = (l) => {
              const i = r.get(l);
              return typeof i == "string" && i.trim() !== "";
            },
            o = Vr.filter((l) => l.some(s)).map(([l]) => l);
          if (!o.includes("via") && typeof t == "string") {
            const l = new URLSearchParams(t.slice(1)).get("via");
            typeof l == "string" && l.trim() !== "" && o.push("via");
          }
          o.length > 0 && (n.campaign_click_id_types = o);
        } catch {
          return {};
        }
        return n;
      },
      jn = (e, t) => {
        let n = e;
        for (; n && W(JSON.stringify(n)) > t;)
          n = n.slice(0, Math.floor(n.length * 0.8));
        return n;
      },
      Me = (e, t) => {
        if (typeof e != "string") return null;
        const n = e.replace(/\s+/gu, " ").trim();
        if (!n) return null;
        if (n.length <= t) return n;
        const r = Array.from(n);
        return r.length > t ? r.slice(0, t).join("") : n;
      },
      $r = 2048,
      Fn = () => Me(xt(I.pathname || "/"), $r) || "/",
      Rt = (e) => {
        const t = e && typeof e == "object" ? e : null,
          n = (o) =>
            typeof o == "string"
              ? o
              : typeof o == "number" ||
                  typeof o == "boolean" ||
                  typeof o == "bigint"
                ? String(o)
                : null,
          r = n(t?.stack),
          s = n(t?.message) || n(e) || "Unknown error";
        return {
          message: jn(s.slice(0, 2e3), 2048),
          name: n(t?.name),
          stack: r ? jn(r.slice(0, 8e3), 8192) : null,
        };
      },
      Un = 1e3,
      zr = 1e4,
      On = 10,
      We = new Map(),
      Re = [],
      Nn = (e, t) => {
        for (const [n, r] of We) t - r >= Un && We.delete(n);
        We.set(e, t);
      },
      Ct = (e, t = !0) => {
        t && In();
        const n = I.pathname,
          r = { url_path: xt(n), navigation_type: e };
        (typeof m?.referrer == "string" &&
          m.referrer &&
          ((r.referrer_host = Pn(m.referrer) ?? ""),
          (r.referrer_path = Mt(m.referrer) ?? "")),
          Object.assign(r, Dr(I.search, I.hash)),
          (xe = n),
          Nn(n, T.now()),
          C("lovable.page_viewed", r));
      },
      Lt = (e) => {
        I.pathname !== xe && Ct(e);
      },
      qr = () => {
        const e = I.pathname;
        if (e === xe) return;
        const t = T.now(),
          n = We.get(e);
        if (
          n !== void 0 &&
          t - n < Un &&
          (Re.push(t),
          Re.length > On + 1 && Re.shift(),
          Re.length > On && t - Re[0] < zr)
        ) {
          ((xe = e), Nn(e, t));
          return;
        }
        Ct("replace_state");
      },
      Vn = () => {
        const e =
          Vt === "rrweb" && Gt && c.rrweb && typeof c.rrweb.record == "function"
            ? c.rrweb.record
            : null;
        if (!(!e || _)) {
          ((_ = M()),
            (ft = T.now()),
            (S = !1),
            (B = 0),
            (me = 0),
            (ge = 0),
            (ye = null),
            (Y = 0),
            (_e = !1),
            (H = !1),
            (D = q),
            ($ = q ? "sampled" : null),
            (De = null),
            ($e = null),
            (dt = !1));
          try {
            const t = e({
              emit(r) {
                if (S || !r || typeof r != "object") return;
                if (_t() >= jt) {
                  bn();
                  return;
                }
                const s = hn(r);
                if (!kr(r)) {
                  s === 2 && !H && z("full_snapshot_too_large", !0);
                  return;
                }
                if (!(s === 3 && !H)) {
                  for (
                    s === 2 && (H = !0), j += 1, R.push(r);
                    !D && R.length > sr;
                  ) {
                    const o = R.findIndex((l) => hn(l) !== 2);
                    (R.splice(o >= 0 ? o : 0, 1), (j = Math.max(0, j - 1)));
                  }
                  vn() || (D && (R.length >= Ae ? ae() : Tn()));
                }
              },
              blockClass: "rr-block",
              blockSelector: cr,
              collectFonts: !1,
              ignoreClass: "rrweb-ignore",
              ignoreSelector: ur,
              inlineImages: !1,
              maskAllInputs: !0,
              maskInputFn: Xt,
              maskInputOptions: {
                checkbox: !1,
                color: !1,
                date: !0,
                "datetime-local": !0,
                email: !0,
                month: !0,
                number: !0,
                password: !0,
                radio: !1,
                range: !1,
                search: !0,
                select: !0,
                tel: !0,
                text: !0,
                textarea: !0,
                time: !0,
                url: !0,
                week: !0,
              },
              maskTextClass: "rr-mask",
              maskTextFn: dr,
              maskTextSelector: "*",
              recordAfter: "load",
              recordCanvas: !1,
              recordCrossOriginIframes: !1,
            });
            if (S) {
              if (typeof t == "function")
                try {
                  t();
                } catch {}
              return;
            }
            ((_e = !0), typeof t == "function" && (Ne = t));
            const n = ee();
            (n &&
              typeof e.takeFullSnapshot == "function" &&
              n(() => {
                if (!(!_ || S))
                  try {
                    e.takeFullSnapshot?.(!1);
                  } catch {}
              }, 1e3),
              n && (Ve = n(bn, jt)),
              St() && kt("started", "recorder_available"));
          } catch {
            (_ && Tt(_, "stopped", "recorder_start_failed", j, _t(), B, Y),
              (_ = null),
              (j = 0),
              (ft = 0),
              (S = !1),
              (H = !1),
              (D = q),
              ($ = q ? "sampled" : null),
              (De = null),
              ($e = null),
              (Ne = null),
              (_e = !1),
              qe());
          }
        }
      },
      Hr = () => {
        if (Vt !== "rrweb" || !Gt || _ || Be || nt) return;
        if (c.rrweb && typeof c.rrweb.record == "function") {
          Vn();
          return;
        }
        const e = m?.head;
        if (!m?.createElement || !e?.appendChild) return;
        const t = m.createElement("script");
        ((Be = !0),
          (t.async = !0),
          (t.src = rr),
          (t.onload = () => {
            if (((Be = !1), !c.rrweb || typeof c.rrweb.record != "function")) {
              Tt(M(), "stopped", "recorder_script_failed", 0, 0, 0, 0);
              return;
            }
            Vn();
          }),
          (t.onerror = () => {
            ((Be = !1),
              Tt(M(), "stopped", "recorder_script_failed", 0, 0, 0, 0));
          }),
          e.appendChild(t));
      },
      Wr = (e) => {
        if (!(!_ || S)) {
          if ((vt(), qe(), !H)) {
            z("missing_full_snapshot", !0);
            return;
          }
          (ae(!0), S || z(e));
        }
      },
      Jr = (e) => {
        if (!_ || S) return;
        const t = e && typeof e == "object" ? e : null,
          n = t?.error && typeof t.error == "object" ? t.error : null,
          r = typeof t?.filename == "string" ? t.filename : "",
          s = typeof n?.stack == "string" ? n.stack : "";
        (r.includes("/__l5e/rrweb-record") ||
          s.includes("/__l5e/rrweb-record")) &&
          z("recorder_runtime_error", !0);
      },
      Gr = (e, t) => {
        const r = {
          CLS: [0.1, 0.25],
          FCP: [1800, 3e3],
          INP: [200, 500],
          LCP: [2500, 4e3],
          TTFB: [800, 1800],
        }[e];
        return !r || t <= r[0]
          ? "good"
          : t <= r[1]
            ? "needs-improvement"
            : "poor";
      },
      Kr = (e) => (e === "CLS" ? "score" : "millisecond"),
      L = (e, t) => {
        const n = e[t];
        return typeof n == "number" && Number.isFinite(n) ? n : null;
      },
      Je = (e, t) => {
        const n = c.PerformanceObserver;
        if (!n) return !1;
        const r = n.supportedEntryTypes;
        if (Array.isArray(r) && !r.includes(e)) return !1;
        try {
          return (
            new n((o) => {
              const l = typeof o.getEntries == "function" ? o.getEntries() : [];
              for (const i of l) i && typeof i == "object" && t(i);
            }).observe(
              e === "event"
                ? { type: e, buffered: !0, durationThreshold: 40 }
                : { type: e, buffered: !0 },
            ),
            !0
          );
        } catch {
          return !1;
        }
      },
      Xr = () => {
        const e = Fn(),
          t = (f, p, k = p, w = M()) => {
            !Number.isFinite(p) ||
              p < 0 ||
              C("lovable.web_vital", {
                url_path: e,
                metric: f,
                value: p,
                unit: Kr(f),
                delta: k,
                rating: Gr(f, p),
                id: w,
                navigation_type: "initial_load",
              });
          };
        let n = !1,
          r = null,
          s = 0,
          o = 0,
          l = 1 / 0,
          i = 1 / 0,
          g = !1;
        const b = {},
          E = {},
          se = (f) => ((b[f] = b[f] || M()), b[f]),
          G = (f, p) => {
            if (E[f] === p) return;
            const k = E[f];
            ((E[f] = p), t(f, p, k === void 0 ? p : p - k, se(f)));
          },
          K = (f) =>
            (typeof T.getEntriesByType == "function"
              ? T.getEntriesByType(f)
              : []
            ).filter((p) => !!p && typeof p == "object"),
          U = K("navigation")[0] ?? null,
          ie = U ? L(U, "responseStart") : null,
          Ge = U ? L(U, "requestStart") : null,
          Ke = U ? L(U, "fetchStart") : null,
          O = Ge ?? Ke;
        ie !== null && O !== null && ie >= O && t("TTFB", ie - O);
        const V = () => {
          const f = Math.max((U ? L(U, "activationStart") : null) ?? 0, 0),
            p = K("visibility-state").find((w) => {
              const A = L(w, "startTime");
              return w.name === "hidden" && A !== null && A >= f;
            }),
            k = p
              ? L(p, "startTime")
              : m?.visibilityState === "hidden"
                ? 0
                : null;
          (k !== null && (l = Math.min(l, k)),
            Je("paint", (w) => {
              if (n || w.name !== "first-contentful-paint") return;
              const A = L(w, "startTime");
              A !== null && ((n = !0), A < l && t("FCP", Math.max(A - f, 0)));
            }),
            Je("largest-contentful-paint", (w) => {
              const A =
                L(w, "startTime") ?? L(w, "renderTime") ?? L(w, "loadTime");
              A === null || A >= l || A >= i || (r = Math.max(A - f, 0));
            }));
        };
        if (
          (m?.prerendering === !0 && typeof m.addEventListener == "function"
            ? m.addEventListener("prerenderingchange", V, { once: !0 })
            : V(),
          m && typeof m.addEventListener == "function")
        ) {
          const f = ["keydown", "click"],
            p = (k) => {
              if (
                !(!k || typeof k != "object" || k.isTrusted !== !0) &&
                ((i = Math.min(i, T.now())),
                typeof m.removeEventListener == "function")
              )
                for (const w of f) m.removeEventListener(w, p, !0);
            };
          for (const k of f) m.addEventListener(k, p, !0);
        }
        const At = Je("layout-shift", (f) => {
          if (f.hadRecentInput === !0) return;
          const p = L(f, "value");
          p !== null && (s += p);
        });
        return (
          Je("event", (f) => {
            const p = L(f, "interactionId");
            if (p === null || p <= 0) return;
            const k = L(f, "duration");
            k !== null && k > o && (o = k);
          }),
          (f = !1) => {
            g ||
              ((l = Math.min(l, T.now())),
              r !== null && G("LCP", r),
              At && G("CLS", s),
              o > 0 && G("INP", o),
              f && (g = !0));
          }
        );
      },
      Bn = (e, t) => {
        const n = c.history,
          r = n && n[e];
        !n ||
          typeof r != "function" ||
          (n[e] = function (...s) {
            const o = r.apply(this, s);
            return (t(), o);
          });
      },
      Yr = (e) => {
        const t = e && typeof e == "object" && !Array.isArray(e) ? e : {},
          n = typeof t.mechanism == "string" ? t.mechanism : "manual",
          r = typeof t.severity == "string" ? t.severity : "error";
        return {
          mechanism: [
            "manual",
            "onerror",
            "unhandledrejection",
            "react_error_boundary",
          ].includes(n)
            ? n
            : "manual",
          handled: typeof t.handled == "boolean" ? t.handled : !0,
          severity: ["error", "warning", "info"].includes(r) ? r : "error",
        };
      };
    ((c.__lovableEvents = Object.assign(Ft, {
      __userAppEventsSdkVersion: Ye,
      track: Fr,
      flush: () => J(),
      identify(e) {
        const t = e && typeof e == "object" ? e : null;
        lt = typeof t?.user_id == "string" ? t.user_id : null;
      },
      getIdentity() {
        return { app_user_id_hash_available: !!lt };
      },
      getReplay() {
        return { replay_id: _, active: !!_ && !S && _e, event_count: j };
      },
      resetIdentity() {
        lt = null;
      },
      captureException(e, t = {}, n = {}) {
        const r = Rt(e),
          s = Yr(n);
        let o = t && typeof t == "object" && !Array.isArray(t) ? t : {};
        try {
          W(JSON.stringify(o)) > 4096 && (o = {});
        } catch {
          o = {};
        }
        C("lovable.client_error", {
          occurrence_id: M(),
          ...r,
          ...s,
          context: o,
        });
      },
      startSpan(e, t = {}) {
        const n = new Date().toISOString(),
          r = T.now();
        return {
          end(s = "ok") {
            C("lovable.frontend_span", {
              name: e,
              start_time: n,
              status: s,
              duration_ms: Math.max(0, T.now() - r),
              attributes: t,
            });
          },
        };
      },
    })),
      c.addEventListener && c.addEventListener("error", Jr, !0),
      Hr(),
      nt && le());
    const Dn = Xr();
    if (
      c.addEventListener &&
      (c.addEventListener(
        "error",
        (e) => {
          const t = e && typeof e == "object" ? e : null,
            n = t?.target && typeof t.target == "object" ? t.target : null;
          let r = null;
          if (
            (n &&
              n !== c &&
              (typeof n.src == "string"
                ? (r = n.src)
                : typeof n.href == "string" && (r = n.href)),
            r !== null)
          ) {
            const o =
                typeof n?.tagName == "string"
                  ? n.tagName.toLowerCase()
                  : "unknown",
              l = Pn(r);
            C("lovable.resource_error", {
              resource_type: o,
              url_host: l || Or(r) || "unknown",
              failure_type: "load_error",
              element: o,
              url_path: l ? Mt(r) : null,
              mechanism: "resource_load",
              handled: !1,
              severity: "error",
            });
            return;
          }
          const s = Rt(t?.error || t?.message);
          C("lovable.client_error", {
            occurrence_id: M(),
            ...s,
            filename: typeof t?.filename == "string" ? Mt(t.filename) : null,
            lineno: typeof t?.lineno == "number" ? t.lineno : null,
            colno: typeof t?.colno == "number" ? t.colno : null,
            mechanism: "onerror",
            handled: !1,
            severity: "error",
          });
        },
        !0,
      ),
      c.addEventListener("unhandledrejection", (e) => {
        const n = Rt((e && typeof e == "object" ? e : null)?.reason);
        C("lovable.client_error", {
          occurrence_id: M(),
          ...n,
          mechanism: "unhandledrejection",
          handled: !1,
          severity: "error",
        });
      }),
      c.addEventListener("pagehide", () => {
        ((Q = !0),
          Dn(!0),
          Wr("pagehide"),
          Ee("pagehide"),
          He(),
          Te(),
          wt(),
          J(!0));
      }),
      c.addEventListener("blur", () => An()),
      c.addEventListener("focus", () => {
        (Ln(), he && ((he = !1), we()));
      }),
      c.addEventListener("pageshow", (e) => {
        (e && typeof e == "object" ? e.persisted : !1) === !0 &&
          ((Q = !1), fn(), Ln(), (he = !1), we());
      }),
      c.addEventListener("popstate", () => Lt("popstate")),
      c.addEventListener("hashchange", () => Lt("hashchange")),
      or)
    ) {
      const g = { select: !0, textarea: !0, input: !0 },
        b = {
          button: !0,
          a: !0,
          input: !0,
          select: !0,
          textarea: !0,
          summary: !0,
        },
        E = {
          button: !0,
          link: !0,
          menuitem: !0,
          menuitemcheckbox: !0,
          menuitemradio: !0,
          tab: !0,
          switch: !0,
          checkbox: !0,
          radio: !0,
          option: !0,
        },
        se = {
          header: !0,
          footer: !0,
          main: !0,
          nav: !0,
          aside: !0,
          section: !0,
          article: !0,
          form: !0,
        },
        G =
          typeof Symbol < "u" && typeof Symbol.for == "function"
            ? Symbol.for("__jsxSource__")
            : null,
        K = (a) =>
          a && typeof a == "object" && typeof a.tagName == "string" ? a : null,
        U = {};
      for (const a of "html body div span main header footer nav aside section article form p a button input select textarea label fieldset legend optgroup option datalist output progress meter ul ol li dl dt dd table thead tbody tfoot tr td th caption col colgroup h1 h2 h3 h4 h5 h6 br hr pre blockquote figure figcaption small strong em b i u s q cite abbr code kbd samp var mark sub sup time address details summary dialog menu picture source track canvas iframe object embed param map area img video audio template slot noscript script style link meta title base head ins del ruby rt rp bdi bdo wbr data hgroup search fencedframe svg path g circle rect line polyline polygon ellipse text textpath tspan defs use symbol clippath mask pattern lineargradient radialgradient stop filter foreignobject marker image view desc animate animatetransform animatemotion set fegaussianblur feoffset feblend fecolormatrix fecomposite feflood femerge femergenode femorphology fetile feturbulence fedropshadow fedisplacementmap".split(
        " ",
      ))
        U[a] = !0;
      const ie = {};
      for (const a of "button link menuitem menuitemcheckbox menuitemradio tab switch checkbox radio option combobox listbox textbox searchbox slider spinbutton treeitem gridcell row columnheader rowheader tooltip dialog alertdialog navigation main banner contentinfo complementary region form search article list listitem table grid tree menu menubar toolbar tabpanel tablist progressbar status alert log timer none presentation".split(
        " ",
      ))
        ie[a] = !0;
      const Ge = {};
      for (const a of "button submit reset checkbox radio text password email number tel url search date time datetime-local month week color file range hidden image".split(
        " ",
      ))
        Ge[a] = !0;
      const Ke = (a, u) =>
          a !== null && u[a.toLowerCase()] === !0 ? a.toLowerCase() : null,
        O = (a) => {
          const u = String(a.tagName).toLowerCase();
          return U[u] === !0 ? u : "x";
        },
        V = (a, u) => {
          if (typeof a.getAttribute != "function") return null;
          const h = a.getAttribute(u);
          return typeof h == "string" && h !== "" ? h : null;
        },
        At = (a, u) =>
          typeof a.getAttribute == "function" &&
          typeof a.getAttribute(u) == "string",
        f = (a) => {
          if (g[O(a)] === !0) return null;
          const u = a.childNodes;
          if (!u || typeof u.length != "number") return null;
          const h = u;
          let d = "";
          for (let v = 0; v < h.length; v++) {
            const y = h[v];
            if (
              (y &&
                y.nodeType === 3 &&
                typeof y.nodeValue == "string" &&
                (d += y.nodeValue),
              d.length > 200)
            )
              return null;
          }
          return d === "" ? null : d;
        },
        p = (a) =>
          Me(V(a, "aria-label") || V(a, "title") || V(a, "alt") || f(a), 64),
        k = (a, u, h) => {
          const d = a.children;
          if (!d || typeof d.length != "number") return "";
          const v = d;
          let y = 0,
            P = 0;
          for (let X = 0; X < v.length; X++) {
            const ce = K(v[X]);
            !ce || O(ce) !== h || (P++, ce === u && (y = P));
          }
          return y > 0 ? ":" + y : "";
        },
        w = (a) => {
          const u = [];
          let h = a;
          for (let v = 0; h && v < 32; v++) {
            const y = O(h);
            if (!y || y === "html") break;
            const P = K(h.parentElement);
            if (
              (u.unshift(P && y !== "body" ? y + k(P, h, y) : y),
              y === "body" || !P)
            )
              break;
            h = P;
          }
          if (u.length === 0) return null;
          let d = u.join(">");
          for (; d.length > 1024 && u.length > 1;)
            (u.shift(), (d = u.join(">")));
          return d.length > 1024 ? d.slice(d.length - 1024) : d;
        },
        A = (a) => {
          if (G === null) return null;
          const u = a[G];
          if (!u || typeof u != "object") return null;
          const h = u.displayName;
          return typeof h == "string" && h !== "" ? h : null;
        },
        Qr = (a) => {
          if (b[O(a)] === !0) return !0;
          const u = V(a, "role");
          return u !== null && E[u.toLowerCase()] === !0;
        },
        Zr = (a, u) => {
          const h =
            typeof a.composedPath == "function" ? a.composedPath() : null;
          if (Array.isArray(h)) {
            const y = [];
            for (const P of h) {
              if (y.length >= u) return { nodes: y, complete: !1 };
              const X = K(P);
              X && y.push(X);
            }
            return { nodes: y, complete: !0 };
          }
          const d = [];
          let v = K(a.target);
          for (; v;) {
            if (d.length >= u) return { nodes: d, complete: !1 };
            (d.push(v), (v = K(v.parentElement)));
          }
          return { nodes: d, complete: !0 };
        },
        $n = (a) => a === "mouse" || a === "touch" || a === "pen",
        eo = 2e3,
        to = 300;
      let It = "",
        zn = 0;
      const qn = (a) => (It !== "" && T.now() - zn <= a ? It : "");
      c.addEventListener(
        "pointerdown",
        (a) => {
          try {
            const u = a;
            if (u.isTrusted !== !0) return;
            const h = typeof u.pointerType == "string" ? u.pointerType : "";
            $n(h) && ((It = h), (zn = T.now()));
          } catch {}
        },
        !0,
      );
      const Hn = (a) => Math.round(a * 1e3) / 1e3,
        Ce = (a) => (typeof a == "number" && isFinite(a) ? a : null);
      c.addEventListener(
        "click",
        (a) => {
          try {
            if (!a || typeof a != "object") return;
            const u = a;
            if (u.isTrusted !== !0 || st >= 200) return;
            const h = Zr(u, 512);
            if (!h.complete) return;
            let d = null,
              v = null;
            for (let Xe = 0; Xe < h.nodes.length; Xe++) {
              const Le = h.nodes[Xe];
              if (At(Le, "data-lov-no-capture")) return;
              if (!(Xe >= 32)) {
                if (d === null) {
                  Qr(Le) && (d = Le);
                  continue;
                }
                v === null && se[O(Le)] === !0 && (v = Le);
              }
            }
            if (d === null) return;
            const y = typeof u.pointerType == "string" ? u.pointerType : "",
              P = Ce(u.detail) ?? 0,
              X = P === 0 ? qn(to) : "",
              ce = $n(y)
                ? y
                : X || (P === 0 ? "keyboard" : qn(eo) || "unknown");
            let Wn = null,
              Jn = null;
            const Gn = Ce(u.clientX),
              Kn = Ce(u.clientY),
              Z =
                typeof d.getBoundingClientRect == "function"
                  ? d.getBoundingClientRect()
                  : null;
            ce !== "keyboard" &&
              Z &&
              Gn !== null &&
              Kn !== null &&
              Z.width > 0 &&
              Z.height > 0 &&
              ((Wn = Hn(Math.min(1, Math.max(0, (Gn - Z.left) / Z.width)))),
              (Jn = Hn(Math.min(1, Math.max(0, (Kn - Z.top) / Z.height)))));
            const Xn = c;
            (C("lovable.element_clicked", {
              url_path: Fn(),
              element_tag: O(d),
              interaction_type: ce,
              element_role: Ke(V(d, "role"), ie),
              element_type: Ke(V(d, "type"), Ge),
              element_label: p(d),
              element_path: w(d),
              component_name: Me(A(d), 64),
              section_tag: v ? Me(O(v), 64) : null,
              section_label: v ? Me(V(v, "aria-label"), 64) : null,
              offset_x: Wn,
              offset_y: Jn,
              viewport_width: Ce(Xn.innerWidth),
              viewport_height: Ce(Xn.innerHeight),
            }),
              st++);
          } catch {}
        },
        !0,
      );
    }
    (m &&
      typeof m.addEventListener == "function" &&
      m.addEventListener("visibilitychange", () => {
        if (m.visibilityState === "hidden") {
          ((Q = !0),
            Dn(),
            ae(!0),
            Ee("hidden"),
            He(),
            Te(),
            wt(),
            J(!0),
            (Q = !1));
          return;
        }
        ((Q = !1), fn(), we());
      }),
      Bn("pushState", () => Lt("push_state")),
      Bn("replaceState", qr),
      C("lovable.session_started", { reason: "new_session" }),
      Ct("initial_load", !1),
      we());
  })(
    window,
    "0.3.0-automated-flag",
    {
      "lovable.webmcp_tool_invoked": 1,
      "lovable.session_started": 1,
      "lovable.page_viewed": 1,
      "lovable.client_error": 1,
      "lovable.frontend_span": 1,
      "lovable.interaction": 1,
      "lovable.element_clicked": 1,
      "lovable.form_submitted": 1,
      "lovable.resource_error": 1,
      "lovable.session_replay": 1,
      "lovable.replay_error": 1,
      "lovable.web_vital": 1,
      "lovable.page_engagement": 1,
    },
    50,
    51200,
  );
})();
