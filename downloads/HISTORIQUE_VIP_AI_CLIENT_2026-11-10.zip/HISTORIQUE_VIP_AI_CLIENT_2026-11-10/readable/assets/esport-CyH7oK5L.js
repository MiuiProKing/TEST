import { j as t } from "./index-C5ThNCN-.js";
import { D as e, G as s } from "./DashboardLayout-XCzqIJrp.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const n = () =>
  t.jsx(e, {
    children: t.jsxs("div", {
      className:
        "rounded-3xl border border-white/[0.08] bg-white/[0.03] p-8 text-center",
      children: [
        t.jsx(s, { className: "mx-auto mb-3 text-[#E040FB]", size: 40 }),
        t.jsx("h1", {
          className: "font-display text-2xl font-black",
          children: "E-sport",
        }),
        t.jsx("p", {
          className: "mt-2 text-sm text-white/60",
          children:
            "Les jeux E-sport ne sont pas encore disponibles. Bientôt sur GOD PREDITOR.",
        }),
      ],
    }),
  });
export { n as component };
