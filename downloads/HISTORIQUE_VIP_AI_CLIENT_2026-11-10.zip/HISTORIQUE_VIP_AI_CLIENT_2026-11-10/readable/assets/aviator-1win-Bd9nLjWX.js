import {
  d as N,
  e as y,
  r,
  f as E,
  J as p,
  M as v,
  j as e,
  A as S,
} from "./index-C5ThNCN-.js";
import { R as A } from "./RoundCard-CZ-rEJ_D.js";
import { P as R, S as I } from "./PredictionPanel-BwmEfDz4.js";
import { A as M } from "./AiPredictionPanel-B3Hc_8UW.js";
import { D as L } from "./DashboardLayout-XCzqIJrp.js";
import "./analysis-data-BaiXRb_2.js";
import "./triangle-alert-CzDFXfJ_.js";
import "./database-80brKRBJ.js";
import "./trending-up-B5K2KKMW.js";
import "./activity-D198U5P3.js";
import "./button-4JeZmZFi.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const P = N({ method: "GET" }).handler(
    y("7b9af2ff8667bb4eb0f9e5b00accf900caac692397ced83bc667f89e10371510"),
  ),
  g = 20,
  T = 6e3,
  W = 3e4;
function C(o) {
  return o
    ? o === "session_1win_expiree_ou_bloquee"
      ? "Session 1Win expirée ou accès Spribe bloqué"
      : o
    : null;
}
function D() {
  const [o, u] = r.useState([]),
    [l, a] = r.useState("connecting"),
    [f, d] = r.useState(null),
    [m, h] = r.useState(!1),
    [w, j] = r.useState(null),
    x = r.useRef(new Set()),
    b = E(P);
  return (
    r.useEffect(() => {
      let n = !1;
      return (
        (async () => {
          const { data: c } = await p
            .from("aviator_1win_rounds")
            .select("id,coefficient,color,played_at")
            .order("played_at", { ascending: !1 })
            .limit(g);
          if (n || !c) return;
          const t = c.map((s) => ({
            id: s.id,
            coefficient: Number(s.coefficient),
            color: v(Number(s.coefficient)),
            timestamp: new Date(s.played_at).getTime(),
          }));
          (t.forEach((s) => x.current.add(s.id)), u(t));
        })(),
        () => {
          n = !0;
        }
      );
    }, []),
    r.useEffect(() => {
      const n = p
        .channel(
          `aviator_1win_rounds_rt_${Math.random().toString(36).slice(2)}`,
        )
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "aviator_1win_rounds" },
          (c) => {
            const t = c.new;
            if (x.current.has(t.id)) return;
            x.current.add(t.id);
            const s = {
              id: t.id,
              coefficient: Number(t.coefficient),
              color: v(Number(t.coefficient)),
              timestamp: new Date(t.played_at).getTime(),
            };
            (j(s.id), u((i) => [s, ...i].slice(0, g)));
          },
        )
        .subscribe();
      return () => {
        p.removeChannel(n);
      };
    }, []),
    r.useEffect(() => {
      let n = !1,
        c;
      const t = async () => {
        let s = T;
        try {
          const i = await b();
          if (n) return;
          if (i?.ok) (a("live"), d(null), h(!!i.waiting));
          else {
            const _ = i?.error ? String(i.error) : null;
            (a("error"),
              d(C(_) ?? "unknown"),
              _ === "session_1win_expiree_ou_bloquee" && (s = W));
          }
        } catch (i) {
          n || (a("error"), d(i.message));
        } finally {
          n || (c = setTimeout(t, s));
        }
      };
      return (
        t(),
        () => {
          ((n = !0), clearTimeout(c));
        }
      );
    }, [b]),
    { rounds: o, status: l, waiting: m, newestId: w, errorMsg: f, max: g }
  );
}
const k =
    "/__l5e/assets-v1/d31cbcbc-8f61-4d88-9c80-d38676f33266/aviator-1win-logo.png",
  O = "/__l5e/assets-v1/52d46183-a69c-41f5-ab32-72c8336e53bb/1win-logo.png";
function Z() {
  const [o, u] = r.useState(!1);
  r.useEffect(() => {
    (localStorage.setItem("lj_current_game", "aviator-1win"), u(!0));
  }, []);
  const { rounds: l, status: a, newestId: f, errorMsg: d } = D();
  return e.jsxs(L, {
    children: [
      e.jsxs("div", {
        className:
          "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between flex-wrap gap-3 relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "absolute inset-0 bg-gradient-to-r from-red-600/10 via-transparent to-blue-500/10 pointer-events-none",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-3 min-w-0 relative",
            children: [
              e.jsx("img", {
                src: k,
                alt: "Aviator 1Win",
                className:
                  "shrink-0 w-11 h-11 rounded-xl object-cover shadow-[0_0_20px_rgba(239,68,68,0.4)]",
              }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 flex-wrap",
                    children: [
                      e.jsx("h1", {
                        className:
                          "font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight bg-gradient-to-r from-red-400 via-[var(--neon-orange)] to-yellow-400 bg-clip-text text-transparent",
                        children: "Aviator",
                      }),
                      e.jsx("span", {
                        className:
                          "text-muted-foreground font-light text-lg sm:text-xl",
                        children: "×",
                      }),
                      e.jsx("div", {
                        className:
                          "inline-flex items-center px-2.5 py-1 rounded-lg bg-gradient-to-br from-blue-600 to-blue-800 shadow-[0_0_18px_rgba(37,99,235,0.5)] border border-blue-400/30",
                        children: e.jsx("img", {
                          src: O,
                          alt: "1Win",
                          className: "h-5 sm:h-6 w-auto object-contain",
                        }),
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    children: "Historique des 20 derniers tours en temps réel",
                  }),
                ],
              }),
            ],
          }),
          o &&
            e.jsxs("div", {
              className: "flex items-center gap-2 text-xs font-mono",
              children: [
                e.jsx("span", {
                  className: `w-2 h-2 rounded-full animate-pulse ${a === "live" ? "bg-[var(--neon-green)]" : a === "error" ? "bg-[var(--neon-orange)]" : "bg-[var(--neon-blue)]"}`,
                }),
                e.jsx("span", {
                  className: "text-muted-foreground",
                  children:
                    a === "live"
                      ? "LIVE"
                      : a === "error"
                        ? `Erreur API${d ? ` : ${d}` : ""}`
                        : "Connexion…",
                }),
              ],
            }),
        ],
      }),
      e.jsx(M, { rounds: l, game: "aviator" }),
      e.jsx(R, { rounds: l, table: "aviator_1win_rounds" }),
      e.jsx(I, { rounds: l }),
      e.jsxs("div", {
        className: "glass rounded-2xl p-3 sm:p-5",
        children: [
          e.jsxs("div", {
            className: "flex items-center justify-between mb-3",
            children: [
              e.jsx("h2", {
                className: "font-display font-bold text-base sm:text-lg",
                children: "20 derniers tours",
              }),
              e.jsx("span", {
                className: "text-[10px] font-mono text-muted-foreground",
                children: "temps réel",
              }),
            ],
          }),
          e.jsx("div", {
            className: "grid grid-cols-5 sm:grid-cols-10 gap-1.5 sm:gap-2",
            children: e.jsx(S, {
              initial: !1,
              children: l.map((m) =>
                e.jsx(A, { round: m, isNew: m.id === f }, m.id),
              ),
            }),
          }),
        ],
      }),
    ],
  });
}
export { Z as component };
