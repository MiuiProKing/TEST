import {
  d as N,
  e as w,
  r,
  f as _,
  J as x,
  M as g,
  j as e,
  A as y,
} from "./index-C5ThNCN-.js";
import { R as S } from "./RoundCard-CZ-rEJ_D.js";
import { P as E, S as I } from "./PredictionPanel-BwmEfDz4.js";
import { D as A } from "./DashboardLayout-XCzqIJrp.js";
import "./analysis-data-BaiXRb_2.js";
import "./triangle-alert-CzDFXfJ_.js";
import "./database-80brKRBJ.js";
import "./trending-up-B5K2KKMW.js";
import "./activity-D198U5P3.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const R = N({ method: "GET" }).handler(
    w("4b1565e78d4cd89934b7a64b09b5de464a40560dd907f765d3e6a5092b2c6a25"),
  ),
  p = 20;
function M() {
  const [i, d] = r.useState([]),
    [c, n] = r.useState("connecting"),
    [u, m] = r.useState(null),
    [l, b] = r.useState(!1),
    [v, h] = r.useState(null),
    f = r.useRef(new Set());
  return (
    _(R),
    r.useEffect(() => {
      let a = !1;
      return (
        (async () => {
          const { data: o } = await x
            .from("aviator_rounds")
            .select("id,coefficient,color,played_at")
            .order("played_at", { ascending: !1 })
            .limit(p);
          if (a || !o) return;
          const s = o.map((t) => ({
            id: t.id,
            coefficient: Number(t.coefficient),
            color: g(Number(t.coefficient)),
            timestamp: new Date(t.played_at).getTime(),
          }));
          (s.forEach((t) => f.current.add(t.id)), d(s));
        })(),
        () => {
          a = !0;
        }
      );
    }, []),
    r.useEffect(() => {
      const a = x
        .channel(`aviator_rounds_rt_${Math.random().toString(36).slice(2)}`)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "aviator_rounds" },
          (o) => {
            const s = o.new;
            if (f.current.has(s.id)) return;
            f.current.add(s.id);
            const t = {
              id: s.id,
              coefficient: Number(s.coefficient),
              color: g(Number(s.coefficient)),
              timestamp: new Date(s.played_at).getTime(),
            };
            (h(t.id), d((j) => [t, ...j].slice(0, p)));
          },
        )
        .subscribe();
      return () => {
        x.removeChannel(a);
      };
    }, []),
    r.useEffect(() => {
      const a = () => {
        const s = i[0]?.timestamp ?? 0;
        if (!s) return;
        const t = Date.now() - s < 3 * 6e4;
        (n(t ? "live" : "error"), m(t ? null : "données en attente"), b(!t));
      };
      a();
      const o = setInterval(a, 1e4);
      return () => clearInterval(o);
    }, [i]),
    { rounds: i, status: c, waiting: l, newestId: v, errorMsg: u, max: p }
  );
}
const P =
  "/__l5e/assets-v1/2501fd19-7197-43ba-9f04-83c9e4c74b64/betclic-aviator.png";
function J() {
  const [i, d] = r.useState(!1);
  r.useEffect(() => {
    (localStorage.setItem("lj_current_game", "aviator"), d(!0));
  }, []);
  const { rounds: c, status: n, newestId: u, errorMsg: m } = M();
  return e.jsxs(A, {
    children: [
      e.jsxs("div", {
        className:
          "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between flex-wrap gap-3 relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "absolute inset-0 bg-gradient-to-r from-red-600/10 via-transparent to-orange-500/10 pointer-events-none",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-3 min-w-0 relative",
            children: [
              e.jsx("img", {
                src: P,
                alt: "Aviator",
                className:
                  "shrink-0 w-11 h-11 rounded-xl object-cover shadow-[0_0_20px_rgba(239,68,68,0.4)]",
              }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 flex-wrap",
                    children: [
                      e.jsx("h1", {
                        className:
                          "font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight bg-gradient-to-r from-red-400 via-[var(--neon-orange)] to-yellow-400 bg-clip-text text-transparent",
                        children: "Aviator",
                      }),
                      e.jsx("span", {
                        className:
                          "text-muted-foreground font-light text-lg sm:text-xl",
                        children: "×",
                      }),
                      e.jsx("div", {
                        className:
                          "inline-flex items-center px-2.5 py-1 rounded-lg bg-gradient-to-br from-red-600 to-red-800 shadow-[0_0_18px_rgba(220,38,38,0.5)] border border-red-400/30",
                        children: e.jsx("img", {
                          src: "/__l5e/assets-v1/82f6e81d-ae8c-475c-a3da-bbe18750b285/betclic-logo-new.png",
                          alt: "Betclic",
                          className: "h-5 sm:h-6 w-auto object-contain",
                        }),
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    children: "Historique des 20 derniers tours en temps réel",
                  }),
                ],
              }),
            ],
          }),
          i &&
            e.jsxs("div", {
              className: "flex items-center gap-2 text-xs font-mono",
              children: [
                e.jsx("span", {
                  className: `w-2 h-2 rounded-full animate-pulse ${n === "live" ? "bg-[var(--neon-green)]" : n === "error" ? "bg-[var(--neon-orange)]" : "bg-[var(--neon-blue)]"}`,
                }),
                e.jsx("span", {
                  className: "text-muted-foreground",
                  children:
                    n === "live"
                      ? "LIVE"
                      : n === "error"
                        ? `Erreur API${m ? ` : ${m}` : ""}`
                        : "Connexion…",
                }),
              ],
            }),
        ],
      }),
      e.jsx(E, { rounds: c, table: "aviator_rounds" }),
      e.jsx(I, { rounds: c }),
      e.jsxs("div", {
        className: "glass rounded-2xl p-3 sm:p-5",
        children: [
          e.jsxs("div", {
            className: "flex items-center justify-between mb-3",
            children: [
              e.jsx("h2", {
                className: "font-display font-bold text-base sm:text-lg",
                children: "20 derniers tours",
              }),
              e.jsx("span", {
                className: "text-[10px] font-mono text-muted-foreground",
                children: "temps réel",
              }),
            ],
          }),
          e.jsx("div", {
            className: "grid grid-cols-5 sm:grid-cols-10 gap-1.5 sm:gap-2",
            children: e.jsx(y, {
              initial: !1,
              children: c.map((l) =>
                e.jsx(S, { round: l, isNew: l.id === u }, l.id),
              ),
            }),
          }),
        ],
      }),
    ],
  });
}
export { J as component };
