import {
  c as d,
  j as e,
  g as B,
  m as o,
  r as n,
  Z as L,
  N as D,
  J as j,
  S as I,
} from "./index-C5ThNCN-.js";
import { Z as O, T as q, c as T } from "./god-character.png.asset-BWFGzeh1.js";
import { L as E } from "./lock-DtZN1438.js";
import { R as z, P as V } from "./rocket-B4-ZWi-5.js";
import { E as $ } from "./eye--TeH1aRg.js";
import { A as U } from "./arrow-right-vdV6jsVn.js";
import { A as G } from "./activity-D198U5P3.js";
const H = [
    ["circle", { cx: "11", cy: "13", r: "9", key: "hd149" }],
    [
      "path",
      {
        d: "M14.35 4.65 16.3 2.7a2.41 2.41 0 0 1 3.4 0l1.6 1.6a2.4 2.4 0 0 1 0 3.4l-1.95 1.95",
        key: "jp4j1b",
      },
    ],
    ["path", { d: "m22 2-1.5 1.5", key: "ay92ug" }],
  ],
  J = d("bomb", H);
const Z = [
    ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
    ["path", { d: "M18 17V9", key: "2bz60n" }],
    ["path", { d: "M13 17V5", key: "1frdt8" }],
    ["path", { d: "M8 17v-3", key: "17ska0" }],
  ],
  W = d("chart-column", Z);
const X = [
    ["path", { d: "M13.744 17.736a6 6 0 1 1-7.48-7.48", key: "bq4yh3" }],
    ["path", { d: "M15 6h1v4", key: "11y1tn" }],
    ["path", { d: "m6.134 14.768.866-.5 2 3.464", key: "17snzx" }],
    ["circle", { cx: "16", cy: "8", r: "6", key: "14bfc9" }],
  ],
  K = d("coins", X);
const Q = [
    [
      "path",
      {
        d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
        key: "ct8e1f",
      },
    ],
    ["path", { d: "M14.084 14.158a3 3 0 0 1-4.242-4.242", key: "151rxh" }],
    [
      "path",
      {
        d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
        key: "13bj9a",
      },
    ],
    ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ],
  Y = d("eye-off", Q);
const ee = [
    ["path", { d: "M10.5 3 8 9l4 13 4-13-2.5-6", key: "b3dvk1" }],
    [
      "path",
      {
        d: "M17 3a2 2 0 0 1 1.6.8l3 4a2 2 0 0 1 .013 2.382l-7.99 10.986a2 2 0 0 1-3.247 0l-7.99-10.986A2 2 0 0 1 2.4 7.8l2.998-3.997A2 2 0 0 1 7 3z",
        key: "7w4byz",
      },
    ],
    ["path", { d: "M2 9h20", key: "16fsjt" }],
  ],
  te = d("gem", ee);
const se = [
    ["path", { d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7", key: "132q7q" }],
    [
      "rect",
      { x: "2", y: "4", width: "20", height: "16", rx: "2", key: "izxlao" },
    ],
  ],
  ae = d("mail", se);
const ie = [
    ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
    ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }],
  ],
  k = d("user", ie),
  re = [
    { icon: B, title: "Sécurisé", desc: "Vos données sont protégées" },
    { icon: O, title: "Rapide", desc: "Prédictions en temps réel" },
    { icon: q, title: "Performant", desc: "Analyses précises" },
    { icon: E, title: "Fiable", desc: "100% sécurisé" },
  ];
function oe({ form: s, hero: a }) {
  return e.jsxs("div", {
    className:
      "relative min-h-screen w-full overflow-hidden bg-[#090B18] text-white",
    children: [
      e.jsxs("div", {
        className: "pointer-events-none absolute inset-0",
        children: [
          e.jsx("div", {
            className:
              "absolute -top-40 -left-40 h-[500px] w-[500px] rounded-full bg-[#3D5AFE]/20 blur-[160px]",
          }),
          e.jsx("div", {
            className:
              "absolute -bottom-40 -right-40 h-[600px] w-[600px] rounded-full bg-[#7B2FFF]/25 blur-[180px]",
          }),
        ],
      }),
      e.jsxs("div", {
        className:
          "relative grid min-h-screen grid-cols-1 md:grid-cols-2 lg:grid-cols-[40%_60%]",
        children: [
          e.jsx("section", {
            className: "flex items-center justify-center px-4 py-10 sm:px-8",
            children: s,
          }),
          e.jsx("section", {
            className: "relative hidden md:block",
            children: e.jsx("div", {
              className:
                "absolute inset-0 rounded-l-[40px] border-l border-white/5 bg-gradient-to-br from-[#0F0F2A] via-[#0B0B22] to-[#090B18]",
              children: a,
            }),
          }),
        ],
      }),
      e.jsx("div", {
        className:
          "relative z-10 border-t border-white/5 bg-[#090B18]/70 px-4 py-4 backdrop-blur-xl sm:px-8",
        children: e.jsxs("div", {
          className:
            "mx-auto grid max-w-[1400px] grid-cols-2 items-center gap-4 sm:grid-cols-[1fr_auto] sm:gap-6",
          children: [
            e.jsx("div", {
              className:
                "col-span-2 grid grid-cols-2 gap-3 sm:col-span-1 sm:grid-cols-4 sm:gap-4",
              children: re.map((r, p) =>
                e.jsxs(
                  o.div,
                  {
                    initial: { opacity: 0, y: 8 },
                    animate: { opacity: 1, y: 0 },
                    transition: { delay: 0.1 + p * 0.06, duration: 0.35 },
                    className: "flex items-center gap-2.5",
                    children: [
                      e.jsx("span", {
                        className:
                          "grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#3D5AFE]/20 to-[#7B2FFF]/20 text-[#E040FB]",
                        children: e.jsx(r.icon, { size: 16 }),
                      }),
                      e.jsxs("div", {
                        className: "min-w-0",
                        children: [
                          e.jsx("p", {
                            className: "truncate text-xs font-bold text-white",
                            children: r.title,
                          }),
                          e.jsx("p", {
                            className: "truncate text-[10px] text-[#9CA3AF]",
                            children: r.desc,
                          }),
                        ],
                      }),
                    ],
                  },
                  r.title,
                ),
              ),
            }),
            e.jsxs(o.a, {
              href: "#",
              whileHover: {
                y: -2,
                boxShadow: "0 12px 40px -8px rgba(123,47,255,0.6)",
              },
              whileTap: { scale: 0.98 },
              className:
                "col-span-2 flex h-11 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#3D5AFE] via-[#7B2FFF] to-[#E040FB] px-6 text-sm font-semibold text-white shadow-lg shadow-[#7B2FFF]/30 sm:col-span-1",
              children: [e.jsx(z, { size: 16 }), "Commencer maintenant"],
            }),
          ],
        }),
      }),
    ],
  });
}
function ne() {
  const [s, a] = n.useState(!1),
    [r, p] = n.useState("login"),
    [y, C] = n.useState(""),
    [v, S] = n.useState(""),
    [h, _] = n.useState(""),
    [x, P] = n.useState(""),
    [f, w] = n.useState(!1),
    [F, u] = n.useState(null),
    [N, b] = n.useState(null),
    A = L();
  function M(i) {
    const t = (i || "").toLowerCase();
    return t
      ? t.includes("invalid login") || t.includes("invalid credentials")
        ? "Email ou mot de passe incorrect."
        : t.includes("email not confirmed")
          ? "Email non confirmé."
          : t.includes("already registered") ||
              t.includes("already exists") ||
              t.includes("user already")
            ? "Un compte existe déjà avec cet email."
            : t.includes("pwned") ||
                t.includes("compromised") ||
                t.includes("weak password") ||
                t.includes("has been found") ||
                t.includes("data breach")
              ? "Ce mot de passe est trop courant ou a été compromis lors d'une fuite de données. Choisissez un mot de passe plus fort (mélangez lettres, chiffres et symboles)."
              : t.includes("password should be at least") ||
                  t.includes("password is too short") ||
                  t.includes("at least 8")
                ? "Le mot de passe doit contenir au moins 8 caractères."
                : t.includes("unable to validate email") ||
                    t.includes("invalid email") ||
                    t.includes("invalid format")
                  ? "Adresse email invalide."
                  : t.includes("rate limit") || t.includes("too many")
                    ? "Trop de tentatives. Réessayez dans quelques minutes."
                    : t.includes("network") || t.includes("failed to fetch")
                      ? "Problème de connexion. Vérifiez votre réseau."
                      : t.includes("signup") && t.includes("disabled")
                        ? "Les inscriptions sont temporairement désactivées."
                        : t.includes("user not found")
                          ? "Aucun compte trouvé avec cet email."
                          : `Erreur : ${i}`
      : "Une erreur est survenue. Veuillez réessayer.";
  }
  async function R(i) {
    if ((i.preventDefault(), !f)) {
      if (x.length < 8) {
        u("Le mot de passe doit contenir au moins 8 caractères.");
        return;
      }
      (w(!0), u(null), b(null));
      try {
        if (r === "register") {
          const { error: t } = await j.auth.signUp({
            email: h,
            password: x,
            options: {
              emailRedirectTo: `${window.location.origin}/dashboard`,
              data: { first_name: y, last_name: v },
            },
          });
          if (t) throw t;
          const { data: g } = await j.auth.getSession();
          g.session
            ? A({ to: "/dashboard" })
            : b("Vérifiez votre email pour confirmer votre compte.");
        } else {
          const { error: t } = await j.auth.signInWithPassword({
            email: h,
            password: x,
          });
          if (t) throw t;
          A({ to: "/dashboard" });
        }
      } catch (t) {
        const g = t instanceof Error ? t.message : "";
        u(M(g));
      } finally {
        w(!1);
      }
    }
  }
  const l = r === "register";
  return e.jsxs(o.div, {
    initial: { opacity: 0, y: 16 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5, ease: "easeOut" },
    className:
      "relative w-full max-w-md rounded-[28px] border border-white/10 bg-white/[0.03] p-7 sm:p-9 shadow-[0_20px_60px_-20px_rgba(123,47,255,0.35)]",
    style: { backdropFilter: "blur(18px)" },
    children: [
      e.jsxs("div", {
        className: "mb-8 flex items-center gap-1",
        children: [
          e.jsx("span", {
            className:
              "font-display text-2xl font-black italic tracking-tight text-white",
            children: "GOD",
          }),
          e.jsx("span", {
            className:
              "font-display text-2xl font-black italic tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
            children: "PREDITOR",
          }),
        ],
      }),
      e.jsx("h1", {
        className:
          "font-display text-[28px] font-bold leading-tight text-white",
        children: l ? "Créer un compte" : "Bienvenue de retour !",
      }),
      e.jsx("p", {
        className: "mt-1.5 text-sm text-[#9CA3AF]",
        children: l
          ? "Inscrivez-vous pour débloquer vos prédictions"
          : "Connectez-vous à votre compte pour continuer",
      }),
      e.jsxs("form", {
        className: "mt-7 space-y-5",
        onSubmit: R,
        children: [
          l &&
            e.jsxs("div", {
              className: "grid grid-cols-2 gap-3",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx("label", {
                      className: "mb-2 block text-xs font-medium text-white/80",
                      children: "Prénom",
                    }),
                    e.jsxs("div", {
                      className: "relative",
                      children: [
                        e.jsx(k, {
                          className:
                            "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#9CA3AF]",
                          size: 16,
                        }),
                        e.jsx("input", {
                          type: "text",
                          required: !0,
                          value: y,
                          onChange: (i) => C(i.target.value),
                          placeholder: "Votre prénom",
                          className:
                            "h-12 w-full rounded-2xl border border-white/10 bg-white/[0.03] pl-11 pr-4 text-sm text-white placeholder:text-[#9CA3AF]/70 outline-none transition-all duration-300 focus:border-[#7B2FFF] focus:bg-white/[0.06] focus:ring-2 focus:ring-[#7B2FFF]/30",
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx("label", {
                      className: "mb-2 block text-xs font-medium text-white/80",
                      children: "Nom",
                    }),
                    e.jsxs("div", {
                      className: "relative",
                      children: [
                        e.jsx(k, {
                          className:
                            "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#9CA3AF]",
                          size: 16,
                        }),
                        e.jsx("input", {
                          type: "text",
                          required: !0,
                          value: v,
                          onChange: (i) => S(i.target.value),
                          placeholder: "Votre nom",
                          className:
                            "h-12 w-full rounded-2xl border border-white/10 bg-white/[0.03] pl-11 pr-4 text-sm text-white placeholder:text-[#9CA3AF]/70 outline-none transition-all duration-300 focus:border-[#7B2FFF] focus:bg-white/[0.06] focus:ring-2 focus:ring-[#7B2FFF]/30",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
          e.jsxs("div", {
            children: [
              e.jsx("label", {
                className: "mb-2 block text-xs font-medium text-white/80",
                children: "Email",
              }),
              e.jsxs("div", {
                className: "relative",
                children: [
                  e.jsx(ae, {
                    className:
                      "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#9CA3AF]",
                    size: 16,
                  }),
                  e.jsx("input", {
                    type: "email",
                    required: !0,
                    value: h,
                    onChange: (i) => _(i.target.value),
                    placeholder: "Entrez votre email",
                    className:
                      "h-12 w-full rounded-2xl border border-white/10 bg-white/[0.03] pl-11 pr-4 text-sm text-white placeholder:text-[#9CA3AF]/70 outline-none transition-all duration-300 focus:border-[#7B2FFF] focus:bg-white/[0.06] focus:ring-2 focus:ring-[#7B2FFF]/30",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx("label", {
                className: "mb-2 block text-xs font-medium text-white/80",
                children: "Mot de passe",
              }),
              e.jsxs("div", {
                className: "relative",
                children: [
                  e.jsx(E, {
                    className:
                      "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#9CA3AF]",
                    size: 16,
                  }),
                  e.jsx("input", {
                    type: s ? "text" : "password",
                    required: !0,
                    minLength: 8,
                    value: x,
                    onChange: (i) => P(i.target.value),
                    placeholder: "Entrez votre mot de passe",
                    className:
                      "h-12 w-full rounded-2xl border border-white/10 bg-white/[0.03] pl-11 pr-11 text-sm text-white placeholder:text-[#9CA3AF]/70 outline-none transition-all duration-300 focus:border-[#7B2FFF] focus:bg-white/[0.06] focus:ring-2 focus:ring-[#7B2FFF]/30",
                  }),
                  e.jsx("button", {
                    type: "button",
                    onClick: () => a((i) => !i),
                    className:
                      "absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-[#9CA3AF] transition-colors hover:text-white",
                    "aria-label": "Afficher/masquer mot de passe",
                    children: s
                      ? e.jsx(Y, { size: 16 })
                      : e.jsx($, { size: 16 }),
                  }),
                ],
              }),
            ],
          }),
          !l &&
            e.jsx("div", {
              className: "flex justify-end text-xs",
              children: e.jsx("a", {
                href: "#",
                className:
                  "font-medium text-[#E040FB] transition-colors hover:text-white",
                children: "Mot de passe oublié ?",
              }),
            }),
          F &&
            e.jsx("p", {
              className: "text-center text-xs text-[#ff6b81]",
              children: F,
            }),
          N &&
            e.jsx("p", {
              className: "text-center text-xs text-[#7dd3fc]",
              children: N,
            }),
          e.jsx(o.button, {
            whileHover: {
              y: -2,
              boxShadow: "0 12px 40px -8px rgba(123,47,255,0.6)",
            },
            whileTap: { scale: 0.98 },
            type: "submit",
            disabled: f,
            className:
              "group relative flex h-12 w-full items-center justify-center gap-2 overflow-hidden rounded-2xl bg-gradient-to-r from-[#3D5AFE] via-[#7B2FFF] to-[#E040FB] text-sm font-semibold text-white shadow-lg shadow-[#7B2FFF]/30 transition-all duration-300 disabled:opacity-60",
            children: f
              ? e.jsx(D, { size: 16, className: "animate-spin" })
              : e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("span", {
                      children: l ? "Créer mon compte" : "Se connecter",
                    }),
                    e.jsx(U, {
                      size: 16,
                      className:
                        "transition-transform duration-300 group-hover:translate-x-1",
                    }),
                  ],
                }),
          }),
        ],
      }),
      e.jsxs("p", {
        className: "mt-7 text-center text-sm text-[#9CA3AF]",
        children: [
          l ? "Vous avez déjà un compte ?" : "Vous n'avez pas de compte ?",
          e.jsx("br", {}),
          e.jsx("button", {
            type: "button",
            onClick: () => {
              (u(null), b(null), p(l ? "login" : "register"));
            },
            className:
              "mt-1 font-semibold text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] hover:from-[#E040FB] hover:to-[#7B2FFF]",
            children: l ? "Se connecter" : "S'inscrire maintenant",
          }),
        ],
      }),
    ],
  });
}
const le = [
  {
    icon: G,
    title: "Analyse en temps réel",
    desc: "Données actualisées à chaque seconde",
  },
  { icon: I, title: "Prédictions avancées", desc: "Algorithmes intelligents" },
  { icon: W, title: "Statistiques", desc: "Visualisez vos performances" },
  { icon: B, title: "Sécurité", desc: "Plateforme fiable et sécurisée" },
];
function de() {
  return e.jsx("div", {
    className: "grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4",
    children: le.map((s, a) =>
      e.jsxs(
        o.div,
        {
          initial: { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          transition: { delay: 0.3 + a * 0.08, duration: 0.4 },
          whileHover: {
            y: -4,
            boxShadow: "0 10px 40px -10px rgba(123,47,255,0.6)",
          },
          className:
            "rounded-2xl border border-white/10 bg-white/[0.04] p-3.5 backdrop-blur-xl transition-colors hover:border-[#7B2FFF]/40",
          children: [
            e.jsx("div", {
              className:
                "mb-2 inline-flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#3D5AFE]/25 to-[#7B2FFF]/25 text-[#E040FB]",
              children: e.jsx(s.icon, { size: 16 }),
            }),
            e.jsx("p", {
              className:
                "text-xs font-bold uppercase tracking-wider text-white",
              children: s.title,
            }),
            e.jsx("p", {
              className: "mt-1 text-[11px] leading-snug text-[#9CA3AF]",
              children: s.desc,
            }),
          ],
        },
        s.title,
      ),
    ),
  });
}
function ce() {
  return e.jsxs("div", {
    className:
      "relative flex h-full w-full flex-col justify-between overflow-hidden p-8 lg:p-12",
    children: [
      e.jsxs("div", {
        className: "pointer-events-none absolute inset-0 -z-10",
        children: [
          e.jsx("div", {
            className:
              "absolute -top-32 left-1/4 h-96 w-96 rounded-full bg-[#7B2FFF]/30 blur-[120px]",
          }),
          e.jsx("div", {
            className:
              "absolute bottom-0 right-0 h-[500px] w-[500px] rounded-full bg-[#3D5AFE]/25 blur-[140px]",
          }),
          e.jsx("div", {
            className:
              "absolute top-1/2 left-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#E040FB]/20 blur-[100px]",
          }),
          Array.from({ length: 30 }).map((s, a) =>
            e.jsx(
              o.span,
              {
                className: "absolute h-1 w-1 rounded-full bg-white/60",
                style: {
                  top: `${(a * 37) % 100}%`,
                  left: `${(a * 53) % 100}%`,
                },
                animate: { opacity: [0.2, 1, 0.2], scale: [1, 1.6, 1] },
                transition: {
                  duration: 3 + (a % 4),
                  repeat: 1 / 0,
                  delay: a * 0.15,
                },
              },
              a,
            ),
          ),
        ],
      }),
      e.jsxs(o.div, {
        initial: { opacity: 0, y: -20 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.6 },
        className: "text-center",
        children: [
          e.jsxs("h2", {
            className:
              "font-display text-5xl font-black italic tracking-tight lg:text-7xl",
            children: [
              e.jsx("span", { className: "text-white", children: "GOD " }),
              e.jsx("span", {
                className:
                  "text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                children: "PREDITOR",
              }),
            ],
          }),
          e.jsx("p", {
            className: "mt-3 text-base text-white/80 lg:text-lg",
            children: "L'intelligence au service de vos prédictions",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "relative flex flex-1 items-center justify-center py-6",
        children: [
          e.jsx(o.div, {
            initial: { opacity: 0, x: -40 },
            animate: { opacity: 1, x: 0, y: [0, -10, 0] },
            transition: {
              opacity: { duration: 0.6, delay: 0.2 },
              x: { duration: 0.6, delay: 0.2 },
              y: { duration: 4, repeat: 1 / 0, ease: "easeInOut" },
            },
            className:
              "absolute left-2 top-1/2 -translate-y-1/2 -rotate-[8deg] lg:left-8",
            children: e.jsx(xe, {}),
          }),
          e.jsx(o.div, {
            initial: { opacity: 0, scale: 0.85 },
            animate: { opacity: 1, scale: 1, rotate: [-3, 3, -3] },
            transition: {
              opacity: { duration: 0.6, delay: 0.3 },
              scale: { duration: 0.6, delay: 0.3 },
              rotate: { duration: 6, repeat: 1 / 0, ease: "easeInOut" },
            },
            className: "relative z-10",
            children: e.jsx(me, {}),
          }),
          e.jsx(o.div, {
            initial: { opacity: 0, x: 40 },
            animate: { opacity: 1, x: 0, y: [0, 10, 0] },
            transition: {
              opacity: { duration: 0.6, delay: 0.2 },
              x: { duration: 0.6, delay: 0.2 },
              y: { duration: 4.5, repeat: 1 / 0, ease: "easeInOut" },
            },
            className:
              "absolute right-2 top-1/2 -translate-y-1/2 rotate-[8deg] lg:right-8",
            children: e.jsx(ue, {}),
          }),
          [
            { top: "10%", left: "20%", d: 0, s: 22 },
            { top: "20%", right: "18%", d: 0.5, s: 18 },
            { bottom: "18%", left: "12%", d: 1, s: 20 },
            { bottom: "10%", right: "25%", d: 1.5, s: 16 },
          ].map((s, a) =>
            e.jsx(
              o.div,
              {
                className: "absolute text-[#E040FB]",
                style: {
                  top: s.top,
                  left: s.left,
                  right: s.right,
                  bottom: s.bottom,
                },
                animate: { y: [0, -14, 0], rotate: [0, 360] },
                transition: {
                  y: {
                    duration: 3 + a * 0.4,
                    repeat: 1 / 0,
                    ease: "easeInOut",
                    delay: s.d,
                  },
                  rotate: { duration: 8 + a, repeat: 1 / 0, ease: "linear" },
                },
                children: e.jsx("div", {
                  className:
                    "flex items-center justify-center rounded-full bg-gradient-to-br from-[#E040FB] to-[#7B2FFF] p-1.5 shadow-lg shadow-[#7B2FFF]/40",
                  children: e.jsx(K, { size: s.s, className: "text-white" }),
                }),
              },
              a,
            ),
          ),
        ],
      }),
      e.jsx(de, {}),
    ],
  });
}
function xe() {
  return e.jsxs("div", {
    className:
      "relative h-72 w-40 rounded-[28px] border border-white/15 bg-gradient-to-br from-[#141433] to-[#0B0B22] p-3 shadow-2xl shadow-[#7B2FFF]/30 lg:h-80 lg:w-44",
    children: [
      e.jsx("div", {
        className: "mx-auto mb-2 h-1 w-10 rounded-full bg-white/20",
      }),
      e.jsxs("div", {
        className:
          "rounded-2xl bg-gradient-to-br from-[#7B2FFF]/20 to-[#3D5AFE]/10 p-3 text-center",
        children: [
          e.jsx("p", {
            className: "text-[9px] font-bold text-white/80",
            children: "BONUS EXCLUSIF",
          }),
          e.jsx("p", {
            className: "mt-1 font-display text-xl font-black text-white",
            children: "+500%",
          }),
          e.jsx("p", {
            className: "text-[8px] text-[#9CA3AF]",
            children: "SUR VOTRE 1er DÉPÔT",
          }),
          e.jsx("div", {
            className:
              "mt-2 rounded-lg bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] px-2 py-1 text-[9px] font-semibold text-white",
            children: "Profiter du bonus",
          }),
        ],
      }),
      e.jsx("p", {
        className: "mt-3 text-[9px] font-bold uppercase text-white/70",
        children: "Top Jeux",
      }),
      e.jsxs("div", {
        className: "mt-2 grid grid-cols-2 gap-1.5",
        children: [
          e.jsx(m, {
            icon: e.jsx(V, { size: 12 }),
            label: "Aviator",
            color: "from-red-500 to-orange-500",
          }),
          e.jsx(m, {
            icon: e.jsx(z, { size: 12 }),
            label: "Rocket",
            color: "from-orange-500 to-yellow-500",
          }),
          e.jsx(m, {
            icon: e.jsx(J, { size: 12 }),
            label: "Mines",
            color: "from-blue-500 to-purple-500",
          }),
          e.jsx(m, {
            icon: e.jsx(te, { size: 12 }),
            label: "LuckyJet",
            color: "from-purple-500 to-pink-500",
          }),
        ],
      }),
    ],
  });
}
function m({ icon: s, label: a, color: r }) {
  return e.jsxs("div", {
    className: `flex flex-col items-center gap-0.5 rounded-lg bg-gradient-to-br ${r} p-1.5 shadow-md`,
    children: [
      e.jsx("div", { className: "text-white", children: s }),
      e.jsx("span", {
        className: "text-[8px] font-bold text-white",
        children: a,
      }),
    ],
  });
}
function ue() {
  return e.jsxs("div", {
    className:
      "relative h-72 w-40 rounded-[28px] border border-white/15 bg-gradient-to-br from-[#141433] to-[#0B0B22] p-3 shadow-2xl shadow-[#3D5AFE]/30 lg:h-80 lg:w-44",
    children: [
      e.jsx("div", {
        className: "mx-auto mb-2 h-1 w-10 rounded-full bg-white/20",
      }),
      e.jsxs("div", {
        className: "rounded-2xl border border-white/10 bg-white/[0.04] p-2.5",
        children: [
          e.jsx("p", {
            className: "text-[8px] text-[#9CA3AF]",
            children: "Prédiction en cours",
          }),
          e.jsx("p", {
            className: "text-[10px] font-semibold text-[#7B2FFF]",
            children: "Aviator",
          }),
          e.jsxs("div", {
            className: "flex items-end justify-between",
            children: [
              e.jsx("p", {
                className: "font-display text-2xl font-black text-white",
                children: "2.45x",
              }),
              e.jsx("span", {
                className:
                  "rounded-md bg-green-500/20 px-1.5 py-0.5 text-[8px] font-bold text-green-400",
                children: "EN COURS",
              }),
            ],
          }),
        ],
      }),
      e.jsx("p", {
        className: "mt-3 text-[9px] font-bold uppercase text-white/70",
        children: "Statistiques",
      }),
      e.jsxs("div", {
        className: "mt-2 space-y-1.5 text-[9px]",
        children: [
          e.jsx(c, { label: "Gagnantes", value: "72%", ok: !0 }),
          e.jsx(c, { label: "Profit total", value: "+4,250€", ok: !0 }),
          e.jsx(c, { label: "Prédictions", value: "186" }),
          e.jsx(c, { label: "Mise moyenne", value: "25€" }),
          e.jsx(c, { label: "Best multi", value: "12.85x", ok: !0 }),
        ],
      }),
      e.jsx("div", {
        className:
          "mt-2 flex h-10 items-end gap-0.5 rounded-lg bg-white/[0.03] p-1",
        children: [3, 5, 4, 7, 6, 8, 6, 9, 8, 10, 9, 11].map((s, a) =>
          e.jsx(
            "div",
            {
              className:
                "flex-1 rounded-sm bg-gradient-to-t from-[#3D5AFE] to-[#E040FB]",
              style: { height: `${s * 8}%` },
            },
            a,
          ),
        ),
      }),
    ],
  });
}
function c({ label: s, value: a, ok: r }) {
  return e.jsxs("div", {
    className: "flex items-center justify-between",
    children: [
      e.jsx("span", { className: "text-[#9CA3AF]", children: s }),
      e.jsx("span", {
        className: r
          ? "font-semibold text-green-400"
          : "font-semibold text-white",
        children: a,
      }),
    ],
  });
}
function me() {
  return e.jsxs("div", {
    className: "relative",
    children: [
      e.jsx("div", {
        className:
          "absolute inset-0 -z-10 rounded-full bg-[#E040FB]/40 blur-3xl",
      }),
      e.jsx("img", {
        src: T.url,
        alt: "GOD PREDITOR mascot",
        width: 280,
        height: 370,
        className:
          "h-[280px] w-auto drop-shadow-[0_20px_40px_rgba(224,64,251,0.35)] lg:h-[370px]",
      }),
    ],
  });
}
function ve() {
  return e.jsx(oe, { form: e.jsx(ne, {}), hero: e.jsx(ce, {}) });
}
export { ve as component };
