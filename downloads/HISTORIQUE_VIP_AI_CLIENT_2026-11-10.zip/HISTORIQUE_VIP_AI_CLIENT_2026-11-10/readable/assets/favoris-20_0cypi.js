import { r as o, j as e, k as l } from "./index-C5ThNCN-.js";
import {
  r as c,
  a as n,
  D as x,
  S as m,
  t as d,
} from "./DashboardLayout-XCzqIJrp.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
function b() {
  const [a, r] = o.useState([]);
  o.useEffect(() => r(c()), []);
  const i = n.filter((s) => a.includes(s.path));
  return e.jsxs(x, {
    children: [
      e.jsx("h1", {
        className: "font-display text-2xl font-black",
        children: "Mes favoris",
      }),
      i.length === 0
        ? e.jsx("p", {
            className: "text-sm text-white/60",
            children:
              "Aucun favori pour l'instant. Touchez l'étoile d'un jeu ci-dessous pour l'ajouter.",
          })
        : e.jsx("div", {
            className: "grid grid-cols-2 sm:grid-cols-3 gap-3",
            children: i.map((s) =>
              e.jsxs(
                l,
                {
                  to: s.path,
                  className:
                    "rounded-2xl border border-[#E040FB]/30 bg-white/[0.04] p-4",
                  children: [
                    e.jsx("p", { className: "font-bold", children: s.name }),
                    e.jsx("p", {
                      className: "text-xs text-white/50",
                      children: s.platform,
                    }),
                  ],
                },
                s.path,
              ),
            ),
          }),
      e.jsx("h2", {
        className: "mt-4 text-sm font-semibold text-white/70",
        children: "Tous les jeux",
      }),
      e.jsx("div", {
        className: "space-y-2",
        children: n.map((s) => {
          const t = a.includes(s.path);
          return e.jsxs(
            "div",
            {
              className:
                "flex items-center justify-between rounded-xl bg-white/[0.04] px-4 py-3",
              children: [
                e.jsxs(l, {
                  to: s.path,
                  className: "text-sm",
                  children: [
                    s.name,
                    " ",
                    e.jsxs("span", {
                      className: "text-white/40",
                      children: ["· ", s.platform],
                    }),
                  ],
                }),
                e.jsx("button", {
                  "aria-label": t
                    ? "Retirer des favoris"
                    : "Ajouter aux favoris",
                  onClick: () => r(d(s.path)),
                  className: t ? "text-amber-400" : "text-white/40",
                  children: e.jsx(m, {
                    size: 20,
                    fill: t ? "currentColor" : "none",
                  }),
                }),
              ],
            },
            s.path,
          );
        }),
      }),
    ],
  });
}
export { b as component };
