import {
  c as l,
  d as k,
  e as F,
  Z as Y,
  an as Q,
  r as o,
  f as z,
  $ as ee,
  J as f,
  j as e,
  k as d,
  A,
  m as v,
  ao as te,
  ap as se,
  S as ae,
} from "./index-C5ThNCN-.js";
import {
  T as ne,
  c as ie,
  Z as re,
} from "./god-character.png.asset-BWFGzeh1.js";
import { H as D } from "./history-DU1SVBVB.js";
import { C as $, W as P, L as w, S as C } from "./wrench-DMPf9Lxe.js";
const oe = [
    ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
    [
      "path",
      {
        d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",
        key: "11g9vi",
      },
    ],
  ],
  le = l("bell", oe);
const ce = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]],
  de = l("chevron-down", ce);
const xe = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
    [
      "path",
      { d: "M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662", key: "154egf" },
    ],
  ],
  N = l("circle-user", xe);
const me = [
    [
      "path",
      {
        d: "M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4",
        key: "1slcih",
      },
    ],
  ],
  pe = l("flame", me);
const he = [
    ["line", { x1: "6", x2: "10", y1: "11", y2: "11", key: "1gktln" }],
    ["line", { x1: "8", x2: "8", y1: "9", y2: "13", key: "qnk9ow" }],
    ["line", { x1: "15", x2: "15.01", y1: "12", y2: "12", key: "krot7o" }],
    ["line", { x1: "18", x2: "18.01", y1: "10", y2: "10", key: "1lcuu1" }],
    [
      "path",
      {
        d: "M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",
        key: "mfqc10",
      },
    ],
  ],
  T = l("gamepad-2", he);
const ue = [
    [
      "path",
      { d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8", key: "5wwlr5" },
    ],
    [
      "path",
      {
        d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
        key: "r6nss1",
      },
    ],
  ],
  R = l("house", ue);
const fe = [
    ["path", { d: "M4 5h16", key: "1tepv9" }],
    ["path", { d: "M4 12h16", key: "1lakjw" }],
    ["path", { d: "M4 19h16", key: "1djgab" }],
  ],
  be = l("menu", fe);
const ge = [
    [
      "path",
      {
        d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
        key: "18887p",
      },
    ],
  ],
  O = l("message-square", ge);
const je = [
    [
      "path",
      {
        d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
        key: "1i5ecw",
      },
    ],
    ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ],
  q = l("settings", je);
const ve = [
    ["path", { d: "M12 18v4", key: "jadmvz" }],
    [
      "path",
      {
        d: "M2 14.499a5.5 5.5 0 0 0 9.591 3.675.6.6 0 0 1 .818.001A5.5 5.5 0 0 0 22 14.5c0-2.29-1.5-4-3-5.5l-5.492-5.312a2 2 0 0 0-3-.02L5 8.999c-1.5 1.5-3 3.2-3 5.5",
        key: "1aw2pz",
      },
    ],
  ],
  we = l("spade", ve);
const ye = [
    [
      "path",
      {
        d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
        key: "r04s7s",
      },
    ],
  ],
  Ne = l("star", ye);
const ke = [
    [
      "path",
      {
        d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
        key: "qn84l0",
      },
    ],
    ["path", { d: "M13 5v2", key: "dyzc3o" }],
    ["path", { d: "M13 17v2", key: "1ont0d" }],
    ["path", { d: "M13 11v2", key: "1wjjxi" }],
  ],
  Fe = l("ticket", ke),
  _e = k({ method: "POST" }).handler(
    F("9001e82f5e4586240724b3702db8180f0d27f5f5c01978829a8d5234c6a074f1"),
  ),
  Ie = k({ method: "POST" }).handler(
    F("1cdaf0dad02b936b30a985a2e974e14ae847b18044db13e7e7facf3e194a72eb"),
  ),
  Le = k({ method: "POST" }).handler(
    F("085b089e917b0544495adf0eee10f02f17d4f3acbb6d6d0f8ade776c442fe7c3"),
  ),
  Se = "/__l5e/assets-v1/55c3fec5-d979-419a-b61b-c8796b91df06/user-logo.png",
  I = { url: Se },
  Be = [
    { path: "/", name: "Lucky Jet", platform: "1Win" },
    { path: "/rocketqueen", name: "Rocket Queen", platform: "1Win" },
    { path: "/jetx-1win", name: "JetX", platform: "1Win" },
    { path: "/astronaut", name: "Astronaut", platform: "1Win" },
    { path: "/jetx", name: "JetX", platform: "Betclic" },
    { path: "/aviator", name: "Aviator", platform: "Betclic" },
    { path: "/splinko", name: "Splinko Deluxe", platform: "Betclic" },
    { path: "/crash-1xbet", name: "Crash", platform: "1xBet" },
    { path: "/dragons-crash", name: "Dragon's Crash", platform: "1xBet" },
  ],
  Ee = (n) => Be.find((i) => i.path === n),
  V = "gp_favorite_games";
function Me() {
  try {
    const n = JSON.parse(localStorage.getItem(V) || "[]");
    return Array.isArray(n) ? n.filter((i) => typeof i == "string") : [];
  } catch {
    return [];
  }
}
function De(n) {
  const i = Me(),
    s = i.includes(n) ? i.filter((m) => m !== n) : [...i, n];
  return (localStorage.setItem(V, JSON.stringify(s)), s);
}
const ze = [
    { to: "/dashboard", label: "Accueil", icon: R },
    { to: "/jeux", label: "Jeux", icon: T },
    { to: "/sport", label: "Sport", icon: ne },
    { to: "/historique", label: "Historique", icon: D },
    { to: "/boutique", label: "Abonnement", icon: $ },
    { to: "/outils", label: "Outils", icon: P },
    { to: "/profil", label: "Profil", icon: N },
  ],
  y = "lj_access_token",
  L = "lj_upgrade_banner_dismissed";
function $e({ children: n }) {
  const i = Y(),
    s = Q({ select: (t) => t.location.pathname }),
    [m, H] = o.useState(""),
    [G, _] = o.useState(!1),
    [S, p] = o.useState(!1),
    [K, h] = o.useState(!1),
    [W, J] = o.useState(null),
    [U, B] = o.useState(!1),
    [u, E] = o.useState(0),
    b = o.useRef(null),
    M = z(ee),
    g = z(_e);
  (o.useEffect(() => {
    const t = (a) => {
      b.current && !b.current.contains(a.target) && p(!1);
    };
    return (
      document.addEventListener("mousedown", t),
      () => document.removeEventListener("mousedown", t)
    );
  }, []),
    o.useEffect(() => {
      (async () => {
        const { data: a } = await f.auth.getUser(),
          c = a.user,
          r = c?.user_metadata ?? {};
        c && H(r.first_name || c.email?.split("@")[0] || "");
        const X = typeof window < "u" && !!localStorage.getItem(y);
        _(!!(r.is_vip || r.subscription_active) || X);
      })();
      const t = () => {
        typeof window < "u" && localStorage.getItem(y) && _(!0);
      };
      return (
        window.addEventListener("lj-access-unlocked", t),
        window.addEventListener("storage", t),
        () => {
          (window.removeEventListener("lj-access-unlocked", t),
            window.removeEventListener("storage", t));
        }
      );
    }, []),
    o.useEffect(() => {
      const t = typeof window < "u" ? localStorage.getItem(y) : null;
      if (!t) return;
      B(sessionStorage.getItem(L) === "1");
      let a = !1;
      (async () => {
        try {
          const r = await M({ data: { token: t } });
          !a && r.ok && J(r.source);
        } catch {}
        try {
          const r = await g({ data: { token: t } });
          !a && r.ok && E(r.unread);
        } catch {}
      })();
      const c = setInterval(async () => {
        try {
          const r = await g({ data: { token: t } });
          r.ok && E(r.unread);
        } catch {}
      }, 6e4);
      return () => {
        ((a = !0), clearInterval(c));
      };
    }, [M, g, s]),
    o.useEffect(() => {
      if (!Ee(s)) return;
      const t = `gp_visit_${s}`,
        a = Number(sessionStorage.getItem(t) || 0);
      Date.now() - a < 30 * 6e4 ||
        f.auth.getUser().then(({ data: c }) => {
          c.user &&
            (sessionStorage.setItem(t, String(Date.now())),
            f
              .from("game_visits")
              .insert({ user_id: c.user.id, game_path: s })
              .then(() => {}));
        });
    }, [s]));
  const Z = W === "manual" && !U && s !== "/boutique",
    j = async () => {
      (await f.auth.signOut(), i({ to: "/login" }));
    };
  return e.jsxs("div", {
    className: "min-h-screen bg-[#08070F] text-white flex",
    children: [
      e.jsxs("aside", {
        className:
          "hidden lg:flex w-[240px] shrink-0 flex-col gap-4 p-4 border-r border-white/[0.06] bg-[#0B0916]",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-1 px-3 py-4",
            children: [
              e.jsx("span", {
                className:
                  "font-display text-xl font-black italic tracking-tight text-white",
                children: "GOD",
              }),
              e.jsx("span", {
                className:
                  "font-display text-xl font-black italic tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                children: "PREDITOR",
              }),
            ],
          }),
          e.jsxs("nav", {
            className: "flex flex-col gap-1",
            children: [
              ze.map((t) => {
                const a =
                    s === t.to || (t.to === "/dashboard" && s === "/dashboard"),
                  c = t.icon;
                return e.jsxs(
                  d,
                  {
                    to: t.to,
                    className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${a ? "bg-gradient-to-r from-[#7B2FFF]/25 to-transparent border border-[#7B2FFF]/40 text-white" : "text-white/70 hover:text-white hover:bg-white/[0.04]"}`,
                    children: [
                      e.jsx(c, { size: 18 }),
                      e.jsx("span", { className: "flex-1", children: t.label }),
                    ],
                  },
                  t.to,
                );
              }),
              e.jsx("div", { className: "my-3 h-px bg-white/[0.06]" }),
              e.jsxs("button", {
                className:
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]",
                children: [
                  e.jsx(q, { size: 18 }),
                  e.jsx("span", { children: "Paramètres" }),
                ],
              }),
              e.jsxs("button", {
                onClick: j,
                className:
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-[#ff5577] hover:bg-[#ff5577]/10",
                children: [
                  e.jsx(w, { size: 18 }),
                  e.jsx("span", { children: "Déconnexion" }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className:
              "relative overflow-hidden rounded-2xl border border-white/[0.08] bg-gradient-to-br from-[#1a0b2e] to-[#0b0916] p-4",
            children: [
              e.jsxs("div", {
                className: "relative z-10 max-w-[130px]",
                children: [
                  e.jsxs("p", {
                    className: "font-display text-sm font-black leading-tight",
                    children: [
                      "BOOSTEZ",
                      e.jsx("br", {}),
                      e.jsx("span", {
                        className: "text-[#E040FB]",
                        children: "VOS GAINS",
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "mt-2 text-[10px] text-white/60",
                    children: "Avec nos analyses intelligentes en temps réel !",
                  }),
                  e.jsx("a", {
                    href: "https://t.me/vipluckyjet",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className:
                      "mt-3 inline-block rounded-lg bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] px-3 py-1.5 text-[11px] font-semibold",
                    children: "Découvrir",
                  }),
                  e.jsxs("a", {
                    href: "https://t.me/haga48",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className:
                      "mt-2 inline-flex items-center gap-1.5 rounded-lg border border-[#229ED9]/40 bg-[#229ED9]/15 px-3 py-1.5 text-[11px] font-semibold text-white hover:bg-[#229ED9]/25",
                    children: [
                      e.jsx(C, { size: 12, className: "fill-white" }),
                      "Contactez-nous",
                    ],
                  }),
                ],
              }),
              e.jsx("img", {
                src: ie.url,
                alt: "",
                className:
                  "pointer-events-none absolute -right-4 bottom-0 h-32 w-auto object-contain opacity-90",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "flex-1 flex flex-col min-w-0",
        children: [
          e.jsxs("header", {
            className:
              "flex items-center justify-between gap-2 border-b border-white/[0.06] bg-[#0B0916]/60 px-3 sm:px-6 py-3 backdrop-blur sticky top-0 z-30",
            children: [
              e.jsxs("div", {
                className: "flex items-center gap-2 sm:gap-3 min-w-0 flex-1",
                children: [
                  e.jsx("div", {
                    className:
                      "h-10 w-10 sm:h-11 sm:w-11 shrink-0 rounded-full bg-gradient-to-br from-[#7B2FFF] to-[#E040FB] p-[2px]",
                    children: e.jsx("div", {
                      className:
                        "h-full w-full rounded-full bg-[#0B0916] flex items-center justify-center overflow-hidden",
                      children: e.jsx("img", {
                        src: I.url,
                        alt: "Logo",
                        className: "h-full w-full object-cover",
                        loading: "lazy",
                      }),
                    }),
                  }),
                  e.jsxs("div", {
                    className: "min-w-0 flex-1",
                    children: [
                      e.jsx("p", {
                        className: "text-[10px] sm:text-xs text-white/60",
                        children: "Bonjour,",
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-1.5 sm:gap-2 min-w-0",
                        children: [
                          e.jsx("p", {
                            className:
                              "font-display font-bold text-sm sm:text-base truncate",
                            children: m || "...",
                          }),
                          G &&
                            e.jsx("span", {
                              className:
                                "shrink-0 rounded-md bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] px-1.5 py-0.5 text-[9px] font-black tracking-wider text-white",
                              children: "VIP",
                            }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "flex items-center gap-1.5 sm:gap-3 shrink-0",
                children: [
                  e.jsxs(d, {
                    to: "/messages",
                    className:
                      "hidden sm:inline-flex relative rounded-full bg-white/[0.05] p-2.5 hover:bg-white/[0.08]",
                    "aria-label": "Notifications",
                    children: [
                      e.jsx(le, { size: 16 }),
                      u > 0 &&
                        e.jsx("span", {
                          className:
                            "absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full bg-[#ff3d6b] text-[9px] font-black flex items-center justify-center",
                          children: u,
                        }),
                    ],
                  }),
                  e.jsxs(d, {
                    to: "/messages",
                    className:
                      "hidden sm:inline-flex relative rounded-full bg-white/[0.05] p-2.5 hover:bg-white/[0.08]",
                    "aria-label": "Messagerie",
                    children: [
                      e.jsx(O, { size: 16 }),
                      u > 0 &&
                        e.jsx("span", {
                          className:
                            "absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full bg-[#ff3d6b] text-[9px] font-black flex items-center justify-center",
                          children: u,
                        }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "relative",
                    ref: b,
                    children: [
                      e.jsxs("button", {
                        onClick: () => p((t) => !t),
                        className:
                          "flex items-center gap-2 rounded-full p-1 hover:bg-white/[0.05] transition",
                        children: [
                          e.jsx("div", {
                            className:
                              "h-9 w-9 rounded-full bg-gradient-to-br from-[#7B2FFF] to-[#E040FB] p-[2px]",
                            children: e.jsx("div", {
                              className:
                                "h-full w-full rounded-full bg-[#0B0916] overflow-hidden",
                              children: e.jsx("img", {
                                src: I.url,
                                alt: "Logo",
                                className: "h-full w-full object-cover",
                              }),
                            }),
                          }),
                          e.jsx(de, {
                            size: 14,
                            className: `text-white/50 transition-transform ${S ? "rotate-180" : ""}`,
                          }),
                        ],
                      }),
                      e.jsx(A, {
                        children:
                          S &&
                          e.jsxs(v.div, {
                            initial: { opacity: 0, y: -6, scale: 0.98 },
                            animate: { opacity: 1, y: 0, scale: 1 },
                            exit: { opacity: 0, y: -6, scale: 0.98 },
                            transition: { duration: 0.15 },
                            className:
                              "absolute right-0 top-full mt-2 w-52 rounded-xl border border-white/[0.08] bg-[#12101F] shadow-2xl overflow-hidden z-50",
                            children: [
                              e.jsxs("div", {
                                className:
                                  "px-3 py-2.5 border-b border-white/[0.06]",
                                children: [
                                  e.jsx("p", {
                                    className: "text-[10px] text-white/50",
                                    children: "Connecté en tant que",
                                  }),
                                  e.jsx("p", {
                                    className: "text-sm font-semibold truncate",
                                    children: m || "Utilisateur",
                                  }),
                                ],
                              }),
                              e.jsxs("button", {
                                onClick: () => {
                                  (p(!1), i({ to: "/profil" }));
                                },
                                className:
                                  "flex w-full items-center gap-2.5 px-3 py-2.5 text-sm text-white/80 hover:bg-white/[0.05] hover:text-white",
                                children: [
                                  e.jsx(q, { size: 16 }),
                                  "Paramètres",
                                ],
                              }),
                              e.jsxs("button", {
                                onClick: () => {
                                  (p(!1), j());
                                },
                                className:
                                  "flex w-full items-center gap-2.5 px-3 py-2.5 text-sm text-[#ff5577] hover:bg-[#ff5577]/10",
                                children: [
                                  e.jsx(w, { size: 16 }),
                                  "Déconnexion",
                                ],
                              }),
                            ],
                          }),
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          Z &&
            e.jsxs("div", {
              className:
                "border-b border-[#7B2FFF]/30 bg-gradient-to-r from-[#7B2FFF]/15 via-[#E040FB]/10 to-transparent px-3 sm:px-6 py-2.5 flex items-center gap-3",
              children: [
                e.jsx(te, { className: "w-4 h-4 text-[#E040FB] shrink-0" }),
                e.jsxs("p", {
                  className: "text-xs sm:text-sm text-white/85 flex-1 min-w-0",
                  children: [
                    "Vous utilisez une ",
                    e.jsx("b", { children: "clé d'activation" }),
                    ". Pour un abonnement direct et sans clé, écrivez au support via la messagerie du site.",
                  ],
                }),
                e.jsxs(d, {
                  to: "/messages",
                  className:
                    "hidden sm:inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] whitespace-nowrap",
                  children: [e.jsx(O, { size: 12 }), " Ouvrir la messagerie"],
                }),
                e.jsx(d, {
                  to: "/boutique",
                  className:
                    "inline-flex sm:hidden items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-semibold bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] whitespace-nowrap",
                  children: "Abonnement",
                }),
                e.jsx("button", {
                  onClick: () => {
                    (B(!0), sessionStorage.setItem(L, "1"));
                  },
                  className: "p-1 text-white/40 hover:text-white shrink-0",
                  "aria-label": "Masquer",
                  children: e.jsx(se, { size: 14 }),
                }),
              ],
            }),
          e.jsx("div", {
            className:
              "lg:hidden border-b border-white/[0.08] bg-[#0B0916] px-1.5 py-1",
            children: e.jsxs("div", {
              className: "grid grid-cols-4",
              children: [
                e.jsx(x, {
                  to: "/populaires",
                  label: "Populaires",
                  icon: ae,
                  active: s === "/populaires",
                }),
                e.jsx(x, {
                  to: "/sport",
                  label: "Sports",
                  icon: re,
                  active: s.startsWith("/sport"),
                }),
                e.jsx(x, {
                  to: "/esport",
                  label: "E-sport",
                  icon: T,
                  active: s === "/esport",
                }),
                e.jsx(x, {
                  to: "/jeux",
                  label: "Casino",
                  icon: we,
                  active: s === "/jeux",
                }),
              ],
            }),
          }),
          e.jsx("main", {
            className: "flex-1 p-3 sm:p-6 space-y-4 sm:space-y-5 pb-28 lg:pb-6",
            children: n,
          }),
          e.jsxs("footer", {
            className:
              "hidden sm:flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.06] px-6 py-3 text-[11px] text-white/40",
            children: [
              e.jsx("span", {
                children: "© 2026 GOD PREDITOR. Tous droits réservés.",
              }),
              e.jsx("span", { children: "Version 1.0.0" }),
              e.jsxs("span", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx("span", {
                    className:
                      "h-2 w-2 rounded-full bg-emerald-400 animate-pulse",
                  }),
                  "Serveur connecté",
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsx("nav", {
        className:
          "lg:hidden fixed bottom-0 inset-x-0 z-40 pb-[env(safe-area-inset-bottom)]",
        children: e.jsx("div", {
          className:
            "bg-[#0B0916]/95 backdrop-blur border-t border-white/[0.08] px-1.5",
          children: e.jsxs("div", {
            className: "grid grid-cols-5",
            children: [
              e.jsx(x, {
                to: "/populaires",
                label: "Populaire",
                icon: pe,
                active: s === "/populaires",
              }),
              e.jsx(x, {
                to: "/favoris",
                label: "Favoris",
                icon: Ne,
                active: s === "/favoris",
              }),
              e.jsxs("div", {
                className: "flex flex-col items-center",
                children: [
                  e.jsx(d, {
                    to: "/coupons",
                    className:
                      "-mt-6 flex h-14 w-14 items-center justify-center rounded-full border-4 border-[#0B0916] bg-gradient-to-br from-[#7B2FFF] to-[#E040FB] text-white shadow-[0_0_24px_rgba(123,47,255,0.55)]",
                    children: e.jsx(Fe, { size: 22 }),
                  }),
                  e.jsx("span", {
                    className:
                      "mt-0.5 pb-1.5 text-[10px] font-medium text-white/60",
                    children: "Coupon",
                  }),
                ],
              }),
              e.jsx(x, {
                to: "/historique",
                label: "Historique",
                icon: D,
                active: s.startsWith("/historique"),
              }),
              e.jsxs("button", {
                onClick: () => h(!0),
                className:
                  "flex flex-col items-center gap-0.5 py-2 text-[10px] font-medium text-white/55",
                children: [
                  e.jsx(be, { size: 20 }),
                  e.jsx("span", { children: "Menu" }),
                ],
              }),
            ],
          }),
        }),
      }),
      e.jsx(A, {
        children:
          K &&
          e.jsxs(e.Fragment, {
            children: [
              e.jsx(
                v.div,
                {
                  initial: { opacity: 0 },
                  animate: { opacity: 1 },
                  exit: { opacity: 0 },
                  className: "lg:hidden fixed inset-0 z-50 bg-black/60",
                  onClick: () => h(!1),
                },
                "menu-backdrop",
              ),
              e.jsxs(
                v.div,
                {
                  initial: { y: "100%" },
                  animate: { y: 0 },
                  exit: { y: "100%" },
                  transition: { type: "spring", damping: 30, stiffness: 300 },
                  className:
                    "lg:hidden fixed bottom-0 inset-x-0 z-50 rounded-t-2xl border-t border-white/[0.08] bg-[#12101F] p-4 pb-8",
                  children: [
                    e.jsx("div", {
                      className:
                        "mx-auto mb-3 h-1 w-10 rounded-full bg-white/20",
                    }),
                    e.jsx("p", {
                      className:
                        "mb-2 px-1 text-[10px] uppercase tracking-wider text-white/40",
                      children: "Menu",
                    }),
                    e.jsx("div", {
                      className: "grid grid-cols-2 gap-1.5",
                      children: [
                        { to: "/dashboard", label: "Accueil", icon: R },
                        { to: "/outils", label: "Outils", icon: P },
                        { to: "/bot-telegram", label: "Bot Telegram", icon: C },
                        { to: "/parrainage", label: "Parrainage", icon: N },
                        { to: "/profil", label: "Profil", icon: N },
                        { to: "/boutique", label: "Abonnement", icon: $ },
                      ].map((t) => {
                        const a = t.icon;
                        return e.jsxs(
                          d,
                          {
                            to: t.to,
                            onClick: () => h(!1),
                            className: `flex items-center gap-2.5 rounded-xl bg-white/[0.04] px-3 py-3 text-sm ${s === t.to ? "text-[#E040FB]" : "text-white/80"} hover:bg-white/[0.08]`,
                            children: [e.jsx(a, { size: 18 }), t.label],
                          },
                          t.to,
                        );
                      }),
                    }),
                    e.jsxs("button", {
                      onClick: () => {
                        (h(!1), j());
                      },
                      className:
                        "mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-[#ff5577]/30 py-2.5 text-sm text-[#ff5577] hover:bg-[#ff5577]/10",
                      children: [e.jsx(w, { size: 16 }), "Déconnexion"],
                    }),
                  ],
                },
                "menu-sheet",
              ),
            ],
          }),
      }),
    ],
  });
}
function x({ to: n, label: i, icon: s, active: m }) {
  return e.jsxs(d, {
    to: n,
    className: `flex flex-col items-center gap-0.5 py-2 text-[10px] font-medium transition ${m ? "text-[#E040FB]" : "text-white/55"}`,
    children: [
      e.jsx(s, { size: 20 }),
      e.jsx("span", { className: "truncate", children: i }),
    ],
  });
}
export {
  le as B,
  $e as D,
  pe as F,
  T as G,
  O as M,
  Ne as S,
  Fe as T,
  Be as a,
  Le as b,
  Ee as f,
  _e as l,
  Ie as m,
  Me as r,
  De as t,
};
