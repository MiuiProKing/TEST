import { f as c, $ as i, r as a, j as e, k as d } from "./index-C5ThNCN-.js";
const l = "lj_access_token";
function m() {
  const t = c(i),
    [r, n] = a.useState("loading");
  return (
    a.useEffect(() => {
      const s = localStorage.getItem(l);
      if (!s) return n("denied");
      t({ data: { token: s } })
        .then((o) => n(o.ok ? "ok" : "denied"))
        .catch(() => n("denied"));
    }, [t]),
    r
  );
}
function x({ loading: t }) {
  return e.jsx("div", {
    className: "glass rounded-2xl p-6 text-center space-y-3",
    children: t
      ? e.jsx("p", {
          className: "text-sm text-muted-foreground",
          children: "Vérification de votre abonnement…",
        })
      : e.jsxs(e.Fragment, {
          children: [
            e.jsx("p", { className: "text-3xl", children: "🔒" }),
            e.jsx("h2", {
              className: "font-display font-black text-lg",
              children: "Section Premium réservée aux abonnés",
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Prenez un abonnement pour accéder aux signaux Premium Lucky Jet, JetX 1Win et JetX Betclic.",
            }),
            e.jsx(d, {
              to: "/",
              className:
                "inline-block rounded-full bg-gradient-to-r from-yellow-400 to-amber-600 px-5 py-2 text-sm font-bold text-foreground",
              children: "S'abonner",
            }),
          ],
        }),
  });
}
export { x as P, m as u };
