import {
  u as m,
  r as o,
  j as e,
  m as a,
  G as h,
  C as f,
  a as v,
  E as b,
  A as g,
  S as j,
  b as w,
} from "./index-C5ThNCN-.js";
import { R as y } from "./RoundCard-CZ-rEJ_D.js";
import { P as N, S as _ } from "./PredictionPanel-BwmEfDz4.js";
import { S as k } from "./wrench-DMPf9Lxe.js";
import { D as S } from "./DashboardLayout-XCzqIJrp.js";
import "./analysis-data-BaiXRb_2.js";
import "./triangle-alert-CzDFXfJ_.js";
import "./database-80brKRBJ.js";
import "./trending-up-B5K2KKMW.js";
import "./activity-D198U5P3.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
const d = "HAGA48",
  E = "https://one-vv53243.com/?open=register&p=8nf4",
  R = "https://t.me/vipluckyjet";
function C() {
  const { t: s } = m(),
    [t, r] = o.useState(!1),
    n = async () => {
      try {
        (await navigator.clipboard.writeText(d),
          r(!0),
          setTimeout(() => r(!1), 1800));
      } catch {}
    };
  return e.jsxs(a.section, {
    initial: { opacity: 0, y: 12 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 },
    className: "relative overflow-hidden glass rounded-3xl p-4 sm:p-6 lg:p-7",
    children: [
      e.jsx("div", {
        className:
          "pointer-events-none absolute -top-24 -right-24 w-72 h-72 rounded-full bg-[var(--neon-purple)] opacity-20 blur-3xl",
      }),
      e.jsx("div", {
        className:
          "pointer-events-none absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-[var(--neon-blue)] opacity-20 blur-3xl",
      }),
      e.jsxs("div", {
        className:
          "relative grid gap-4 lg:gap-6 lg:grid-cols-[1fr_auto] items-center",
        children: [
          e.jsxs("div", {
            className: "flex flex-col gap-3",
            children: [
              e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  e.jsxs("span", {
                    className:
                      "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] sm:text-xs font-mono uppercase tracking-wider bg-[var(--neon-orange)]/15 text-[var(--neon-orange)] border border-[var(--neon-orange)]/40",
                    children: [
                      e.jsx(h, { className: "w-3 h-3" }),
                      " ",
                      s("promo.bonus"),
                    ],
                  }),
                  e.jsx("span", {
                    className:
                      "text-[10px] sm:text-xs text-muted-foreground font-mono",
                    children: s("promo.signup_promo"),
                  }),
                ],
              }),
              e.jsxs("h2", {
                className:
                  "font-display font-bold text-lg sm:text-2xl lg:text-3xl tracking-tight leading-tight",
                children: [
                  s("promo.boost"),
                  " ",
                  e.jsx("span", {
                    className: "text-[var(--neon-orange)] text-glow",
                    children: d,
                  }),
                ],
              }),
              e.jsxs("div", {
                className:
                  "flex flex-col sm:flex-row gap-2 sm:gap-3 sm:items-center",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex items-center gap-2 glass rounded-2xl px-3 py-2 border border-[var(--neon-orange)]/40 shadow-[0_0_24px_var(--neon-orange-glow)]",
                    children: [
                      e.jsx("span", {
                        className:
                          "font-mono text-base sm:text-lg font-bold tracking-[0.2em] text-[var(--neon-orange)] text-glow",
                        children: d,
                      }),
                      e.jsxs("button", {
                        type: "button",
                        onClick: n,
                        className:
                          "ml-auto inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-mono font-semibold bg-[var(--neon-orange)]/15 hover:bg-[var(--neon-orange)]/25 text-[var(--neon-orange)] transition-colors",
                        children: [
                          t
                            ? e.jsx(f, { className: "w-3.5 h-3.5" })
                            : e.jsx(v, { className: "w-3.5 h-3.5" }),
                          s(t ? "promo.copied" : "promo.copy"),
                        ],
                      }),
                    ],
                  }),
                  e.jsxs(a.a, {
                    whileHover: { scale: 1.03 },
                    whileTap: { scale: 0.97 },
                    href: E,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className:
                      "inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-display font-bold text-white bg-gradient-to-r from-[var(--neon-purple)] to-[var(--neon-blue)] shadow-[0_0_30px_var(--neon-purple-glow)] hover:shadow-[0_0_40px_var(--neon-purple-glow)] transition-shadow",
                    children: [
                      s("promo.register"),
                      e.jsx(b, { className: "w-4 h-4" }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs(a.a, {
            whileHover: { scale: 1.04 },
            whileTap: { scale: 0.96 },
            href: R,
            target: "_blank",
            rel: "noopener noreferrer",
            className:
              "group relative inline-flex items-center justify-center gap-2.5 px-5 py-3 rounded-2xl text-sm sm:text-base font-display font-bold text-white bg-gradient-to-r from-[#229ED9] to-[#27a7e7] shadow-[0_0_30px_rgba(34,158,217,0.55)] hover:shadow-[0_0_50px_rgba(34,158,217,0.8)] transition-shadow w-full lg:w-auto",
            children: [
              e.jsx(a.span, {
                animate: { x: [0, 4, 0, -2, 0], rotate: [0, 8, 0, -4, 0] },
                transition: { duration: 2.4, repeat: 1 / 0, ease: "easeInOut" },
                className: "inline-flex",
                children: e.jsx(k, { className: "w-5 h-5 fill-white" }),
              }),
              s("promo.telegram"),
              e.jsx("span", {
                className:
                  "absolute inset-0 rounded-2xl ring-1 ring-white/20 group-hover:ring-white/40 transition",
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function P() {
  const { t: s } = m(),
    [t, r] = o.useState(!0);
  return (
    o.useEffect(() => {
      const n = setTimeout(() => r(!1), 3200);
      return () => clearTimeout(n);
    }, []),
    e.jsx(g, {
      children:
        t &&
        e.jsxs(a.div, {
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
          transition: { duration: 0.4 },
          className:
            "fixed inset-0 z-[100] flex items-center justify-center px-4 pointer-events-none",
          children: [
            e.jsx("div", {
              className:
                "absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-transparent backdrop-blur-sm",
            }),
            e.jsxs(a.div, {
              initial: { scale: 0.9, y: 20, opacity: 0 },
              animate: { scale: 1, y: 0, opacity: 1 },
              exit: { scale: 0.95, y: -10, opacity: 0 },
              transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] },
              className:
                "relative glass rounded-3xl px-8 py-6 sm:px-12 sm:py-8 border border-white/10 shadow-[0_0_60px_rgba(168,85,247,0.35)] text-center",
              children: [
                e.jsx(a.div, {
                  animate: { rotate: [0, 10, -10, 0] },
                  transition: { duration: 2, repeat: 1 / 0 },
                  className:
                    "inline-flex w-12 h-12 sm:w-14 sm:h-14 mb-3 items-center justify-center rounded-2xl bg-gradient-to-br from-[var(--neon-purple)] to-[var(--neon-blue)] shadow-[0_0_30px_rgba(168,85,247,0.6)]",
                  children: e.jsx(j, {
                    className: "w-6 h-6 sm:w-7 sm:h-7 text-white",
                  }),
                }),
                e.jsx("h2", {
                  className:
                    "font-display font-bold text-xl sm:text-3xl tracking-tight bg-gradient-to-r from-[var(--neon-purple)] via-white to-[var(--neon-blue)] bg-clip-text text-transparent",
                  children: s("welcome.title"),
                }),
              ],
            }),
          ],
        }),
    })
  );
}
function B() {
  const { t: s } = m(),
    [t, r] = o.useState(!1);
  o.useEffect(() => {
    (localStorage.setItem("lj_current_game", "luckyjet"), r(!0));
  }, []);
  const { rounds: n, status: l, newestId: u } = w(),
    x = n;
  return e.jsxs(S, {
    children: [
      t && e.jsx(P, {}),
      e.jsx(C, {}),
      t && e.jsx(N, { rounds: n }),
      t && e.jsx(_, { rounds: x }),
      e.jsxs("main", {
        className: "glass rounded-3xl p-4 sm:p-6 lg:p-8",
        children: [
          e.jsxs("div", {
            className: "flex items-end justify-between flex-wrap gap-2 mb-5",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx("h2", {
                    className:
                      "font-display font-bold text-xl sm:text-2xl lg:text-3xl tracking-tight",
                    children: s("home.live_title"),
                  }),
                  e.jsx("p", {
                    className: "text-xs sm:text-sm text-muted-foreground mt-1",
                    children: s("home.live_desc"),
                  }),
                ],
              }),
              e.jsx("div", {
                className: "flex items-center gap-3 flex-wrap",
                children:
                  t &&
                  e.jsxs("div", {
                    className: "flex items-center gap-2 text-xs font-mono",
                    children: [
                      e.jsx("span", {
                        className: `w-2 h-2 rounded-full animate-pulse ${l === "live" ? "bg-[var(--neon-green)]" : l === "error" ? "bg-[var(--neon-orange)]" : "bg-[var(--neon-blue)]"}`,
                      }),
                      e.jsx("span", {
                        className: "text-muted-foreground",
                        children: s(
                          l === "live"
                            ? "header.live"
                            : l === "error"
                              ? "header.retry"
                              : "header.connecting",
                        ),
                      }),
                    ],
                  }),
              }),
            ],
          }),
          t && n.length === 0
            ? e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: Array.from({ length: 20 }).map((i, p) =>
                  e.jsx(
                    "div",
                    {
                      className:
                        "rounded-2xl h-[56px] sm:h-[64px] glass animate-pulse",
                      style: { animationDelay: `${p * 50}ms` },
                    },
                    p,
                  ),
                ),
              })
            : e.jsx(a.div, {
                layout: !0,
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: e.jsx(g, {
                  initial: !1,
                  children: x.map((i) =>
                    e.jsx(y, { round: i, isNew: i.id === u }, i.id),
                  ),
                }),
              }),
          e.jsxs("div", {
            className:
              "flex flex-wrap gap-4 sm:gap-6 mt-6 text-xs font-mono text-muted-foreground",
            children: [
              e.jsx(c, { className: "card-blue", label: s("legend.low") }),
              e.jsx(c, { className: "card-purple", label: s("legend.mid") }),
              e.jsx(c, { className: "card-orange", label: s("legend.high") }),
            ],
          }),
        ],
      }),
    ],
  });
}
function c({ className: s, label: t }) {
  return e.jsxs("div", {
    className: "flex items-center gap-2",
    children: [
      e.jsx("span", { className: `${s} w-3.5 h-3.5 rounded-full` }),
      e.jsx("span", { children: t }),
    ],
  });
}
export { B as component };
