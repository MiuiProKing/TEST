import {
  a7 as je,
  a8 as J,
  a9 as f,
  aa as Q,
  ab as E,
  ac as U,
  ad as q,
  ae as Y,
  af as we,
  ag as P,
  ah as ye,
  ai as Ne,
  aj as Z,
  ak as le,
  r as x,
  al as oe,
  am as ve,
  c as M,
  d as y,
  P as D,
  e as N,
  f as w,
  j as e,
  C as ke,
  N as _,
  T as ce,
  J as ee,
  S as _e,
  m as de,
} from "./index-C5ThNCN-.js";
import { B as Fe, F as z, D as Ce } from "./DashboardLayout-XCzqIJrp.js";
import { C as T } from "./circle-alert-Adrk4haQ.js";
import { T as he, Z as Se } from "./god-character.png.asset-BWFGzeh1.js";
import { E as Ee } from "./eye--TeH1aRg.js";
import { R as me } from "./radio-B9K4C2ja.js";
import { T as H, a as xe } from "./trending-up-B5K2KKMW.js";
import { C as R } from "./circle-check-B56GEMOe.js";
import { C as Re } from "./circle-x-Bj11oEwU.js";
import { B as Me, T as Te } from "./triangle-alert-CzDFXfJ_.js";
import { C as Be } from "./wrench-DMPf9Lxe.js";
import "./history-DU1SVBVB.js";
var Le = class extends je {
  constructor(t, s) {
    (super(),
      (this.options = s),
      (this.#s = t),
      (this.#i = null),
      (this.#a = J()),
      this.bindMethods(),
      this.setOptions(s));
  }
  #s;
  #e = void 0;
  #u = void 0;
  #t = void 0;
  #n;
  #d;
  #a;
  #i;
  #p;
  #h;
  #m;
  #l;
  #o;
  #r;
  #x = new Set();
  bindMethods() {
    this.refetch = this.refetch.bind(this);
  }
  onSubscribe() {
    this.listeners.size === 1 &&
      (this.#e.addObserver(this),
      te(this.#e, this.options) ? this.#c() : this.updateResult(),
      this.#j());
  }
  onUnsubscribe() {
    this.hasListeners() || this.destroy();
  }
  shouldFetchOnReconnect() {
    return V(this.#e, this.options, this.options.refetchOnReconnect);
  }
  shouldFetchOnWindowFocus() {
    return V(this.#e, this.options, this.options.refetchOnWindowFocus);
  }
  destroy() {
    ((this.listeners = new Set()),
      this.#w(),
      this.#y(),
      this.#e.removeObserver(this));
  }
  setOptions(t) {
    const s = this.options,
      a = this.#e;
    if (
      ((this.options = this.#s.defaultQueryOptions(t)),
      this.options.enabled !== void 0 &&
        typeof this.options.enabled != "boolean" &&
        typeof this.options.enabled != "function" &&
        typeof f(this.options.enabled, this.#e) != "boolean")
    )
      throw new Error(
        "Expected enabled to be a boolean or a callback that returns a boolean",
      );
    (this.#N(),
      this.#e.setOptions(this.options),
      s._defaulted &&
        !Q(this.options, s) &&
        this.#s
          .getQueryCache()
          .notify({
            type: "observerOptionsUpdated",
            query: this.#e,
            observer: this,
          }));
    const i = this.hasListeners();
    (i && se(this.#e, a, this.options, s) && this.#c(),
      this.updateResult(),
      i &&
        (this.#e !== a ||
          f(this.options.enabled, this.#e) !== f(s.enabled, this.#e) ||
          E(this.options.staleTime, this.#e) !== E(s.staleTime, this.#e)) &&
        this.#f());
    const r = this.#b();
    i &&
      (this.#e !== a ||
        f(this.options.enabled, this.#e) !== f(s.enabled, this.#e) ||
        r !== this.#r) &&
      this.#g(r);
  }
  getOptimisticResult(t) {
    const s = this.#s.getQueryCache().build(this.#s, t),
      a = this.createResult(s, t);
    return (
      Ie(this, a) &&
        ((this.#t = a), (this.#d = this.options), (this.#n = this.#e.state)),
      a
    );
  }
  getCurrentResult() {
    return this.#t;
  }
  trackResult(t, s) {
    return new Proxy(t, {
      get: (a, i) => (
        this.trackProp(i),
        s?.(i),
        i === "promise" &&
          (this.trackProp("data"),
          !this.options.experimental_prefetchInRender &&
            this.#a.status === "pending" &&
            this.#a.reject(
              new Error(
                "experimental_prefetchInRender feature flag is not enabled",
              ),
            )),
        Reflect.get(a, i)
      ),
    });
  }
  trackProp(t) {
    this.#x.add(t);
  }
  getCurrentQuery() {
    return this.#e;
  }
  refetch({ ...t } = {}) {
    return this.fetch({ ...t });
  }
  fetchOptimistic(t) {
    const s = this.#s.defaultQueryOptions(t),
      a = this.#s.getQueryCache().build(this.#s, s);
    return a.fetch().then(() => this.createResult(a, s));
  }
  fetch(t) {
    return this.#c({ ...t, cancelRefetch: t.cancelRefetch ?? !0 }).then(
      () => (this.updateResult(), this.#t),
    );
  }
  #c(t) {
    this.#N();
    let s = this.#e.fetch(this.options, t);
    return (t?.throwOnError || (s = s.catch(U)), s);
  }
  #f() {
    this.#w();
    const t = E(this.options.staleTime, this.#e);
    if (q.isServer() || this.#t.isStale || !Y(t)) return;
    const a = we(this.#t.dataUpdatedAt, t) + 1;
    this.#l = P.setTimeout(() => {
      this.#t.isStale || this.updateResult();
    }, a);
  }
  #b() {
    return (
      (typeof this.options.refetchInterval == "function"
        ? this.options.refetchInterval(this.#e)
        : this.options.refetchInterval) ?? !1
    );
  }
  #g(t) {
    (this.#y(),
      (this.#r = t),
      !(
        q.isServer() ||
        f(this.options.enabled, this.#e) === !1 ||
        !Y(this.#r) ||
        this.#r === 0
      ) &&
        (this.#o = P.setInterval(() => {
          (this.options.refetchIntervalInBackground || ye.isFocused()) &&
            this.#c();
        }, this.#r)));
  }
  #j() {
    (this.#f(), this.#g(this.#b()));
  }
  #w() {
    this.#l !== void 0 && (P.clearTimeout(this.#l), (this.#l = void 0));
  }
  #y() {
    this.#o !== void 0 && (P.clearInterval(this.#o), (this.#o = void 0));
  }
  createResult(t, s) {
    const a = this.#e,
      i = this.options,
      r = this.#t,
      l = this.#n,
      n = this.#d,
      c = t !== a ? t.state : this.#u,
      { state: m } = t;
    let o = { ...m },
      b = !1,
      d;
    if (s._optimisticResults) {
      const p = this.hasListeners(),
        S = !p && te(t, s),
        L = p && se(t, a, s, i);
      ((S || L) && (o = { ...o, ...Ne(m.data, t.options) }),
        s._optimisticResults === "isRestoring" && (o.fetchStatus = "idle"));
    }
    let { error: j, errorUpdatedAt: F, status: u } = o;
    d = o.data;
    let B = !1;
    if (s.placeholderData !== void 0 && d === void 0 && u === "pending") {
      let p;
      (r?.isPlaceholderData && s.placeholderData === n?.placeholderData
        ? ((p = r.data), (B = !0))
        : (p =
            typeof s.placeholderData == "function"
              ? s.placeholderData(this.#m?.state.data, this.#m)
              : s.placeholderData),
        p !== void 0 && ((u = "success"), (d = Z(r?.data, p, s)), (b = !0)));
    }
    if (s.select && d !== void 0 && !B)
      if (r && d === l?.data && s.select === this.#p) d = this.#h;
      else
        try {
          ((this.#p = s.select),
            (d = s.select(d)),
            (d = Z(r?.data, d, s)),
            (this.#h = d),
            (this.#i = null));
        } catch (p) {
          this.#i = p;
        }
    this.#i && ((j = this.#i), (d = this.#h), (F = Date.now()), (u = "error"));
    const v = o.fetchStatus === "fetching",
      C = u === "pending",
      $ = u === "error",
      X = C && v,
      G = d !== void 0,
      g = {
        status: u,
        fetchStatus: o.fetchStatus,
        isPending: C,
        isSuccess: u === "success",
        isError: $,
        isInitialLoading: X,
        isLoading: X,
        data: d,
        dataUpdatedAt: o.dataUpdatedAt,
        error: j,
        errorUpdatedAt: F,
        failureCount: o.fetchFailureCount,
        failureReason: o.fetchFailureReason,
        errorUpdateCount: o.errorUpdateCount,
        isFetched: t.isFetched(),
        isFetchedAfterMount:
          o.dataUpdateCount > c.dataUpdateCount ||
          o.errorUpdateCount > c.errorUpdateCount,
        isFetching: v,
        isRefetching: v && !C,
        isLoadingError: $ && !G,
        isPaused: o.fetchStatus === "paused",
        isPlaceholderData: b,
        isRefetchError: $ && G,
        isStale: K(t, s),
        refetch: this.refetch,
        promise: this.#a,
        isEnabled: f(s.enabled, t) !== !1,
      };
    if (this.options.experimental_prefetchInRender) {
      const p = g.data !== void 0,
        S = g.status === "error" && !p,
        L = (I) => {
          S ? I.reject(g.error) : p && I.resolve(g.data);
        },
        W = () => {
          const I = (this.#a = g.promise = J());
          L(I);
        },
        O = this.#a;
      switch (O.status) {
        case "pending":
          t.queryHash === a.queryHash && L(O);
          break;
        case "fulfilled":
          (S || g.data !== O.value) && W();
          break;
        case "rejected":
          (!S || g.error !== O.reason) && W();
          break;
      }
    }
    return g;
  }
  updateResult() {
    const t = this.#t,
      s = this.createResult(this.#e, this.options);
    if (
      ((this.#n = this.#e.state),
      (this.#d = this.options),
      this.#n.data !== void 0 && (this.#m = this.#e),
      Q(s, t))
    )
      return;
    this.#t = s;
    const a = () => {
      if (!t) return !0;
      const { notifyOnChangeProps: i } = this.options,
        r = typeof i == "function" ? i() : i;
      if (r === "all" || (!r && !this.#x.size)) return !0;
      const l = new Set(r ?? this.#x);
      return (
        this.options.throwOnError && l.add("error"),
        Object.keys(this.#t).some((n) => {
          const h = n;
          return this.#t[h] !== t[h] && l.has(h);
        })
      );
    };
    this.#v({ listeners: a() });
  }
  #N() {
    const t = this.#s.getQueryCache().build(this.#s, this.options);
    if (t === this.#e) return;
    const s = this.#e;
    ((this.#e = t),
      (this.#u = t.state),
      this.hasListeners() && (s?.removeObserver(this), t.addObserver(this)));
  }
  onQueryUpdate() {
    (this.updateResult(), this.hasListeners() && this.#j());
  }
  #v(t) {
    le.batch(() => {
      (t.listeners &&
        this.listeners.forEach((s) => {
          s(this.#t);
        }),
        this.#s
          .getQueryCache()
          .notify({ query: this.#e, type: "observerResultsUpdated" }));
    });
  }
};
function Oe(t, s) {
  return (
    f(s.enabled, t) !== !1 &&
    t.state.data === void 0 &&
    !(t.state.status === "error" && f(s.retryOnMount, t) === !1)
  );
}
function te(t, s) {
  return Oe(t, s) || (t.state.data !== void 0 && V(t, s, s.refetchOnMount));
}
function V(t, s, a) {
  if (f(s.enabled, t) !== !1 && E(s.staleTime, t) !== "static") {
    const i = typeof a == "function" ? a(t) : a;
    return i === "always" || (i !== !1 && K(t, s));
  }
  return !1;
}
function se(t, s, a, i) {
  return (
    (t !== s || f(i.enabled, t) === !1) &&
    (!a.suspense || t.state.status !== "error") &&
    K(t, a)
  );
}
function K(t, s) {
  return f(s.enabled, t) !== !1 && t.isStaleByTime(E(s.staleTime, t));
}
function Ie(t, s) {
  return !Q(t.getCurrentResult(), s);
}
var ue = x.createContext(!1),
  Pe = () => x.useContext(ue);
ue.Provider;
function Ae() {
  let t = !1;
  return {
    clearReset: () => {
      t = !1;
    },
    reset: () => {
      t = !0;
    },
    isReset: () => t,
  };
}
var De = x.createContext(Ae()),
  $e = () => x.useContext(De),
  Qe = (t, s, a) => {
    const i =
      a?.state.error && typeof t.throwOnError == "function"
        ? oe(t.throwOnError, [a.state.error, a])
        : t.throwOnError;
    (t.suspense || t.experimental_prefetchInRender || i) &&
      (s.isReset() || (t.retryOnMount = !1));
  },
  Ue = (t) => {
    x.useEffect(() => {
      t.clearReset();
    }, [t]);
  },
  qe = ({
    result: t,
    errorResetBoundary: s,
    throwOnError: a,
    query: i,
    suspense: r,
  }) =>
    t.isError &&
    !s.isReset() &&
    !t.isFetching &&
    i &&
    ((r && t.data === void 0) || oe(a, [t.error, i])),
  Ve = (t) => {
    if (t.suspense) {
      const a = (r) => (r === "static" ? r : Math.max(r ?? 1e3, 1e3)),
        i = t.staleTime;
      ((t.staleTime = typeof i == "function" ? (...r) => a(i(...r)) : a(i)),
        typeof t.gcTime == "number" && (t.gcTime = Math.max(t.gcTime, 1e3)));
    }
  },
  ze = (t, s) => t.isLoading && t.isFetching && !s,
  He = (t, s) => t?.suspense && s.isPending,
  ae = (t, s, a) =>
    s.fetchOptimistic(t).catch(() => {
      a.clearReset();
    });
function Ke(t, s, a) {
  const i = Pe(),
    r = $e(),
    l = ve(),
    n = l.defaultQueryOptions(t);
  l.getDefaultOptions().queries?._experimental_beforeQuery?.(n);
  const h = l.getQueryCache().get(n.queryHash);
  ((n._optimisticResults = i ? "isRestoring" : "optimistic"),
    Ve(n),
    Qe(n, r, h),
    Ue(r));
  const c = !l.getQueryCache().get(n.queryHash),
    [m] = x.useState(() => new s(l, n)),
    o = m.getOptimisticResult(n),
    b = !i && t.subscribed !== !1;
  if (
    (x.useSyncExternalStore(
      x.useCallback(
        (d) => {
          const j = b ? m.subscribe(le.batchCalls(d)) : U;
          return (m.updateResult(), j);
        },
        [m, b],
      ),
      () => m.getCurrentResult(),
      () => m.getCurrentResult(),
    ),
    x.useEffect(() => {
      m.setOptions(n);
    }, [n, m]),
    He(n, o))
  )
    throw ae(n, m, r);
  if (
    qe({
      result: o,
      errorResetBoundary: r,
      throwOnError: n.throwOnError,
      query: h,
      suspense: n.suspense,
    })
  )
    throw o.error;
  return (
    l.getDefaultOptions().queries?._experimental_afterQuery?.(n, o),
    n.experimental_prefetchInRender &&
      !q.isServer() &&
      ze(o, i) &&
      (c ? ae(n, m, r) : h?.promise)?.catch(U).finally(() => {
        m.updateResult();
      }),
    n.notifyOnChangeProps ? o : m.trackResult(o)
  );
}
function k(t, s) {
  return Ke(t, Le);
}
const Xe = [
    ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
    [
      "path",
      {
        d: "M17 17H4a1 1 0 0 1-.74-1.673C4.59 13.956 6 12.499 6 8a6 6 0 0 1 .258-1.742",
        key: "178tsu",
      },
    ],
    ["path", { d: "m2 2 20 20", key: "1ooewy" }],
    [
      "path",
      {
        d: "M8.668 3.01A6 6 0 0 1 18 8c0 2.687.77 4.653 1.707 6.05",
        key: "1hqiys",
      },
    ],
  ],
  Ge = M("bell-off", Xe);
const We = [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]],
  Je = M("chevron-right", We);
const Ye = [
    ["path", { d: "m15 10 5 5-5 5", key: "qqa56n" }],
    ["path", { d: "M4 4v7a4 4 0 0 0 4 4h12", key: "z08zvw" }],
  ],
  Ze = M("corner-down-right", Ye);
const et = [
    ["path", { d: "m12 14 4-4", key: "9kzdfg" }],
    ["path", { d: "M3.34 19a10 10 0 1 1 17.32 0", key: "19p75a" }],
  ],
  pe = M("gauge", et);
const tt = [
    ["path", { d: "M12 3v18", key: "108xh3" }],
    ["path", { d: "m19 8 3 8a5 5 0 0 1-6 0zV7", key: "zcdpyk" }],
    ["path", { d: "M3 7h1a17 17 0 0 0 8-2 17 17 0 0 0 8 2h1", key: "1yorad" }],
    ["path", { d: "m5 8 3 8a5 5 0 0 1-6 0zV7", key: "eua70x" }],
    ["path", { d: "M7 21h10", key: "1b0cd5" }],
  ],
  st = M("scale", tt),
  at = y({ method: "GET" })
    .middleware([D])
    .handler(
      N("2c798f3c36ac67f36c0ab57d886fafb07f9bf70bbdb2e7046c2a408506d5502b"),
    ),
  it = y({ method: "GET" })
    .middleware([D])
    .handler(
      N("8b13d669344af4630fc757bbf513ea8bad7965ef0401f0d06db7363af6e0427e"),
    ),
  rt = y({ method: "POST" })
    .middleware([D])
    .handler(
      N("f60c2806b4362b3a919e4d91a7355cf419b35cbb30a5183009485898cfb1a497"),
    ),
  nt =
    "BGFlJhr9BACBRXf3zffklgkspIMptUTnzX3Y3SKSw9D1GQg6UfcX6aTlSJiSt7sDDeiTb1zu2ZVAXoRpOaMfQYo";
function lt(t) {
  const s = "=".repeat((4 - (t.length % 4)) % 4),
    a = (t + s).replace(/-/g, "+").replace(/_/g, "/"),
    i = atob(a),
    r = new Uint8Array(i.length);
  for (let l = 0; l < i.length; l++) r[l] = i.charCodeAt(l);
  return r;
}
function ot() {
  const t = w(rt),
    [s, a] = x.useState("idle");
  x.useEffect(() => {
    if (!(typeof window > "u")) {
      if (
        !("serviceWorker" in navigator) ||
        !("PushManager" in window) ||
        !("Notification" in window)
      ) {
        a("unsupported");
        return;
      }
      Notification.permission === "denied"
        ? a("denied")
        : navigator.serviceWorker.getRegistration().then((r) => {
            r?.pushManager.getSubscription().then((l) => {
              l && a("subscribed");
            });
          });
    }
  }, []);
  async function i() {
    a("loading");
    try {
      if ((await Notification.requestPermission()) !== "granted") {
        a("denied");
        return;
      }
      const l = await navigator.serviceWorker.register("/sw.js");
      await navigator.serviceWorker.ready;
      let n = await l.pushManager.getSubscription();
      n ||
        (n = await l.pushManager.subscribe({
          userVisibleOnly: !0,
          applicationServerKey: lt(nt),
        }));
      const h = n.toJSON();
      (await t({
        data: {
          endpoint: n.endpoint,
          p256dh: h.keys?.p256dh ?? "",
          auth: h.keys?.auth ?? "",
          userAgent: navigator.userAgent,
        },
      }),
        a("subscribed"));
    } catch (r) {
      (console.error("push subscribe failed", r), a("idle"));
    }
  }
  return s === "unsupported"
    ? null
    : s === "subscribed"
      ? e.jsxs("div", {
          className:
            "inline-flex items-center gap-2 text-xs font-mono text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-full px-3 py-1.5",
          children: [
            e.jsx(ke, { className: "w-3.5 h-3.5" }),
            " Notifications activées",
          ],
        })
      : s === "denied"
        ? e.jsxs("div", {
            className:
              "inline-flex items-center gap-2 text-xs font-mono text-white/50 bg-white/[0.04] rounded-full px-3 py-1.5",
            children: [
              e.jsx(Ge, { className: "w-3.5 h-3.5" }),
              " Notifications bloquées",
            ],
          })
        : e.jsxs("button", {
            onClick: i,
            disabled: s === "loading",
            className:
              "inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] px-3 py-1.5 text-xs font-bold hover:opacity-90 disabled:opacity-60",
            children: [
              s === "loading"
                ? e.jsx(_, { className: "w-3.5 h-3.5 animate-spin" })
                : e.jsx(Fe, { className: "w-3.5 h-3.5" }),
              "Activer les notifications VIP",
            ],
          });
}
const ct = y({ method: "GET" }).handler(
    N("a90183e11f08ca05875ba571d8e2cfd3ebc97178dc707b18e13dc553efbe5af0"),
  ),
  dt = y({ method: "GET" }).handler(
    N("0b716197aa0993a384fd3bc158a446c9851f7e8d30b2d51c85987c2c887dd149"),
  ),
  ht = y({ method: "GET" }).handler(
    N("b3622716819ab08bfb6cb44a4e4dccb94084013cf30846fe9703598f58c26470"),
  ),
  mt = {
    "1X2": "Résultat du match",
    double_chance: "Double chance",
    goals: "Nombre de buts",
    btts: "Les deux marquent",
    corners: "Corners",
    cards: "Cartons",
  };
function xt(t) {
  return new Date(t).toLocaleString("fr-FR", {
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}
function ut(t) {
  return t >= 80
    ? "text-emerald-400"
    : t >= 65
      ? "text-[#FF8C00]"
      : "text-white/80";
}
function ie({ url: t, name: s }) {
  return t
    ? e.jsx("img", {
        src: t,
        alt: s,
        className: "h-8 w-8 shrink-0 object-contain",
        loading: "lazy",
      })
    : e.jsx("div", {
        className:
          "h-8 w-8 shrink-0 rounded-full bg-white/[0.06] flex items-center justify-center text-[10px] font-bold",
        children: s.slice(0, 2).toUpperCase(),
      });
}
function pt({ pick: t }) {
  const [s, a] = x.useState(!1);
  return e.jsxs("div", {
    className:
      "glass rounded-2xl p-4 border border-white/[0.06] flex flex-col gap-3",
    children: [
      e.jsxs("div", {
        className:
          "flex items-center justify-between gap-3 text-[10px] text-white/50",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2 min-w-0",
            children: [
              t.league_logo &&
                e.jsx("img", {
                  src: t.league_logo,
                  alt: "",
                  className: "h-4 w-4 object-contain",
                  loading: "lazy",
                }),
              e.jsx("span", {
                className: "truncate font-mono",
                children: [t.country, t.league_name]
                  .filter(Boolean)
                  .join(" · "),
              }),
            ],
          }),
          e.jsxs("span", {
            className:
              "shrink-0 inline-flex items-center gap-1 font-mono text-white/60",
            children: [e.jsx(ce, { className: "w-3 h-3" }), " ", xt(t.kickoff)],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2.5 min-w-0",
            children: [
              e.jsx(ie, { url: t.home_logo, name: t.home_name }),
              e.jsx("span", {
                className: "font-semibold text-sm truncate",
                children: t.home_name,
              }),
            ],
          }),
          e.jsx("span", {
            className: "text-white/40 text-xs font-mono",
            children: "vs",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2.5 min-w-0 justify-end",
            children: [
              e.jsx("span", {
                className: "font-semibold text-sm truncate text-right",
                children: t.away_name,
              }),
              e.jsx(ie, { url: t.away_logo, name: t.away_name }),
            ],
          }),
        ],
      }),
      s
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsxs("div", {
                className:
                  "rounded-xl bg-white/[0.04] border border-white/[0.06] p-3",
                children: [
                  e.jsx("p", {
                    className:
                      "text-[10px] uppercase tracking-widest text-white/50 font-mono",
                    children: mt[t.market],
                  }),
                  e.jsx("p", {
                    className: "font-display font-black text-base mt-0.5",
                    children: t.selection,
                  }),
                  e.jsxs("div", {
                    className: "flex items-center gap-4 mt-2",
                    children: [
                      e.jsxs("span", {
                        className: `font-display font-black text-2xl ${ut(t.probability)}`,
                        children: [t.probability, "%"],
                      }),
                      e.jsxs("span", {
                        className:
                          "inline-flex items-center gap-1 text-[11px] font-mono text-white/60",
                        children: [
                          e.jsx(pe, { className: "w-3 h-3" }),
                          " fiabilité ",
                          t.confidence,
                          "%",
                        ],
                      }),
                      t.probability >= 80 &&
                        e.jsxs("span", {
                          className:
                            "inline-flex items-center gap-1 text-[11px] font-mono text-[#FF8C00]",
                          children: [
                            e.jsx(z, { className: "w-3 h-3" }),
                            " forte proba",
                          ],
                        }),
                    ],
                  }),
                  e.jsx("div", {
                    className:
                      "h-1.5 rounded-full bg-white/5 overflow-hidden mt-2",
                    children: e.jsx("div", {
                      className:
                        "h-full bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                      style: { width: `${t.probability}%` },
                    }),
                  }),
                ],
              }),
              e.jsx("p", {
                className:
                  "text-xs text-white/70 italic border-l-2 border-[#E040FB]/40 pl-3",
                children: t.rationale,
              }),
              t.alternatives?.length > 0 &&
                e.jsx("div", {
                  className: "flex flex-wrap gap-1.5",
                  children: t.alternatives.map((i, r) =>
                    e.jsxs(
                      "span",
                      {
                        className:
                          "text-[10px] font-mono px-2 py-1 rounded-lg bg-white/[0.04] border border-white/[0.06] text-white/60",
                        children: [
                          i.selection,
                          " · ",
                          Math.round(i.probability),
                          "%",
                        ],
                      },
                      r,
                    ),
                  ),
                }),
            ],
          })
        : e.jsxs("button", {
            onClick: () => a(!0),
            className:
              "w-full flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-black uppercase tracking-widest bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] text-white shadow-[0_0_20px_rgba(224,64,251,0.3)] hover:opacity-90 transition",
            children: [
              e.jsx(Ee, { className: "w-4 h-4" }),
              " Voir le pronostic",
            ],
          }),
    ],
  });
}
function ft(t) {
  const s = new Map();
  for (const a of t) {
    const i = `${a.country ?? ""}·${a.league_name ?? "Autres"}`;
    let r = s.get(i);
    (r ||
      ((r = {
        key: i,
        label:
          [a.country, a.league_name].filter(Boolean).join(" · ") || "Autres",
        logo: a.league_logo,
        picks: [],
      }),
      s.set(i, r)),
      r.picks.push(a));
  }
  return [...s.values()].sort((a, i) => i.picks.length - a.picks.length);
}
function bt({ group: t }) {
  return e.jsxs("section", {
    className: "space-y-3",
    children: [
      e.jsxs("header", {
        className: "flex items-center gap-2.5 px-1",
        children: [
          t.logo
            ? e.jsx("img", {
                src: t.logo,
                alt: "",
                className: "h-6 w-6 object-contain",
                loading: "lazy",
              })
            : e.jsx(he, { className: "w-5 h-5 text-[#E040FB]" }),
          e.jsx("h3", {
            className:
              "font-display font-black text-sm uppercase tracking-wide",
            children: t.label,
          }),
          e.jsxs("span", {
            className:
              "text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#E040FB]/15 text-[#E040FB] border border-[#E040FB]/30",
            children: [t.picks.length, " match", t.picks.length > 1 ? "s" : ""],
          }),
        ],
      }),
      e.jsx("div", {
        className: "grid grid-cols-1 lg:grid-cols-2 gap-3",
        children: t.picks.map((s) => e.jsx(pt, { pick: s }, s.match_key)),
      }),
    ],
  });
}
function gt() {
  const t = w(ct),
    [s, a] = x.useState(null),
    i = k({
      queryKey: ["sport", "smart-picks"],
      queryFn: () => t(),
      refetchInterval: 5 * 6e4,
    }),
    r = i.data?.ok ? i.data.picks : [],
    l = x.useMemo(() => ft(r), [r]);
  if (i.isLoading)
    return e.jsxs("div", {
      className:
        "glass rounded-2xl p-8 flex items-center justify-center gap-3 text-white/60",
      children: [
        e.jsx(_, { className: "w-5 h-5 animate-spin" }),
        e.jsx("span", {
          className: "text-sm font-mono",
          children: "Analyse des matchs...",
        }),
      ],
    });
  if (!r.length)
    return e.jsxs("div", {
      className:
        "glass rounded-2xl p-8 flex items-start gap-3 border border-white/[0.06]",
      children: [
        e.jsx(T, { className: "w-5 h-5 text-white/60 shrink-0 mt-0.5" }),
        e.jsxs("div", {
          children: [
            e.jsx("p", {
              className: "text-sm font-semibold",
              children: "Aucun pronostic Flashscore/Forebet disponible",
            }),
            e.jsx("p", {
              className: "text-xs text-white/60 mt-1",
              children:
                "Les analyses sont rafraîchies plusieurs fois par jour. Reviens dans quelques minutes.",
            }),
          ],
        }),
      ],
    });
  const n = s ?? l[0]?.key ?? null,
    h = n ? l.filter((c) => c.key === n) : l;
  return e.jsxs("div", {
    className: "space-y-5",
    children: [
      e.jsxs("p", {
        className: "text-xs text-white/50 font-mono px-1",
        children: [
          r.length,
          " matchs analysés · ",
          l.length,
          " championnat",
          l.length > 1 ? "s" : "",
          " · données Flashscore & Forebet fusionnées par l'IA · un seul pari retenu par match, celui à plus forte probabilité.",
        ],
      }),
      e.jsx("div", {
        className:
          "flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
        children: l.map((c) =>
          e.jsxs(
            "button",
            {
              onClick: () => a(c.key),
              className: `shrink-0 inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold border transition ${n === c.key ? "bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] text-white border-transparent shadow-[0_0_16px_rgba(224,64,251,0.35)]" : "bg-white/[0.04] text-white/60 border-white/[0.08] hover:text-white"}`,
              children: [
                c.logo &&
                  e.jsx("img", {
                    src: c.logo,
                    alt: "",
                    className: "h-4 w-4 object-contain",
                    loading: "lazy",
                  }),
                c.label,
                e.jsx("span", {
                  className: "text-[10px] font-mono opacity-70",
                  children: c.picks.length,
                }),
                e.jsx(Je, { className: "w-3 h-3 opacity-50" }),
              ],
            },
            c.key,
          ),
        ),
      }),
      e.jsx("div", {
        className: "space-y-7",
        children: h.map((c) => e.jsx(bt, { group: c }, c.key)),
      }),
    ],
  });
}
function re({ url: t, name: s }) {
  return t
    ? e.jsx("img", {
        src: t,
        alt: s,
        className: "h-8 w-8 shrink-0 object-contain",
        loading: "lazy",
      })
    : e.jsx("div", {
        className:
          "h-8 w-8 shrink-0 rounded-full bg-white/[0.06] flex items-center justify-center text-[10px] font-bold",
        children: s.slice(0, 2).toUpperCase(),
      });
}
const jt = {
  "1X2": "Résultat du match",
  double_chance: "Double chance",
  goals: "Nombre de buts",
  btts: "Les deux marquent",
};
function wt(t) {
  return t >= 80
    ? "text-emerald-400"
    : t >= 65
      ? "text-[#FF8C00]"
      : "text-white/80";
}
function yt({ m: t }) {
  return e.jsxs("div", {
    className: "glass rounded-2xl p-4 border border-red-500/20 space-y-3",
    children: [
      e.jsxs("div", {
        className:
          "flex items-center justify-between gap-3 text-[10px] text-white/50",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2 min-w-0",
            children: [
              t.leagueLogo &&
                e.jsx("img", {
                  src: t.leagueLogo,
                  alt: "",
                  className: "h-4 w-4 object-contain",
                  loading: "lazy",
                }),
              e.jsx("span", {
                className: "truncate font-mono",
                children: [t.country, t.league].filter(Boolean).join(" · "),
              }),
            ],
          }),
          e.jsxs("span", {
            className:
              "shrink-0 inline-flex items-center gap-1 rounded-full bg-red-500/15 border border-red-400/30 px-2 py-0.5 text-red-300 font-bold",
            children: [
              e.jsx("span", {
                className: "h-1.5 w-1.5 rounded-full bg-red-400 animate-pulse",
              }),
              t.minute != null ? `${t.minute}'` : "LIVE",
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2.5 min-w-0",
            children: [
              e.jsx(re, { url: t.homeLogo, name: t.home }),
              e.jsx("span", {
                className: "font-semibold text-sm truncate",
                children: t.home,
              }),
            ],
          }),
          e.jsxs("span", {
            className: "text-xl font-black font-mono text-emerald-300",
            children: [t.scoreHome ?? 0, " - ", t.scoreAway ?? 0],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2.5 min-w-0 justify-end",
            children: [
              e.jsx("span", {
                className: "font-semibold text-sm truncate text-right",
                children: t.away,
              }),
              e.jsx(re, { url: t.awayLogo, name: t.away }),
            ],
          }),
        ],
      }),
      t.pick &&
        e.jsxs("div", {
          className:
            "rounded-xl bg-white/[0.04] border border-white/[0.06] p-3 space-y-2",
          children: [
            e.jsxs("p", {
              className:
                "text-[10px] uppercase tracking-widest text-white/50 font-mono",
              children: [
                "Pronostic live · ",
                jt[t.pick.market] ?? t.pick.market,
              ],
            }),
            e.jsx("p", {
              className: "font-display font-black text-base",
              children: t.pick.selection,
            }),
            e.jsxs("div", {
              className: "flex items-center gap-4",
              children: [
                e.jsxs("span", {
                  className: `font-display font-black text-2xl ${wt(t.pick.probability)}`,
                  children: [t.pick.probability, "%"],
                }),
                e.jsxs("span", {
                  className:
                    "inline-flex items-center gap-1 text-[11px] font-mono text-white/60",
                  children: [
                    e.jsx(pe, { className: "w-3 h-3" }),
                    " fiabilité ",
                    t.pick.confidence,
                    "%",
                  ],
                }),
              ],
            }),
            e.jsx("div", {
              className: "h-1.5 rounded-full bg-white/5 overflow-hidden",
              children: e.jsx("div", {
                className:
                  "h-full bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                style: { width: `${t.pick.probability}%` },
              }),
            }),
            e.jsx("p", {
              className: "text-[11px] text-white/60 font-mono",
              children: t.pick.rationale,
            }),
            (t.pick.alternatives?.length ?? 0) > 0 &&
              e.jsx("div", {
                className: "flex flex-wrap gap-1.5",
                children: (t.pick.alternatives ?? []).map((s, a) =>
                  e.jsxs(
                    "span",
                    {
                      className:
                        "text-[10px] font-mono px-2 py-1 rounded-lg bg-white/[0.04] border border-white/[0.06] text-white/60",
                      children: [s.selection, " · ", s.probability, "%"],
                    },
                    a,
                  ),
                ),
              }),
            (t.pick.correctScores?.length ?? 0) > 0 &&
              e.jsxs("div", {
                className: "pt-2 border-t border-white/[0.06] space-y-1.5",
                children: [
                  e.jsxs("p", {
                    className:
                      "text-[10px] uppercase tracking-widest text-white/50 font-mono flex items-center gap-1.5",
                    children: [
                      e.jsx(H, { className: "w-3 h-3" }),
                      " Scores exacts probables",
                    ],
                  }),
                  e.jsx("div", {
                    className: "flex flex-wrap gap-1.5",
                    children: (t.pick.correctScores ?? []).map((s, a) =>
                      e.jsxs(
                        "span",
                        {
                          className: `text-[11px] font-mono font-bold px-2 py-1 rounded-lg border ${a === 0 ? "bg-[#FF8C00]/15 border-[#FF8C00]/40 text-[#FFB347]" : "bg-white/[0.04] border-white/[0.06] text-white/70"}`,
                          children: [s.score, " · ", s.probability, "%"],
                        },
                        s.score,
                      ),
                    ),
                  }),
                ],
              }),
          ],
        }),
    ],
  });
}
class Nt extends x.Component {
  state = { failed: !1 };
  static getDerivedStateFromError() {
    return { failed: !0 };
  }
  render() {
    return this.state.failed
      ? e.jsxs("div", {
          className:
            "glass rounded-2xl p-8 flex items-start gap-3 border border-white/[0.06]",
          children: [
            e.jsx(T, { className: "w-5 h-5 text-white/60 shrink-0 mt-0.5" }),
            e.jsxs("div", {
              children: [
                e.jsx("p", {
                  className: "text-sm font-semibold",
                  children: "Analyse live momentanément indisponible",
                }),
                e.jsx("p", {
                  className: "text-xs text-white/60 mt-1",
                  children: "Réessaie dans quelques instants.",
                }),
              ],
            }),
          ],
        })
      : this.props.children;
  }
}
function vt() {
  const t = w(dt),
    s = k({
      queryKey: ["sport", "live"],
      queryFn: () => t(),
      refetchInterval: 3e4,
      retry: 1,
    });
  if (s.isLoading)
    return e.jsxs("div", {
      className:
        "glass rounded-2xl p-8 flex items-center justify-center gap-3 text-white/60",
      children: [
        e.jsx(_, { className: "w-5 h-5 animate-spin" }),
        e.jsx("span", {
          className: "text-sm font-mono",
          children: "Chargement des matchs en direct...",
        }),
      ],
    });
  const a = s.data?.ok ? (s.data.matches ?? []) : [];
  return a.length
    ? e.jsxs("div", {
        className: "space-y-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2 px-1",
            children: [
              e.jsx(me, { className: "w-4 h-4 text-red-400" }),
              e.jsx("h2", {
                className:
                  "font-display font-black text-sm uppercase tracking-widest text-white/90",
                children: "Matchs en direct",
              }),
              e.jsxs("span", {
                className: "text-[10px] font-mono text-white/40 ml-auto",
                children: [a.length, " en cours"],
              }),
            ],
          }),
          e.jsx("div", {
            className: "grid grid-cols-1 lg:grid-cols-2 gap-3",
            children: a.map((i) => e.jsx(yt, { m: i }, i.id)),
          }),
        ],
      })
    : e.jsxs("div", {
        className:
          "glass rounded-2xl p-8 flex items-start gap-3 border border-white/[0.06]",
        children: [
          e.jsx(T, { className: "w-5 h-5 text-white/60 shrink-0 mt-0.5" }),
          e.jsxs("div", {
            children: [
              e.jsx("p", {
                className: "text-sm font-semibold",
                children: "Aucun match en direct actuellement",
              }),
              e.jsx("p", {
                className: "text-xs text-white/60 mt-1",
                children:
                  "Les scores s'affichent ici automatiquement dès le coup d'envoi.",
              }),
            ],
          }),
        ],
      });
}
function kt() {
  return e.jsx(Nt, { children: e.jsx(vt, {}) });
}
function _t(t) {
  return new Date(t).toLocaleString("fr-FR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}
function ne({ url: t, name: s }) {
  return t
    ? e.jsx("img", {
        src: t,
        alt: s,
        className: "h-7 w-7 shrink-0 object-contain",
        loading: "lazy",
      })
    : e.jsx("div", {
        className:
          "h-7 w-7 shrink-0 rounded-full bg-white/[0.06] flex items-center justify-center text-[10px] font-bold",
        children: s.slice(0, 2).toUpperCase(),
      });
}
function Ft({ p: t }) {
  const s = t.status === "won";
  return e.jsxs("div", {
    className: `glass rounded-2xl p-4 border flex flex-col gap-2 ${s ? "border-emerald-500/30" : "border-red-500/20"}`,
    children: [
      e.jsxs("div", {
        className:
          "flex items-center justify-between gap-3 text-[10px] text-white/50",
        children: [
          e.jsx("span", {
            className: "truncate font-mono",
            children: [t.country, t.league_name].filter(Boolean).join(" · "),
          }),
          e.jsx("span", {
            className: "shrink-0 font-mono",
            children: _t(t.kickoff),
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2 min-w-0",
            children: [
              e.jsx(ne, { url: t.home_logo, name: t.home_name }),
              e.jsx("span", {
                className: "font-semibold text-sm truncate",
                children: t.home_name,
              }),
            ],
          }),
          e.jsxs("span", {
            className: "font-display font-black text-base",
            children: [t.actual_home ?? "-", " - ", t.actual_away ?? "-"],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2 min-w-0 justify-end",
            children: [
              e.jsx("span", {
                className: "font-semibold text-sm truncate text-right",
                children: t.away_name,
              }),
              e.jsx(ne, { url: t.away_logo, name: t.away_name }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className:
          "flex items-center justify-between gap-3 rounded-xl bg-white/[0.04] border border-white/[0.06] px-3 py-2",
        children: [
          e.jsx("span", {
            className: "text-xs font-semibold truncate",
            children: t.selection,
          }),
          e.jsxs("span", {
            className: `shrink-0 inline-flex items-center gap-1 text-[11px] font-black uppercase tracking-wider ${s ? "text-emerald-400" : "text-red-400"}`,
            children: [
              s
                ? e.jsx(R, { className: "w-4 h-4" })
                : e.jsx(Re, { className: "w-4 h-4" }),
              s ? "Validé" : "Perdu",
              " · ",
              t.probability,
              "%",
            ],
          }),
        ],
      }),
    ],
  });
}
function Ct() {
  const t = w(ht),
    s = k({
      queryKey: ["sport", "smart-picks", "validated"],
      queryFn: () => t(),
      refetchInterval: 5 * 6e4,
    });
  if (s.isLoading)
    return e.jsxs("div", {
      className:
        "glass rounded-2xl p-6 flex items-center justify-center gap-3 text-white/60",
      children: [
        e.jsx(_, { className: "w-4 h-4 animate-spin" }),
        e.jsx("span", {
          className: "text-xs font-mono",
          children: "Vérification des résultats…",
        }),
      ],
    });
  const a = s.data?.ok ? s.data.picks : [];
  if (!a.length)
    return e.jsxs("div", {
      className:
        "glass rounded-2xl p-6 flex items-start gap-3 border border-white/[0.06]",
      children: [
        e.jsx(T, { className: "w-5 h-5 text-white/60 shrink-0 mt-0.5" }),
        e.jsxs("div", {
          children: [
            e.jsx("p", {
              className: "text-sm font-semibold",
              children: "Aucun pronostic vérifié pour l'instant",
            }),
            e.jsx("p", {
              className: "text-xs text-white/60 mt-1",
              children:
                "Les résultats arrivent dès que les matchs sont terminés.",
            }),
          ],
        }),
      ],
    });
  const i = s.data?.ok ? s.data.won : 0,
    r = i + (s.data?.ok ? s.data.lost : 0),
    l = r ? Math.round((i / r) * 100) : 0;
  return e.jsxs("div", {
    className: "space-y-3",
    children: [
      e.jsxs("p", {
        className: "text-xs font-mono text-white/60 px-1",
        children: [
          i,
          "/",
          r,
          " pronostics gagnés · taux de réussite ",
          e.jsxs("span", {
            className: "text-emerald-400 font-bold",
            children: [l, "%"],
          }),
        ],
      }),
      e.jsx("div", {
        className: "grid grid-cols-1 lg:grid-cols-2 gap-3",
        children: a.map((n) => e.jsx(Ft, { p: n }, n.match_key)),
      }),
    ],
  });
}
const St = y({ method: "GET" })
  .middleware([D])
  .handler(
    N("f3457ebbb950aa17306760cce52d6659d3b5c38b0bcd14d4e5c463011e63314a"),
  );
function fe(t) {
  return new Date(t).toLocaleString("fr-FR", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}
function be(t) {
  return new Date(t).toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}
function A({ url: t, name: s }) {
  return t
    ? e.jsx("img", {
        src: t,
        alt: s,
        className: "h-9 w-9 object-contain",
        loading: "lazy",
      })
    : e.jsx("div", {
        className:
          "h-9 w-9 rounded-full bg-white/[0.06] flex items-center justify-center text-[10px] font-bold",
        children: s.slice(0, 2).toUpperCase(),
      });
}
function ge({ pick: t }) {
  const s =
      t === "1"
        ? "from-emerald-500 to-emerald-700"
        : t === "X"
          ? "from-amber-500 to-orange-600"
          : "from-blue-500 to-blue-700",
    a = t === "1" ? "Domicile" : t === "X" ? "Nul" : "Extérieur";
  return e.jsxs("div", {
    className: `px-2.5 py-1 rounded-lg text-[11px] font-black text-white bg-gradient-to-r ${s}`,
    children: [t, " · ", a],
  });
}
function Et({ p: t }) {
  const s = t.pick,
    a = t.prob_home ?? t.probabilities.home,
    i = t.prob_draw ?? t.probabilities.draw,
    r = t.prob_away ?? t.probabilities.away,
    l = t.score_home ?? Number(t.score.split("-")[0] ?? 0),
    n = t.score_away ?? Number(t.score.split("-")[1] ?? 0),
    h = t.btts_yes ?? t.bttsYes,
    c = t.over_25 ?? t.over25,
    m = t.confidence,
    o =
      t.estimated_odds ??
      (() => {
        const d = s === "1" ? a : s === "X" ? i : r;
        return d > 0 ? Math.min(20, Math.max(1.05, 100 / d)) : 5;
      })(),
    b = t.rationale;
  return e.jsxs("div", {
    className: "space-y-3 pt-3 border-t border-white/[0.06]",
    children: [
      e.jsxs("div", {
        className: "flex items-center justify-between gap-2 flex-wrap",
        children: [
          e.jsx(ge, { pick: s }),
          e.jsxs("div", {
            className: "flex items-center gap-2 text-[10px] font-mono",
            children: [
              e.jsxs("span", {
                className: "bg-white/[0.05] rounded-md px-2 py-1",
                children: ["Cote ~", Number(o).toFixed(2)],
              }),
              e.jsxs("span", {
                className:
                  "bg-[#E040FB]/10 border border-[#E040FB]/30 text-[#E040FB] rounded-md px-2 py-1 font-bold",
                children: ["Conf. ", m, "%"],
              }),
            ],
          }),
        ],
      }),
      e.jsx("div", {
        className: "grid grid-cols-3 gap-2",
        children: [
          { label: "1", val: a, color: "bg-emerald-500" },
          { label: "X", val: i, color: "bg-amber-500" },
          { label: "2", val: r, color: "bg-blue-500" },
        ].map((d) =>
          e.jsxs(
            "div",
            {
              className: "rounded-lg bg-white/[0.04] p-2",
              children: [
                e.jsxs("div", {
                  className: "flex items-baseline justify-between mb-1",
                  children: [
                    e.jsx("span", {
                      className: "text-[10px] font-bold text-white/60",
                      children: d.label,
                    }),
                    e.jsxs("span", {
                      className: "text-sm font-black",
                      children: [d.val, "%"],
                    }),
                  ],
                }),
                e.jsx("div", {
                  className: "h-1 rounded-full bg-white/[0.06] overflow-hidden",
                  children: e.jsx("div", {
                    className: `h-full ${d.color}`,
                    style: { width: `${d.val}%` },
                  }),
                }),
              ],
            },
            d.label,
          ),
        ),
      }),
      e.jsxs("div", {
        className: "grid grid-cols-3 gap-2 text-center",
        children: [
          e.jsxs("div", {
            className: "rounded-lg bg-white/[0.04] py-1.5",
            children: [
              e.jsxs("div", {
                className:
                  "flex items-center justify-center gap-1 text-[9px] text-white/50 uppercase",
                children: [e.jsx(z, { className: "w-3 h-3" }), "BTTS"],
              }),
              e.jsxs("div", {
                className: "text-sm font-black",
                children: [h, "%"],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "rounded-lg bg-white/[0.04] py-1.5",
            children: [
              e.jsxs("div", {
                className:
                  "flex items-center justify-center gap-1 text-[9px] text-white/50 uppercase",
                children: [e.jsx(xe, { className: "w-3 h-3" }), "+2.5"],
              }),
              e.jsxs("div", {
                className: "text-sm font-black",
                children: [c, "%"],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "rounded-lg bg-white/[0.04] py-1.5",
            children: [
              e.jsxs("div", {
                className:
                  "flex items-center justify-center gap-1 text-[9px] text-white/50 uppercase",
                children: [e.jsx(H, { className: "w-3 h-3" }), "Score"],
              }),
              e.jsxs("div", {
                className: "text-sm font-black",
                children: [l, "-", n],
              }),
            ],
          }),
        ],
      }),
      e.jsx("p", {
        className: "text-[11px] font-mono italic text-white/60 leading-relaxed",
        children: b,
      }),
      t.extras && e.jsx(Rt, { extras: t.extras, scoreHome: l, scoreAway: n }),
    ],
  });
}
function Rt({ extras: t, scoreHome: s, scoreAway: a }) {
  const [i, r] = x.useState("score"),
    l = [
      { id: "score", label: "Score exact", icon: H, color: "text-[#E040FB]" },
      { id: "handicap", label: "Handicap", icon: st, color: "text-cyan-400" },
      { id: "corners", label: "Corners", icon: Ze, color: "text-amber-400" },
      { id: "marche", label: "Marché", icon: xe, color: "text-emerald-400" },
      { id: "analyse", label: "Analyse", icon: Se, color: "text-yellow-400" },
    ];
  return e.jsxs("div", {
    className: "pt-3 border-t border-white/[0.06] space-y-2.5",
    children: [
      e.jsx("div", {
        className: "grid grid-cols-5 gap-1.5",
        children: l.map((n) => {
          const h = n.icon,
            c = i === n.id;
          return e.jsxs(
            "button",
            {
              onClick: () => r(n.id),
              className: `flex flex-col items-center justify-center gap-0.5 py-1.5 rounded-lg text-[10px] font-bold transition-all ${c ? "bg-white/[0.08] border border-white/[0.14] shadow-[0_0_12px_rgba(224,64,251,0.15)]" : "bg-white/[0.02] border border-transparent text-white/50 hover:text-white/80"}`,
              children: [
                e.jsx(h, { className: `w-3.5 h-3.5 ${c ? n.color : ""}` }),
                e.jsx("span", { children: n.label }),
              ],
            },
            n.id,
          );
        }),
      }),
      i === "score" &&
        t.altScores?.length > 0 &&
        e.jsxs("div", {
          className: "grid grid-cols-4 gap-1.5",
          children: [
            e.jsxs("div", {
              className:
                "rounded-lg bg-gradient-to-br from-[#E040FB]/20 to-[#7B2FFF]/10 border border-[#E040FB]/30 py-2 text-center",
              children: [
                e.jsxs("div", {
                  className: "text-sm font-black",
                  children: [s, "-", a],
                }),
                e.jsx("div", {
                  className: "text-[9px] font-mono text-[#E040FB]",
                  children: "TOP",
                }),
              ],
            }),
            t.altScores.map((n, h) =>
              e.jsxs(
                "div",
                {
                  className: "rounded-lg bg-white/[0.04] py-2 text-center",
                  children: [
                    e.jsx("div", {
                      className: "text-sm font-black",
                      children: n.score,
                    }),
                    e.jsxs("div", {
                      className: "text-[9px] font-mono text-white/50",
                      children: [n.prob, "%"],
                    }),
                  ],
                },
                h,
              ),
            ),
          ],
        }),
      i === "handicap" &&
        t.handicap &&
        e.jsxs("div", {
          className:
            "rounded-xl bg-white/[0.03] border border-white/[0.05] p-2.5",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2 mb-1.5",
              children: [
                e.jsxs("div", {
                  className:
                    "px-2 py-1 rounded-md text-[11px] font-black bg-cyan-500/20 border border-cyan-400/40 text-cyan-200",
                  children: [
                    t.handicap.side === "1" ? "Domicile" : "Extérieur",
                    " ",
                    t.handicap.line > 0
                      ? `+${t.handicap.line}`
                      : t.handicap.line,
                  ],
                }),
                e.jsx("div", {
                  className:
                    "flex-1 h-1.5 rounded-full bg-white/[0.06] overflow-hidden",
                  children: e.jsx("div", {
                    className:
                      "h-full bg-gradient-to-r from-cyan-400 to-blue-500",
                    style: { width: `${t.handicap.prob}%` },
                  }),
                }),
                e.jsxs("span", {
                  className: "text-xs font-black",
                  children: [t.handicap.prob, "%"],
                }),
              ],
            }),
            e.jsx("p", {
              className:
                "text-[10px] font-mono italic text-white/60 leading-snug",
              children: t.handicap.rationale,
            }),
          ],
        }),
      i === "corners" &&
        t.corners &&
        e.jsxs("div", {
          className:
            "rounded-xl bg-white/[0.03] border border-white/[0.05] p-2.5",
          children: [
            e.jsx("div", {
              className: "flex items-center justify-between mb-1.5",
              children: e.jsxs("span", {
                className: "text-[10px] font-mono text-white/50",
                children: ["Attendu ~", t.corners.expected, " corners"],
              }),
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsxs("div", {
                  className: `px-2 py-1 rounded-md text-[11px] font-black ${t.corners.pick === "over" ? "bg-emerald-500/20 border border-emerald-400/40 text-emerald-200" : "bg-blue-500/20 border border-blue-400/40 text-blue-200"}`,
                  children: [
                    t.corners.pick === "over" ? "OVER" : "UNDER",
                    " ",
                    t.corners.line,
                  ],
                }),
                e.jsx("div", {
                  className:
                    "flex-1 h-1.5 rounded-full bg-white/[0.06] overflow-hidden",
                  children: e.jsx("div", {
                    className:
                      "h-full bg-gradient-to-r from-amber-400 to-orange-500",
                    style: {
                      width: `${Math.max(t.corners.over, t.corners.under)}%`,
                    },
                  }),
                }),
                e.jsxs("span", {
                  className: "text-xs font-black",
                  children: [Math.max(t.corners.over, t.corners.under), "%"],
                }),
              ],
            }),
          ],
        }),
      i === "marche" &&
        e.jsxs("div", {
          className:
            "rounded-xl bg-white/[0.03] border border-white/[0.05] p-2.5 space-y-2",
          children: [
            t.market && t.market.bookmakers > 0
              ? e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("div", {
                      className: "grid grid-cols-3 gap-1.5",
                      children: [
                        ["1", t.market.oddsHome, t.market.impliedHome],
                        ["X", t.market.oddsDraw, t.market.impliedDraw],
                        ["2", t.market.oddsAway, t.market.impliedAway],
                      ].map(([n, h, c]) =>
                        e.jsxs(
                          "div",
                          {
                            className:
                              "rounded-lg bg-white/[0.04] py-1.5 text-center",
                            children: [
                              e.jsx("div", {
                                className: "text-[9px] font-mono text-white/45",
                                children: n,
                              }),
                              e.jsx("div", {
                                className: "text-sm font-black",
                                children: h ?? "—",
                              }),
                              e.jsxs("div", {
                                className:
                                  "text-[9px] font-mono text-emerald-300/80",
                                children: [c ?? "—", "%"],
                              }),
                            ],
                          },
                          n,
                        ),
                      ),
                    }),
                    e.jsxs("div", {
                      className:
                        "flex items-center justify-between text-[10px] font-mono text-white/50",
                      children: [
                        e.jsxs("span", {
                          children: [t.market.bookmakers, " bookmakers"],
                        }),
                        t.market.valueEdge !== null &&
                          t.market.valueEdge !== void 0 &&
                          e.jsxs("span", {
                            className:
                              t.market.valueEdge > 0
                                ? "text-emerald-300"
                                : "text-white/50",
                            children: [
                              "Value ",
                              t.market.valueEdge > 0 ? "+" : "",
                              t.market.valueEdge,
                              " pts",
                            ],
                          }),
                      ],
                    }),
                    e.jsxs("div", {
                      className: `rounded-lg px-2.5 py-2 text-[11px] leading-snug ${t.market.steamMove ? "bg-amber-500/10 border border-amber-400/30 text-amber-100" : "bg-white/[0.03] border border-white/[0.06] text-white/60"}`,
                      children: [
                        e.jsx("span", {
                          className: "font-bold",
                          children: "Flux d'argent : ",
                        }),
                        t.market.steamMove ??
                          "cotes stables, aucun mouvement anormal detecte",
                      ],
                    }),
                  ],
                })
              : e.jsx("p", {
                  className: "text-[11px] text-white/50",
                  children: "Cotes indisponibles pour ce match.",
                }),
            t.dataQuality &&
              e.jsx("div", {
                className: "flex flex-wrap gap-1.5 pt-1",
                children: [
                  `${t.dataQuality.formMatches} matchs analyses`,
                  `${t.dataQuality.h2hMatches} confrontations`,
                  `${t.dataQuality.injuriesHome + t.dataQuality.injuriesAway} absents`,
                  t.dataQuality.referee
                    ? `Arbitre ${t.dataQuality.referee}`
                    : "Arbitre n/a",
                ].map((n) =>
                  e.jsx(
                    "span",
                    {
                      className:
                        "px-1.5 py-0.5 rounded-md bg-white/[0.05] text-[9px] font-mono text-white/55",
                      children: n,
                    },
                    n,
                  ),
                ),
              }),
          ],
        }),
      i === "analyse" &&
        e.jsxs("div", {
          className: "space-y-2",
          children: [
            t.keyFactors?.length > 0 &&
              e.jsx("ul", {
                className: "space-y-1",
                children: t.keyFactors.map((n, h) =>
                  e.jsxs(
                    "li",
                    {
                      className:
                        "flex items-start gap-1.5 text-[11px] text-white/75 leading-snug",
                      children: [
                        e.jsx("span", {
                          className: "text-yellow-400 mt-0.5",
                          children: "•",
                        }),
                        e.jsx("span", { children: n }),
                      ],
                    },
                    h,
                  ),
                ),
              }),
            t.risk &&
              e.jsxs("div", {
                className:
                  "flex items-start gap-2 rounded-lg bg-red-500/5 border border-red-400/20 px-2.5 py-2",
                children: [
                  e.jsx(Te, {
                    className: "w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5",
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("div", {
                        className:
                          "text-[9px] uppercase tracking-widest text-red-300/80 font-bold",
                        children: "Risque principal",
                      }),
                      e.jsx("p", {
                        className: "text-[11px] text-white/70 leading-snug",
                        children: t.risk,
                      }),
                    ],
                  }),
                ],
              }),
          ],
        }),
    ],
  });
}
function Mt({ slot: t }) {
  const s = t.prediction;
  return s
    ? e.jsxs(de.div, {
        initial: { opacity: 0, y: 8 },
        animate: { opacity: 1, y: 0 },
        className:
          "relative overflow-hidden rounded-2xl border border-[#E040FB]/40 bg-gradient-to-br from-[#7B2FFF]/20 via-[#E040FB]/10 to-[#FF8C00]/10 p-4 shadow-[0_0_32px_rgba(224,64,251,0.25)]",
        children: [
          e.jsxs("div", {
            className:
              "absolute top-3 right-3 flex items-center gap-1.5 bg-black/40 backdrop-blur-sm rounded-full px-2.5 py-1 text-[10px] font-black",
            children: [
              e.jsx(Be, { className: "w-3 h-3 text-[#FFD700]" }),
              " VIP #",
              t.slot_index,
            ],
          }),
          e.jsxs("div", {
            className:
              "text-[10px] font-mono text-[#E040FB] uppercase tracking-widest mb-2",
            children: [
              "Montante · Étape ",
              t.slot_index,
              "/2 · Cote cible ~",
              t.target_odds,
            ],
          }),
          e.jsxs("div", {
            className:
              "flex items-center justify-between gap-3 text-[10px] text-white/50 mb-2",
            children: [
              e.jsxs("div", {
                className: "flex items-center gap-2 min-w-0",
                children: [
                  s.league_logo &&
                    e.jsx("img", {
                      src: s.league_logo,
                      alt: "",
                      className: "h-4 w-4 object-contain",
                      loading: "lazy",
                    }),
                  e.jsxs("span", {
                    className: "truncate font-semibold",
                    children: [s.league_name, s.country && ` · ${s.country}`],
                  }),
                ],
              }),
              e.jsx("span", {
                className: "font-mono shrink-0",
                children: fe(s.starting_at),
              }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3 mb-1",
            children: [
              e.jsxs("div", {
                className: "flex items-center gap-2.5 min-w-0",
                children: [
                  e.jsx(A, { url: s.home_logo, name: s.home_name }),
                  e.jsx("span", {
                    className: "font-semibold text-sm truncate",
                    children: s.home_name,
                  }),
                ],
              }),
              e.jsx("span", {
                className: "text-white/40 text-xs font-mono",
                children: "vs",
              }),
              e.jsxs("div", {
                className: "flex items-center gap-2.5 min-w-0 justify-end",
                children: [
                  e.jsx("span", {
                    className: "font-semibold text-sm truncate text-right",
                    children: s.away_name,
                  }),
                  e.jsx(A, { url: s.away_logo, name: s.away_name }),
                ],
              }),
            ],
          }),
          e.jsx(Et, { p: s }),
          t.status === "notified" &&
            t.notified_at &&
            e.jsxs("div", {
              className:
                "mt-2 text-[10px] font-mono text-emerald-300 flex items-center gap-1",
              children: [
                e.jsx(ce, { className: "w-3 h-3" }),
                " Notifié à ",
                be(t.notified_at),
              ],
            }),
        ],
      })
    : null;
}
function Tt({ v: t }) {
  const s =
    t.pick === "1" ? t.home_name : t.pick === "2" ? t.away_name : "Match nul";
  return e.jsxs(de.div, {
    initial: { opacity: 0, y: 8 },
    animate: { opacity: 1, y: 0 },
    className:
      "relative overflow-hidden rounded-2xl border border-emerald-500/40 bg-gradient-to-br from-emerald-500/15 via-emerald-600/5 to-transparent p-4 shadow-[0_0_24px_rgba(16,185,129,0.2)]",
    children: [
      e.jsxs("div", {
        className:
          "absolute top-3 right-3 flex items-center gap-1.5 bg-emerald-500/20 border border-emerald-400/40 backdrop-blur-sm rounded-full px-2.5 py-1 text-[10px] font-black text-emerald-200",
        children: [e.jsx(R, { className: "w-3 h-3" }), " VALIDÉ"],
      }),
      e.jsxs("div", {
        className:
          "flex items-center justify-between gap-3 text-[10px] text-white/50 mb-2 pr-20",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2 min-w-0",
            children: [
              t.league_logo &&
                e.jsx("img", {
                  src: t.league_logo,
                  alt: "",
                  className: "h-4 w-4 object-contain",
                  loading: "lazy",
                }),
              e.jsxs("span", {
                className: "truncate font-semibold",
                children: [t.league_name, t.country && ` · ${t.country}`],
              }),
            ],
          }),
          e.jsx("span", {
            className: "font-mono shrink-0",
            children: fe(t.starting_at),
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3 mb-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2.5 min-w-0",
            children: [
              e.jsx(A, { url: t.home_logo, name: t.home_name }),
              e.jsx("span", {
                className: "font-semibold text-sm truncate",
                children: t.home_name,
              }),
            ],
          }),
          e.jsxs("span", {
            className: "text-2xl font-black font-mono text-emerald-300",
            children: [t.actual_home, " - ", t.actual_away],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2.5 min-w-0 justify-end",
            children: [
              e.jsx("span", {
                className: "font-semibold text-sm truncate text-right",
                children: t.away_name,
              }),
              e.jsx(A, { url: t.away_logo, name: t.away_name }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className:
          "flex items-center justify-between gap-2 pt-3 border-t border-white/[0.06] flex-wrap",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(ge, { pick: t.pick }),
              e.jsxs("span", {
                className: "text-[11px] text-white/60",
                children: [
                  "Pronostic : ",
                  e.jsx("b", { className: "text-white/90", children: s }),
                ],
              }),
            ],
          }),
          e.jsxs("span", {
            className:
              "text-[10px] font-mono bg-emerald-500/15 border border-emerald-400/30 text-emerald-200 rounded-md px-2 py-1",
            children: [
              "Conf. ",
              t.confidence,
              "% · Score prédit ",
              t.predicted_score,
            ],
          }),
        ],
      }),
      t.goals.length > 0 &&
        e.jsxs("div", {
          className: "mt-3 pt-3 border-t border-white/[0.06]",
          children: [
            e.jsx("div", {
              className:
                "text-[9px] uppercase tracking-widest text-white/40 mb-1.5",
              children: "⚽ Buteurs",
            }),
            e.jsx("ul", {
              className: "space-y-1",
              children: t.goals.map((a, i) =>
                e.jsxs(
                  "li",
                  {
                    className: "flex items-center gap-2 text-[11px]",
                    children: [
                      e.jsx("span", {
                        className: "font-mono text-white/50 w-9 shrink-0",
                        children: a.minute != null ? `${a.minute}'` : "—",
                      }),
                      e.jsx("span", {
                        className: `shrink-0 h-1.5 w-1.5 rounded-full ${a.team === "home" ? "bg-emerald-400" : "bg-blue-400"}`,
                      }),
                      e.jsx("span", {
                        className: "truncate",
                        children: a.scorer,
                      }),
                      e.jsx("span", {
                        className: "text-white/40 text-[10px] ml-auto",
                        children: a.team === "home" ? t.home_name : t.away_name,
                      }),
                    ],
                  },
                  i,
                ),
              ),
            }),
          ],
        }),
    ],
  });
}
function Ht() {
  const t = w(at),
    s = w(it),
    a = w(St),
    [i, r] = x.useState("pronostics"),
    l = i === "valides",
    [n, h] = x.useState(null);
  x.useEffect(() => {
    let u = !0;
    ee.auth.getSession().then(({ data: v }) => {
      u && h(!!v.session);
    });
    const { data: B } = ee.auth.onAuthStateChange((v, C) => h(!!C));
    return () => {
      ((u = !1), B.subscription.unsubscribe());
    };
  }, []);
  const c = k({
      queryKey: ["sport", "cached"],
      queryFn: () => t(),
      enabled: n === !0,
      retry: !1,
      refetchInterval: 5 * 6e4,
    }),
    m = k({
      queryKey: ["sport", "montante"],
      queryFn: () => s(),
      enabled: n === !0,
      retry: !1,
      refetchInterval: 6e4,
    }),
    o = k({
      queryKey: ["sport", "validated"],
      queryFn: () => a(),
      enabled: l && n === !0,
      retry: !1,
      staleTime: 2 * 6e4,
    }),
    b = c.isLoading || m.isLoading,
    d = c.data?.ok ? c.data.predictions : [],
    j = m.data?.ok ? m.data.slots : [],
    F = d[0]?.analyzed_at;
  return e.jsxs(Ce, {
    children: [
      e.jsxs("div", {
        className:
          "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5 flex items-center gap-3 flex-wrap",
        children: [
          e.jsx("div", {
            className:
              "h-11 w-11 rounded-2xl bg-gradient-to-br from-[#7B2FFF] to-[#E040FB] flex items-center justify-center shadow-[0_0_24px_rgba(224,64,251,0.4)]",
            children: e.jsx(he, { className: "w-5 h-5 text-white" }),
          }),
          e.jsxs("div", {
            className: "flex-1 min-w-0",
            children: [
              e.jsx("h1", {
                className:
                  "font-display font-black text-xl sm:text-2xl tracking-tight bg-gradient-to-r from-[#7B2FFF] via-[#E040FB] to-[#FF8C00] bg-clip-text text-transparent",
                children: "Pronostics Football",
              }),
              e.jsxs("p", {
                className: "text-xs text-white/60 mt-0.5",
                children: [
                  "Clique sur un match pour révéler l'analyse IA · Push activées pour les pronos très fiables",
                  F && ` · MAJ ${be(F)}`,
                ],
              }),
            ],
          }),
          e.jsx(ot, {}),
        ],
      }),
      e.jsxs("div", {
        className: "glass rounded-2xl p-1 flex gap-1",
        children: [
          e.jsxs("button", {
            onClick: () => r("pronostics"),
            className: `flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-black uppercase tracking-widest transition ${i === "pronostics" ? "bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] text-white shadow-[0_0_20px_rgba(224,64,251,0.35)]" : "text-white/60 hover:text-white/90"}`,
            children: [e.jsx(Me, { className: "w-4 h-4" }), " Pronostics"],
          }),
          e.jsxs("button", {
            onClick: () => r("live"),
            className: `flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-black uppercase tracking-widest transition ${i === "live" ? "bg-gradient-to-r from-red-500 to-[#FF8C00] text-white shadow-[0_0_20px_rgba(239,68,68,0.35)]" : "text-white/60 hover:text-white/90"}`,
            children: [e.jsx(me, { className: "w-4 h-4" }), " Live"],
          }),
          e.jsxs("button", {
            onClick: () => r("valides"),
            className: `flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-black uppercase tracking-widest transition ${i === "valides" ? "bg-emerald-500/90 text-white shadow-[0_0_20px_rgba(16,185,129,0.35)]" : "text-white/60 hover:text-white/90"}`,
            children: [e.jsx(R, { className: "w-4 h-4" }), " Validés"],
          }),
        ],
      }),
      i === "live" && e.jsx(kt, {}),
      i === "pronostics" &&
        e.jsxs(e.Fragment, {
          children: [
            b &&
              e.jsxs("div", {
                className:
                  "glass rounded-2xl p-8 flex items-center justify-center gap-3 text-white/60",
                children: [
                  e.jsx(_, { className: "w-5 h-5 animate-spin" }),
                  e.jsx("span", {
                    className: "text-sm font-mono",
                    children: "Chargement des matchs...",
                  }),
                ],
              }),
            !b &&
              j.length > 0 &&
              e.jsxs("div", {
                className: "space-y-3",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 px-1",
                    children: [
                      e.jsx(_e, { className: "w-4 h-4 text-[#E040FB]" }),
                      e.jsx("h2", {
                        className:
                          "font-display font-black text-sm uppercase tracking-widest text-white/90",
                        children: "Montante VIP du jour",
                      }),
                    ],
                  }),
                  e.jsx("div", {
                    className: "grid grid-cols-1 lg:grid-cols-2 gap-3",
                    children: j.map((u) =>
                      e.jsx(Mt, { slot: u }, u.slot_index),
                    ),
                  }),
                ],
              }),
            e.jsxs("div", {
              className: "space-y-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2 px-1",
                  children: [
                    e.jsx(z, { className: "w-4 h-4 text-[#FF8C00]" }),
                    e.jsx("h2", {
                      className:
                        "font-display font-black text-sm uppercase tracking-widest text-white/90",
                      children: "Meilleurs pronostics du jour",
                    }),
                  ],
                }),
                e.jsx(gt, {}),
              ],
            }),
          ],
        }),
      i === "valides" &&
        e.jsxs("div", {
          className: "space-y-3",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2 px-1 flex-wrap",
              children: [
                e.jsx(R, { className: "w-4 h-4 text-emerald-400" }),
                e.jsx("h2", {
                  className:
                    "font-display font-black text-sm uppercase tracking-widest text-white/90",
                  children: "Meilleurs pronostics vérifiés",
                }),
              ],
            }),
            e.jsx(Ct, {}),
            e.jsxs("div", {
              className: "flex items-center gap-2 px-1 flex-wrap pt-2",
              children: [
                e.jsx(R, { className: "w-4 h-4 text-emerald-400" }),
                e.jsx("h2", {
                  className:
                    "font-display font-black text-sm uppercase tracking-widest text-white/90",
                  children: "Pronostics validés",
                }),
                o.data?.ok &&
                  e.jsxs("span", {
                    className: "text-[10px] font-mono text-emerald-300 ml-auto",
                    children: [o.data.validated.length, " gagnés"],
                  }),
              ],
            }),
            o.isLoading &&
              e.jsxs("div", {
                className:
                  "glass rounded-2xl p-6 flex items-center justify-center gap-3 text-white/60",
                children: [
                  e.jsx(_, { className: "w-4 h-4 animate-spin" }),
                  e.jsx("span", {
                    className: "text-xs font-mono",
                    children: "Vérification des résultats en cours…",
                  }),
                ],
              }),
            !o.isLoading &&
              o.data?.ok &&
              o.data.validated.length === 0 &&
              e.jsxs("div", {
                className:
                  "glass rounded-2xl p-6 flex items-start gap-3 border border-white/[0.06]",
                children: [
                  e.jsx(T, {
                    className: "w-5 h-5 text-white/60 shrink-0 mt-0.5",
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("p", {
                        className: "text-sm font-semibold",
                        children: "Aucun pronostic validé pour l'instant",
                      }),
                      e.jsx("p", {
                        className: "text-xs text-white/60 mt-1",
                        children: "Reviens après quelques matchs terminés.",
                      }),
                    ],
                  }),
                ],
              }),
            o.data?.ok &&
              o.data.validated.length > 0 &&
              e.jsx("div", {
                className: "grid grid-cols-1 lg:grid-cols-2 gap-3",
                children: o.data.validated.map((u) =>
                  e.jsx(Tt, { v: u }, u.fixture_id),
                ),
              }),
          ],
        }),
    ],
  });
}
export { Ht as component };
