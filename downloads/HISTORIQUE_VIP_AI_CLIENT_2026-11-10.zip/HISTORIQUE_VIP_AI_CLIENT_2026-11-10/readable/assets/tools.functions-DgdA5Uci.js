import { d as e, e as d } from "./index-C5ThNCN-.js";
const c = e({ method: "POST" }).handler(
    d("fca75d81204f4033b16bcc661baa45421867b67bbde63815140f1a3614c77fbe"),
  ),
  o = e({ method: "POST" }).handler(
    d("b961d3da1b136e9ebe34e18366068c9c4ee004ab1951580ee40d769cc32f1aea"),
  ),
  r = e({ method: "POST" }).handler(
    d("41fb486c661c49114e50f30b64a17d24d6711f877ede4554707d4d90fd2428a6"),
  ),
  b = e({ method: "POST" }).handler(
    d("35bad5c079e6637f3bf4d4c4c79091324dcfc974763f5c01a7346806de84de88"),
  );
export { r as a, b, c, o as d };
