import {
  d as w,
  e as _,
  r,
  f as y,
  J as g,
  M as N,
  j as e,
} from "./index-C5ThNCN-.js";
import { R as S } from "./RoundCard-CZ-rEJ_D.js";
import { S as E, P as k } from "./PredictionPanel-BwmEfDz4.js";
import { A as M } from "./AiPredictionPanel-B3Hc_8UW.js";
import { D as P } from "./DashboardLayout-XCzqIJrp.js";
import "./analysis-data-BaiXRb_2.js";
import "./triangle-alert-CzDFXfJ_.js";
import "./database-80brKRBJ.js";
import "./trending-up-B5K2KKMW.js";
import "./activity-D198U5P3.js";
import "./button-4JeZmZFi.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const R = w({ method: "GET" }).handler(
    _("b62089035040c3a37e97a8cbfa7577cc56d3658bd447ab14ac6eb678e235162a"),
  ),
  p = 20,
  C = 6e4;
function I() {
  const [i, m] = r.useState([]),
    [a, o] = r.useState("connecting"),
    [x, c] = r.useState(null),
    [d, u] = r.useState(!1),
    [b, j] = r.useState(null),
    f = r.useRef(new Set()),
    h = y(R);
  return (
    r.useEffect(() => {
      let n = !1;
      return (
        (async () => {
          const { data: l } = await g
            .from("crash_1xbet_rounds")
            .select("id,coefficient,color,played_at")
            .order("played_at", { ascending: !1 })
            .limit(p);
          if (n || !l) return;
          const s = l.map((t) => ({
            id: t.id,
            coefficient: Number(t.coefficient),
            color: t.color ?? N(Number(t.coefficient)),
            timestamp: new Date(t.played_at).getTime(),
          }));
          (s.forEach((t) => f.current.add(t.id)), m(s));
        })(),
        () => {
          n = !0;
        }
      );
    }, []),
    r.useEffect(() => {
      const n = g
        .channel(`crash_1xbet_rounds_rt_${Math.random().toString(36).slice(2)}`)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "crash_1xbet_rounds" },
          (l) => {
            const s = l.new;
            if (f.current.has(s.id)) return;
            f.current.add(s.id);
            const t = {
              id: s.id,
              coefficient: Number(s.coefficient),
              color: s.color,
              timestamp: new Date(s.played_at).getTime(),
            };
            (j(t.id), m((v) => [t, ...v].slice(0, p)));
          },
        )
        .subscribe();
      return () => {
        g.removeChannel(n);
      };
    }, []),
    r.useEffect(() => {
      let n = !1,
        l;
      const s = async () => {
        try {
          const t = await h();
          if (n) return;
          t?.ok
            ? (o("live"), c(null), u(!!t.waiting))
            : (o("error"), c(t?.error ?? "unknown"));
        } catch (t) {
          n || (o("error"), c(t.message));
        } finally {
          n || (l = setTimeout(s, C));
        }
      };
      return (
        s(),
        () => {
          ((n = !0), clearTimeout(l));
        }
      );
    }, [h]),
    { rounds: i, status: a, waiting: d, newestId: b, errorMsg: x, max: p }
  );
}
function X() {
  const [i, m] = r.useState(!1);
  r.useEffect(() => {
    (localStorage.setItem("lj_current_game", "crash-1xbet"), m(!0));
  }, []);
  const { rounds: a, status: o, newestId: x, errorMsg: c } = I();
  return e.jsxs(P, {
    children: [
      e.jsxs("div", {
        className:
          "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between flex-wrap gap-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-3 min-w-0",
            children: [
              e.jsx("div", {
                className:
                  "shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center font-display font-black text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]",
                children: "1×",
              }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsx("h1", {
                    className:
                      "font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight bg-gradient-to-r from-emerald-400 via-[var(--neon-blue)] to-[var(--neon-orange)] bg-clip-text text-transparent",
                    children: "Crash — 1xBet",
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-0.5",
                    children: "Historique des 20 derniers tours en temps réel",
                  }),
                ],
              }),
            ],
          }),
          i &&
            e.jsxs("div", {
              className: "flex items-center gap-2 text-xs font-mono",
              children: [
                e.jsx("span", {
                  className: `w-2 h-2 rounded-full animate-pulse ${o === "live" ? "bg-[var(--neon-green)]" : o === "error" ? "bg-[var(--neon-orange)]" : "bg-[var(--neon-blue)]"}`,
                }),
                e.jsx("span", {
                  className: "text-muted-foreground",
                  children:
                    o === "live"
                      ? "LIVE"
                      : o === "error"
                        ? `Erreur API${c ? ` : ${c}` : ""}`
                        : "Connexion…",
                }),
              ],
            }),
        ],
      }),
      i && a.length > 0 && e.jsx(E, { rounds: a }),
      i && a.length > 0 && e.jsx(M, { rounds: a, game: "crash_1xbet" }),
      i && a.length > 0 && e.jsx(k, { rounds: a, table: "crash_1xbet_rounds" }),
      e.jsxs("main", {
        className: "glass rounded-3xl p-4 sm:p-6 lg:p-8",
        children: [
          e.jsx("div", {
            className: "flex items-end justify-between flex-wrap gap-2 mb-5",
            children: e.jsxs("div", {
              children: [
                e.jsx("h2", {
                  className:
                    "font-display font-bold text-xl sm:text-2xl tracking-tight",
                  children: "20 derniers tours",
                }),
                e.jsx("p", {
                  className: "text-xs sm:text-sm text-muted-foreground mt-1",
                  children:
                    "Mise à jour en temps réel depuis la WebSocket officielle 1xBet",
                }),
              ],
            }),
          }),
          i && a.length === 0
            ? e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: Array.from({ length: 20 }).map((d, u) =>
                  e.jsx(
                    "div",
                    {
                      className:
                        "rounded-2xl h-[56px] sm:h-[64px] glass animate-pulse",
                      style: { animationDelay: `${u * 50}ms` },
                    },
                    u,
                  ),
                ),
              })
            : e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: a.map((d) =>
                  e.jsx(S, { round: d, isNew: d.id === x }, d.id),
                ),
              }),
        ],
      }),
    ],
  });
}
export { X as component };
