import { j as t, m as s, a5 as l } from "./index-C5ThNCN-.js";
const o = {
  blue: "card-blue",
  purple: "card-purple",
  orange: "card-orange",
  yellow: "card-yellow",
};
function n({ round: e, isNew: a }) {
  return t.jsxs(s.div, {
    layout: !0,
    initial: a ? { scale: 0.6, opacity: 0, y: -20 } : !1,
    animate: { scale: 1, opacity: 1, y: 0 },
    exit: { scale: 0.6, opacity: 0, y: 20 },
    transition: { type: "spring", stiffness: 380, damping: 28 },
    whileHover: { scale: 1.06, y: -4 },
    className: `${o[e.color]} rounded-xl px-1.5 py-2 sm:px-2 sm:py-2.5 flex flex-col items-center justify-center text-white select-none cursor-default`,
    children: [
      t.jsxs("span", {
        className:
          "font-display font-bold text-sm sm:text-base lg:text-lg text-glow tracking-tight leading-none",
        children: [e.coefficient.toFixed(2), "x"],
      }),
      t.jsx("span", {
        className:
          "font-mono text-[9px] sm:text-[10px] opacity-80 mt-1 leading-none",
        children: l(e.timestamp),
      }),
    ],
  });
}
export { n as R };
