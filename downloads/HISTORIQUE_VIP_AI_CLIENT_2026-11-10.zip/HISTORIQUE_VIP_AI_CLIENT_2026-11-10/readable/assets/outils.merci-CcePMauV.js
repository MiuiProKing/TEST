import {
  aq as p,
  f as h,
  r as n,
  j as e,
  N as g,
  k as j,
  l as b,
  ao as f,
  C as w,
  a as k,
} from "./index-C5ThNCN-.js";
import { D as v } from "./DashboardLayout-XCzqIJrp.js";
import { d as N } from "./tools.functions-DgdA5Uci.js";
import { C as y } from "./circle-alert-Adrk4haQ.js";
import { C as A } from "./circle-check-B56GEMOe.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const c = {
  luckyjet: { table: "luckyjet_rounds", label: "LuckyJet (1win)" },
  jetx_1win: { table: "jetx_1win_rounds", label: "JetX (1win)" },
  jetx: { table: "jetx_rounds", label: "JetX (Betclic)" },
  aviator: { table: "aviator_rounds", label: "Aviator (Betclic)" },
  rocketqueen: { table: "rocketqueen_rounds", label: "Rocket Queen (1win)" },
  dragonscrash: {
    table: "dragonscrash_rounds",
    label: "Dragon's Crash (Betclic)",
  },
};
function P() {
  const o = p({ from: "/outils/merci" }),
    d = h(N),
    [t, a] = n.useState({ kind: "loading" }),
    [m, l] = n.useState(!1),
    r =
      o.ref ??
      o.reference ??
      (typeof window < "u"
        ? (localStorage.getItem("gp_tool_ref") ?? void 0)
        : void 0);
  n.useEffect(() => {
    if (!r) {
      a({ kind: "error", msg: "Aucune référence de transaction trouvée." });
      return;
    }
    d({ data: { reference: r } })
      .then((s) => {
        if (!s.ok) {
          s.status && s.status !== "completed"
            ? a({ kind: "pending", status: s.status })
            : a({ kind: "error", msg: s.error ?? "Vérification impossible" });
          return;
        }
        if (s.manual) {
          a({ kind: "manual" });
          return;
        }
        (localStorage.removeItem("gp_tool_ref"),
          a({
            kind: "api",
            key: s.key,
            games: s.games ?? [],
            expiresAt: s.expiresAt,
            already: !!s.alreadyDelivered,
          }));
      })
      .catch((s) => a({ kind: "error", msg: s?.message ?? "Erreur" }));
  }, [r]);
  const x = (s) => {
      (navigator.clipboard.writeText(s), l(!0), setTimeout(() => l(!1), 1800));
    },
    i =
      typeof window < "u"
        ? window.location.origin
        : "https://historique-luckyjet.shop";
  return e.jsxs(v, {
    children: [
      e.jsxs("div", {
        className:
          "rounded-3xl border border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 via-[#0F0B1F] to-[#0B0916] p-6 sm:p-10 text-center flex flex-col items-center gap-3",
        children: [
          e.jsx("div", {
            className:
              "h-16 w-16 rounded-full bg-emerald-500/20 flex items-center justify-center",
            children:
              t.kind === "loading"
                ? e.jsx(g, {
                    className: "w-8 h-8 text-emerald-400 animate-spin",
                  })
                : t.kind === "error" || t.kind === "pending"
                  ? e.jsx(y, { className: "w-8 h-8 text-amber-400" })
                  : e.jsx(A, { className: "w-9 h-9 text-emerald-400" }),
          }),
          e.jsx("h1", {
            className: "font-display font-black text-2xl sm:text-3xl",
            children:
              t.kind === "api"
                ? "Votre API est activée"
                : "Commande enregistrée",
          }),
          t.kind === "loading" &&
            e.jsx("p", {
              className: "text-white/60 text-sm",
              children: "Vérification du paiement et génération de votre clé…",
            }),
          t.kind === "pending" &&
            e.jsxs("p", {
              className: "text-white/70 text-sm max-w-md",
              children: [
                "Paiement en cours de traitement (",
                t.status,
                "). Rechargez cette page dans quelques instants, votre clé sera générée automatiquement.",
              ],
            }),
          t.kind === "error" &&
            e.jsx("p", {
              className: "text-white/70 text-sm max-w-md",
              children: t.msg,
            }),
          t.kind === "manual" &&
            e.jsx("p", {
              className: "text-white/70 text-sm max-w-md",
              children:
                "Paiement confirmé. Votre hébergement Telegram est en cours d'activation — notre équipe vous contacte sous 24h.",
            }),
          e.jsxs(j, {
            to: "/outils",
            className:
              "mt-2 inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-white/10 border border-white/20 font-bold text-sm hover:bg-white/15",
            children: [e.jsx(b, { size: 16 }), " Retour aux outils"],
          }),
        ],
      }),
      t.kind === "api" &&
        e.jsxs("section", {
          className: "mt-3 space-y-3",
          children: [
            e.jsxs("div", {
              className:
                "rounded-2xl border border-[#7B2FFF]/40 bg-[#0F0B1F] p-4 sm:p-6",
              children: [
                e.jsxs("h2", {
                  className:
                    "font-display font-bold text-lg flex items-center gap-2",
                  children: [
                    e.jsx(f, { size: 18, className: "text-[#B388FF]" }),
                    " Votre clé API",
                  ],
                }),
                t.key
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsxs("div", {
                          className:
                            "mt-3 flex items-center gap-2 rounded-xl bg-black/50 border border-white/10 p-3",
                          children: [
                            e.jsx("code", {
                              className:
                                "flex-1 break-all text-emerald-300 font-mono text-xs sm:text-sm",
                              children: t.key,
                            }),
                            e.jsx("button", {
                              type: "button",
                              onClick: () => x(t.key),
                              "aria-label": "Copier la clé API",
                              className:
                                "p-2 rounded-lg bg-white/10 hover:bg-white/20",
                              children: m
                                ? e.jsx(w, {
                                    size: 16,
                                    className: "text-emerald-400",
                                  })
                                : e.jsx(k, { size: 16 }),
                            }),
                          ],
                        }),
                        e.jsx("p", {
                          className: "mt-2 text-[11px] text-amber-300/80",
                          children:
                            "Copiez-la maintenant : pour votre sécurité elle n'est affichée qu'une seule fois.",
                        }),
                      ],
                    })
                  : e.jsx("p", {
                      className: "mt-3 text-sm text-white/70",
                      children:
                        "Clé déjà délivrée pour cette commande. Contactez le support si vous l'avez perdue.",
                    }),
                e.jsxs("div", {
                  className:
                    "mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-white/70",
                  children: [
                    e.jsxs("p", {
                      children: [
                        e.jsx("span", {
                          className: "text-white/40",
                          children: "Jeux inclus :",
                        }),
                        " ",
                        t.games.map((s) => c[s]?.label ?? s).join(", ") || "—",
                      ],
                    }),
                    e.jsxs("p", {
                      children: [
                        e.jsx("span", {
                          className: "text-white/40",
                          children: "Valide jusqu'au :",
                        }),
                        " ",
                        t.expiresAt
                          ? new Date(t.expiresAt).toLocaleDateString("fr-FR")
                          : "—",
                      ],
                    }),
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              className:
                "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-4 sm:p-6",
              children: [
                e.jsx("h2", {
                  className: "font-display font-bold text-lg",
                  children: "Documentation & intégration",
                }),
                e.jsx("p", {
                  className: "text-xs text-white/55 mt-1",
                  children:
                    "Endpoint REST JSON sécurisé, mis à jour en continu par nos collecteurs.",
                }),
                e.jsx("pre", {
                  className:
                    "mt-3 overflow-x-auto rounded-xl bg-black/50 border border-white/10 p-3 text-[11px] sm:text-xs text-emerald-300 font-mono",
                  children: `GET ${i}/api/public/v1/rounds?game=${t.games[0] ?? "luckyjet"}&limit=50
Authorization: Bearer <VOTRE_CLE_API>

{
  "game": "${t.games[0] ?? "luckyjet"}",
  "count": 50,
  "rounds": [
    { "round_id": "8241993", "coefficient": 12.47, "at": "2026-08-10T14:58:31.000Z" }
  ]
}

# cURL
curl -H "Authorization: Bearer <VOTRE_CLE_API>" \\
  "${i}/api/public/v1/rounds?game=${t.games[0] ?? "luckyjet"}&limit=100"

# JavaScript
const res = await fetch("${i}/api/public/v1/rounds?game=${t.games[0] ?? "luckyjet"}&limit=100", {
  headers: { Authorization: "Bearer <VOTRE_CLE_API>" },
});
const { rounds } = await res.json();`,
                }),
                e.jsxs("div", {
                  className: "mt-3 text-xs text-white/60 space-y-1",
                  children: [
                    e.jsxs("p", {
                      children: [
                        e.jsx("span", {
                          className: "text-white/40",
                          children: "Paramètres :",
                        }),
                        " ",
                        e.jsx("code", { children: "game" }),
                        " (obligatoire),",
                        " ",
                        e.jsx("code", { children: "limit" }),
                        " (1 à 500, défaut 50).",
                      ],
                    }),
                    e.jsxs("p", {
                      children: [
                        e.jsx("span", {
                          className: "text-white/40",
                          children: "Slugs disponibles :",
                        }),
                        " ",
                        Object.entries(c)
                          .map(([s, u]) => `${s} = ${u.label}`)
                          .join(" · "),
                      ],
                    }),
                    e.jsxs("p", {
                      children: [
                        e.jsx("span", {
                          className: "text-white/40",
                          children: "Erreurs :",
                        }),
                        " 401 clé absente/invalide · 403 jeu hors abonnement ou clé expirée · 400 jeu inconnu.",
                      ],
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
    ],
  });
}
export { P as component };
