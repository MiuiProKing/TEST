import { j as o } from "./index-C5ThNCN-.js";
import { G as m } from "./GameUnavailable-BOASHPW9.js";
import "./DashboardLayout-XCzqIJrp.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
import "./lock-DtZN1438.js";
const e = () => o.jsx(m, { name: "Crash 1Win" });
export { e as component };
