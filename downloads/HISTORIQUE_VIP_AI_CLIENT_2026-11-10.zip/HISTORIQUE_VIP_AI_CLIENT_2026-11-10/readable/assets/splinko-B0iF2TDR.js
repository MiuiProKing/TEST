import {
  c as k,
  r as d,
  j as e,
  a6 as S,
  T,
  S as $,
} from "./index-C5ThNCN-.js";
import { D as _ } from "./DashboardLayout-XCzqIJrp.js";
import { T as B, a as D } from "./trending-up-B5K2KKMW.js";
import { Z as V } from "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const E = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "M12 16v-4", key: "1dtifu" }],
    ["path", { d: "M12 8h.01", key: "e9boi3" }],
  ],
  L = k("info", E),
  l = {
    rtp: 0.95,
    maxWin: 1350,
    deluxeCost: 45,
    baseBonusRate: 1 / 168,
    baseBonusEv: 38,
    vortexMultipliers: [5, 10, 20, 30, 40, 50, 100],
    deluxeVortexMultipliers: [10, 20, 30, 40, 50, 100, 200],
    pulseBallValues: [2, 5, 10],
  };
function h(s) {
  let r = 2166136261;
  for (let t = 0; t < s.length; t++)
    ((r ^= s.charCodeAt(t)), (r = Math.imul(r, 16777619)));
  return (r >>> 0) / 4294967295;
}
const C = (s) => `${s.getFullYear()}-${s.getMonth() + 1}-${s.getDate()}`;
function F(s) {
  const r = [
    { h: 13, w: 0.75, s: 2.2 },
    { h: 21, w: 1, s: 3 },
    { h: 17, w: 0.45, s: 2 },
  ];
  let t = 0.12;
  for (const a of r) {
    const n = Math.min(Math.abs(s - a.h), 24 - Math.abs(s - a.h));
    t += a.w * Math.exp(-(n * n) / (2 * a.s * a.s));
  }
  return Math.min(1, t);
}
const I = (s, r, t) => Math.max(r, Math.min(t, s)),
  b = (s) =>
    s >= 86 ? "Très élevé" : s >= 74 ? "Élevé" : s >= 60 ? "Moyen" : "Faible",
  g = (s) => s.toString().padStart(2, "0");
function p(s = new Date()) {
  const r = C(s);
  return Array.from({ length: 24 }, (t, a) => {
    const n = F(a),
      o = h(`${r}#${a}`),
      i = h(`${r}#drift`) * 6,
      f = 1 - n,
      j = 0.5 + 0.5 * Math.cos(((a - i) / 24) * 2 * Math.PI * 2),
      c = f * 0.45 + j * 0.35 + o * 0.2,
      v = Math.round(I(28 + c * 72, 20, 96)),
      N = 0.62 + (1 - c) * 0.85,
      w = Math.round((1 / l.baseBonusRate) * N),
      y = +(1 + c * 1.35).toFixed(2),
      M = l.baseBonusEv * (0.85 + c * 0.6) >= l.deluxeCost;
    return { hour: a, score: v, spinsToBonus: w, ballValue: y, deluxeWorth: M };
  });
}
function m(s = new Date(), r = 3) {
  return [...p(s)]
    .sort((n, o) => o.score - n.score)
    .slice(0, r)
    .sort((n, o) => n.hour - o.hour)
    .map((n) => ({
      hour: n.hour,
      startLabel: `${g(n.hour)}h00`,
      endLabel: `${g((n.hour + 1) % 24)}h00`,
      score: n.score,
      confidence: b(n.score),
      spinsToBonus: n.spinsToBonus,
      suggestedMode: n.deluxeWorth ? "Deluxe Experience" : "Jeu de base",
      advice: n.deluxeWorth
        ? "Mise de base modérée puis achat Deluxe (45x) : EV bonus estimée supérieure au coût sur ce créneau."
        : `Restez en jeu de base et enchaînez ~${n.spinsToBonus} spins pour capter les 3 scatters.`,
    }));
}
function W(s = new Date()) {
  const t = p(s)[s.getHours()],
    n =
      m(s, 3).find((i) => i.hour > s.getHours()) ??
      m(new Date(s.getTime() + 864e5), 3)[0] ??
      null,
    o = n
      ? n.hour > s.getHours()
        ? (n.hour - s.getHours()) * 60 - s.getMinutes()
        : (24 - s.getHours() + n.hour) * 60 - s.getMinutes()
      : 0;
  return {
    hour: t.hour,
    score: t.score,
    confidence: b(t.score),
    spinsToBonus: t.spinsToBonus,
    ballValue: t.ballValue,
    verdict:
      t.score >= 74
        ? "Jouer maintenant"
        : t.score >= 58
          ? "Jouer prudemment"
          : "Attendre",
    nextWindow: n,
    minutesToNext: Math.max(0, o),
  };
}
const P =
    "/__l5e/assets-v1/82f6e81d-ae8c-475c-a3da-bbe18750b285/betclic-logo-new.png",
  x = (s) => s.toString().padStart(2, "0");
function G() {
  const [s, r] = d.useState(null);
  d.useEffect(() => {
    (localStorage.setItem("lj_current_game", "splinko"), r(new Date()));
    const a = setInterval(() => r(new Date()), 3e4);
    return () => clearInterval(a);
  }, []);
  const t = d.useMemo(() => {
    if (!s) return null;
    const a = p(s),
      n = W(s);
    return {
      hours: a,
      windows: m(s, 3).map((o) => ({ ...o, score: a[o.hour].score })),
      status: n,
    };
  }, [s]);
  return e.jsxs(_, {
    children: [
      e.jsxs("div", {
        className:
          "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between flex-wrap gap-3 relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "absolute inset-0 bg-gradient-to-r from-fuchsia-600/15 via-transparent to-cyan-500/15 pointer-events-none",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-3 min-w-0 relative",
            children: [
              e.jsx("img", {
                src: S,
                alt: "Splinko Deluxe Betclic",
                className:
                  "shrink-0 w-12 h-12 rounded-xl object-cover shadow-[0_0_22px_rgba(217,70,239,0.45)]",
              }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 flex-wrap",
                    children: [
                      e.jsx("h1", {
                        className:
                          "font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight bg-gradient-to-r from-fuchsia-400 via-[var(--neon-purple)] to-cyan-400 bg-clip-text text-transparent",
                        children: "Splinko Deluxe",
                      }),
                      e.jsx("span", {
                        className: "text-muted-foreground font-light text-lg",
                        children: "×",
                      }),
                      e.jsx("div", {
                        className:
                          "inline-flex items-center px-2.5 py-1 rounded-lg bg-gradient-to-br from-red-600 to-red-800 shadow-[0_0_18px_rgba(220,38,38,0.5)] border border-red-400/30",
                        children: e.jsx("img", {
                          src: P,
                          alt: "Betclic",
                          className: "h-5 w-auto object-contain",
                        }),
                      }),
                    ],
                  }),
                  e.jsxs("p", {
                    className:
                      "text-[11px] sm:text-xs text-muted-foreground mt-0.5",
                    children: [
                      "Slot 3 rouleaux · 1 ligne · RTP ",
                      (l.rtp * 100).toFixed(2),
                      " % · max",
                      " ",
                      l.maxWin,
                      "x",
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      t
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsxs("section", {
                className: "glass rounded-2xl p-4 sm:p-5",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 mb-3",
                    children: [
                      e.jsx(B, {
                        className: "w-4 h-4 text-[var(--neon-purple)]",
                      }),
                      e.jsx("h2", {
                        className:
                          "font-display font-bold text-sm sm:text-base",
                        children: "Faut-il jouer maintenant ?",
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "grid grid-cols-2 lg:grid-cols-4 gap-2.5",
                    children: [
                      e.jsx(u, {
                        label: "Verdict",
                        value: t.status.verdict,
                        accent:
                          t.status.verdict === "Jouer maintenant"
                            ? "text-[var(--neon-green)]"
                            : t.status.verdict === "Jouer prudemment"
                              ? "text-yellow-400"
                              : "text-red-400",
                      }),
                      e.jsx(u, {
                        label: "Score du créneau",
                        value: `${t.status.score}/100`,
                        sub: t.status.confidence,
                      }),
                      e.jsx(u, {
                        label: "Spins avant bonus",
                        value: `≈ ${t.status.spinsToBonus}`,
                        sub: "3 scatters",
                      }),
                      e.jsx(u, {
                        label: "Valeur bille moy.",
                        value: `${t.status.ballValue}x`,
                        sub: "mise de base",
                      }),
                    ],
                  }),
                  t.status.nextWindow &&
                    e.jsxs("div", {
                      className:
                        "mt-3 rounded-xl border border-[var(--neon-purple)]/30 bg-[var(--neon-purple)]/[0.07] px-3 py-2.5 flex items-center gap-2 text-xs",
                      children: [
                        e.jsx(T, {
                          className:
                            "w-3.5 h-3.5 text-[var(--neon-purple)] shrink-0",
                        }),
                        e.jsxs("span", {
                          children: [
                            "Prochaine fenêtre favorable :",
                            " ",
                            e.jsxs("strong", {
                              className: "text-white",
                              children: [
                                t.status.nextWindow.startLabel,
                                " – ",
                                t.status.nextWindow.endLabel,
                              ],
                            }),
                            " ",
                            "(dans ",
                            Math.floor(t.status.minutesToNext / 60),
                            "h",
                            x(t.status.minutesToNext % 60),
                            ")",
                          ],
                        }),
                      ],
                    }),
                ],
              }),
              e.jsxs("section", {
                className: "glass rounded-2xl p-4 sm:p-5",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 mb-3",
                    children: [
                      e.jsx($, {
                        className: "w-4 h-4 text-[var(--neon-orange)]",
                      }),
                      e.jsx("h2", {
                        className:
                          "font-display font-bold text-sm sm:text-base",
                        children: "Meilleures heures d'aujourd'hui",
                      }),
                    ],
                  }),
                  e.jsx("div", {
                    className: "grid sm:grid-cols-3 gap-3",
                    children: t.windows.map((a) =>
                      e.jsxs(
                        "div",
                        {
                          className:
                            "rounded-xl border border-white/[0.08] bg-gradient-to-b from-white/[0.06] to-transparent p-3.5",
                          children: [
                            e.jsxs("div", {
                              className:
                                "flex items-baseline justify-between mb-1.5",
                              children: [
                                e.jsxs("span", {
                                  className:
                                    "font-display font-black text-lg text-white",
                                  children: [a.startLabel, " – ", a.endLabel],
                                }),
                                e.jsx("span", {
                                  className:
                                    "text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-[var(--neon-green)] text-black",
                                  children: a.score,
                                }),
                              ],
                            }),
                            e.jsxs("p", {
                              className:
                                "text-[11px] text-muted-foreground mb-2",
                              children: [
                                "Fiabilité : ",
                                e.jsx("strong", {
                                  className: "text-white",
                                  children: a.confidence,
                                }),
                                " · mode conseillé :",
                                " ",
                                e.jsx("strong", {
                                  className: "text-white",
                                  children: a.suggestedMode,
                                }),
                              ],
                            }),
                            e.jsx("p", {
                              className:
                                "text-[11px] leading-relaxed text-muted-foreground",
                              children: a.advice,
                            }),
                          ],
                        },
                        a.hour,
                      ),
                    ),
                  }),
                ],
              }),
              e.jsxs("section", {
                className: "glass rounded-2xl p-4 sm:p-5",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 mb-3",
                    children: [
                      e.jsx(D, {
                        className: "w-4 h-4 text-[var(--neon-blue)]",
                      }),
                      e.jsx("h2", {
                        className:
                          "font-display font-bold text-sm sm:text-base",
                        children: "Favorabilité sur 24 h",
                      }),
                    ],
                  }),
                  e.jsx("div", {
                    className: "flex items-end gap-[3px] h-32",
                    children: t.hours.map((a) => {
                      const n = a.hour === t.status.hour,
                        o = t.windows.some((i) => i.hour === a.hour);
                      return e.jsxs(
                        "div",
                        {
                          className:
                            "flex-1 flex flex-col items-center gap-1 group",
                          children: [
                            e.jsx("div", {
                              title: `${x(a.hour)}h — score ${a.score}/100 — ≈${a.spinsToBonus} spins`,
                              style: { height: `${a.score}%` },
                              className: `w-full rounded-t-sm transition-all ${o ? "bg-[var(--neon-green)] shadow-[0_0_12px_var(--neon-green)]" : n ? "bg-[var(--neon-orange)]" : "bg-white/15 group-hover:bg-white/30"}`,
                            }),
                            e.jsx("span", {
                              className: `text-[8px] font-mono ${n ? "text-[var(--neon-orange)]" : "text-muted-foreground"}`,
                              children: x(a.hour),
                            }),
                          ],
                        },
                        a.hour,
                      );
                    }),
                  }),
                ],
              }),
              e.jsxs("section", {
                className: "glass rounded-2xl p-4 sm:p-5",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 mb-3",
                    children: [
                      e.jsx(V, {
                        className: "w-4 h-4 text-[var(--neon-orange)]",
                      }),
                      e.jsx("h2", {
                        className:
                          "font-display font-bold text-sm sm:text-base",
                        children: "Stratégie bonus Splinko",
                      }),
                    ],
                  }),
                  e.jsxs("ul", {
                    className:
                      "space-y-2 text-xs text-muted-foreground leading-relaxed",
                    children: [
                      e.jsxs("li", {
                        children: [
                          e.jsx("strong", {
                            className: "text-white",
                            children: "3 Scatters = 20 billes Splinko.",
                          }),
                          " Chaque bille vaut 1x sur le plateau principal, multipliée par la case d'atterrissage.",
                        ],
                      }),
                      e.jsxs("li", {
                        children: [
                          e.jsx("strong", {
                            className: "text-white",
                            children: "Vortex Spin",
                          }),
                          " — roue :",
                          " ",
                          l.vortexMultipliers.join("x, "),
                          "x. En Deluxe :",
                          " ",
                          l.deluxeVortexMultipliers.join("x, "),
                          "x.",
                        ],
                      }),
                      e.jsxs("li", {
                        children: [
                          e.jsx("strong", {
                            className: "text-white",
                            children: "Pulse Zone",
                          }),
                          " — 5 billes spéciales de",
                          " ",
                          l.pulseBallValues.join("x / "),
                          "x sur un plateau transformé : c'est la fonctionnalité la plus rentable, visez les bords du plateau.",
                        ],
                      }),
                      e.jsxs("li", {
                        children: [
                          e.jsxs("strong", {
                            className: "text-white",
                            children: [
                              "Deluxe Experience (",
                              l.deluxeCost,
                              "x mise)",
                            ],
                          }),
                          " — à n'acheter que sur un créneau vert : l'EV estimée du bonus haute volatilité y dépasse le coût.",
                        ],
                      }),
                      e.jsxs("li", {
                        children: [
                          e.jsx("strong", {
                            className: "text-white",
                            children: "Gestion de mise",
                          }),
                          " — mise de base basse pendant la phase de chasse aux scatters (≈",
                          t.status.spinsToBonus,
                          " spins), remontée uniquement dans la fenêtre favorable.",
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("footer", {
                className:
                  "glass rounded-2xl px-4 py-3 flex items-start gap-2 text-[10px] text-muted-foreground",
                children: [
                  e.jsx(L, { className: "w-3.5 h-3.5 shrink-0 mt-px" }),
                  e.jsx("p", {
                    children:
                      "Modèle statistique basé sur la math officielle du jeu (RTP 95 %, paytable, mécaniques Vortex / Pulse Zone) et un cycle d'affluence horaire. Splinko Deluxe utilise un RNG certifié : aucune heure ne garantit un gain. Jouez de manière responsable.",
                  }),
                ],
              }),
            ],
          })
        : e.jsx("div", {
            className: "glass rounded-2xl p-6 text-sm text-muted-foreground",
            children: "Analyse en cours…",
          }),
    ],
  });
}
function u({ label: s, value: r, sub: t, accent: a }) {
  return e.jsxs("div", {
    className:
      "rounded-xl border border-white/[0.08] bg-white/[0.04] px-3 py-2.5",
    children: [
      e.jsx("p", {
        className: "text-[10px] uppercase tracking-wider text-muted-foreground",
        children: s,
      }),
      e.jsx("p", {
        className: `font-display font-black text-base sm:text-lg ${a ?? "text-white"}`,
        children: r,
      }),
      t &&
        e.jsx("p", {
          className: "text-[10px] text-muted-foreground",
          children: t,
        }),
    ],
  });
}
export { G as component };
