import {
  d as b,
  e as g,
  r as s,
  f as h,
  j as e,
  T as k,
  C as u,
  g as F,
  N as C,
} from "./index-C5ThNCN-.js";
import { D as I } from "./DashboardLayout-XCzqIJrp.js";
import { G as S } from "./graduation-cap-XZTeMn7p.js";
import { L as D } from "./lock-DtZN1438.js";
import { Z as P } from "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const A = b({ method: "POST" }).handler(
    g("d0b1bdd0433976d98f511a31f78d3b68dcaf12abb96776d9c165e8a8fea424d4"),
  ),
  E = b({ method: "POST" }).handler(
    g("fb1ae5c4d37c0ca8ed7a6f21b1662684347816bb0a88836dbabdd0a927d35bb7"),
  ),
  _ = [
    "Accès au salon privé « groupe-de-formation-vip »",
    "Tous nos échanges et explications en direct",
    "Rôle VIP Formation attribué automatiquement",
    "Durée : 6 mois complets",
  ];
function z() {
  const [o, w] = s.useState(""),
    [c, j] = s.useState(""),
    [d, x] = s.useState(!1),
    [m, i] = s.useState(null),
    [n, N] = s.useState(null),
    [l, p] = s.useState(!1),
    v = h(A),
    f = h(E);
  s.useEffect(() => {
    if (
      typeof window > "u" ||
      new URLSearchParams(window.location.search).get("paid") !== "1"
    )
      return;
    const a = localStorage.getItem("formation_pending_ref");
    a &&
      (p(!0),
      f({ data: { reference: a } })
        .then((r) => {
          r.ok
            ? (N({
                expiresAt: r.expiresAt,
                roleGranted: "roleGranted" in r ? r.roleGranted : void 0,
              }),
              localStorage.removeItem("formation_pending_ref"))
            : i(r.error ?? "Paiement non confirmé");
        })
        .catch(() => i("Impossible de vérifier le paiement"))
        .finally(() => p(!1)));
  }, [f]);
  async function y() {
    if ((i(null), !/^\d{15,25}$/.test(o.trim()))) {
      i(
        "Entrez votre identifiant Discord (15 à 25 chiffres). Voir l'aide ci-dessous.",
      );
      return;
    }
    x(!0);
    try {
      const t = (() => {
          try {
            return window.top?.location.origin ?? window.location.origin;
          } catch {
            return window.location.origin;
          }
        })(),
        a = await v({
          data: {
            discordUserId: o.trim(),
            discordUsername: c.trim() || void 0,
            origin: t,
          },
        });
      try {
        localStorage.setItem("formation_pending_ref", a.reference);
      } catch {}
      if (!window.open(a.checkoutUrl, "_blank", "noopener,noreferrer"))
        try {
          window.top && window.top !== window.self
            ? (window.top.location.href = a.checkoutUrl)
            : (window.location.href = a.checkoutUrl);
        } catch {
          window.location.href = a.checkoutUrl;
        }
    } catch (t) {
      i(t?.message ?? "Impossible d'initier le paiement");
    } finally {
      x(!1);
    }
  }
  return e.jsxs(I, {
    children: [
      e.jsxs("header", {
        className:
          "rounded-3xl border border-white/[0.08] bg-gradient-to-br from-[#0b1a2e] via-[#0a1220] to-[#0b0916] px-4 sm:px-6 py-6 text-center relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(56,189,248,0.22),transparent_60%)]",
          }),
          e.jsxs("h1", {
            className:
              "relative font-display font-black text-2xl sm:text-3xl tracking-tight flex items-center justify-center gap-2",
            children: [
              e.jsx(S, { className: "w-7 h-7 text-sky-400" }),
              "VIP ",
              e.jsx("span", {
                className:
                  "italic text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300",
                children: "FORMATION",
              }),
            ],
          }),
          e.jsx("p", {
            className: "relative text-sm text-white/60 mt-2",
            children:
              "Le salon privé Discord de la formation — 25 000 FCFA pour 6 mois",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-3",
        children: [
          e.jsxs("aside", {
            className:
              "rounded-2xl border border-white/[0.08] bg-[#0B1220] p-4 flex flex-col gap-4",
            children: [
              e.jsxs("div", {
                className: "text-center",
                children: [
                  e.jsx("p", {
                    className: "text-[10px] tracking-[0.2em] text-white/50",
                    children: "ABONNEMENT",
                  }),
                  e.jsxs("p", {
                    className:
                      "font-display font-black text-3xl text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300",
                    children: [
                      "25 000 ",
                      e.jsx("span", {
                        className: "text-base",
                        children: "FCFA",
                      }),
                    ],
                  }),
                  e.jsxs("p", {
                    className:
                      "text-[11px] text-white/50 mt-1 flex items-center justify-center gap-1",
                    children: [
                      e.jsx(k, { className: "w-3 h-3" }),
                      " 6 mois d'accès",
                    ],
                  }),
                ],
              }),
              e.jsx("ul", {
                className: "flex flex-col gap-1.5",
                children: _.map((t) =>
                  e.jsxs(
                    "li",
                    {
                      className:
                        "flex items-center gap-2 text-xs text-white/85",
                      children: [
                        e.jsx(u, {
                          className: "w-3.5 h-3.5 text-emerald-400 shrink-0",
                        }),
                        t,
                      ],
                    },
                    t,
                  ),
                ),
              }),
              e.jsxs("div", {
                className:
                  "mt-auto pt-3 border-t border-white/[0.06] flex items-start gap-2",
                children: [
                  e.jsx(F, {
                    className: "w-4 h-4 text-sky-400 shrink-0 mt-0.5",
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("p", {
                        className: "text-[11px] font-bold",
                        children: "Accès automatique",
                      }),
                      e.jsx("p", {
                        className: "text-[10px] text-white/50",
                        children:
                          "Le rôle VIP Formation vous est donné dès le paiement confirmé.",
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsx("section", {
            className:
              "rounded-2xl border border-white/[0.08] bg-[#0B1220] p-4 flex flex-col gap-4",
            children: n
              ? e.jsxs("div", {
                  className:
                    "rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-6 text-center flex flex-col items-center gap-2",
                  children: [
                    e.jsx(u, { className: "w-8 h-8 text-emerald-400" }),
                    e.jsx("p", {
                      className: "font-display font-black text-lg",
                      children: "Bienvenue dans la Formation !",
                    }),
                    e.jsxs("p", {
                      className: "text-sm text-white/70",
                      children: [
                        "Votre rôle VIP Formation est actif jusqu'au",
                        " ",
                        e.jsx("b", {
                          children: new Date(n.expiresAt).toLocaleDateString(
                            "fr-FR",
                          ),
                        }),
                        ".",
                      ],
                    }),
                    n.roleGranted === !1 &&
                      e.jsx("p", {
                        className: "text-xs text-amber-300",
                        children:
                          "Le rôle n'a pas pu être donné automatiquement — contactez @Haga48 avec votre référence.",
                      }),
                    e.jsx("p", {
                      className: "text-xs text-white/50",
                      children:
                        "Ouvrez Discord : le salon « groupe-de-formation-vip » est maintenant visible.",
                    }),
                  ],
                })
              : e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("h2", {
                      className: "font-display font-bold text-base",
                      children: "Vos informations Discord",
                    }),
                    e.jsxs("div", {
                      className: "flex flex-col gap-1.5",
                      children: [
                        e.jsx("label", {
                          className: "text-[11px] font-bold text-white/60",
                          children: "Identifiant Discord (obligatoire)",
                        }),
                        e.jsx("input", {
                          value: o,
                          onChange: (t) => w(t.target.value.replace(/\D/g, "")),
                          placeholder: "Ex : 123456789012345678",
                          className:
                            "h-11 rounded-xl border border-white/10 bg-black/40 px-3 text-sm outline-none focus:border-sky-400",
                        }),
                        e.jsx("p", {
                          className:
                            "text-[10px] text-white/40 leading-relaxed",
                          children:
                            "Pour le trouver : Discord → Paramètres → Avancés → activez « Mode développeur », puis clic droit sur votre profil → « Copier l'identifiant ». Vous devez déjà être membre du serveur.",
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "flex flex-col gap-1.5",
                      children: [
                        e.jsx("label", {
                          className: "text-[11px] font-bold text-white/60",
                          children: "Pseudo Discord (facultatif)",
                        }),
                        e.jsx("input", {
                          value: c,
                          onChange: (t) => j(t.target.value),
                          placeholder: "Ex : firmin_k",
                          className:
                            "h-11 rounded-xl border border-white/10 bg-black/40 px-3 text-sm outline-none focus:border-sky-400",
                        }),
                      ],
                    }),
                    m &&
                      e.jsx("div", {
                        className:
                          "rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200",
                        children: m,
                      }),
                    e.jsx("button", {
                      onClick: y,
                      disabled: d || l,
                      className:
                        "relative h-11 w-full rounded-xl bg-gradient-to-r from-sky-500 to-cyan-400 font-display font-black tracking-wider text-black text-sm shadow-lg shadow-sky-500/40 disabled:opacity-60 transition flex items-center justify-center gap-2",
                      children:
                        d || l
                          ? e.jsxs(e.Fragment, {
                              children: [
                                e.jsx(C, { className: "w-4 h-4 animate-spin" }),
                                l ? "VÉRIFICATION…" : "REDIRECTION…",
                              ],
                            })
                          : e.jsxs(e.Fragment, {
                              children: [
                                e.jsx(D, { className: "w-4 h-4" }),
                                "PAYER 25 000 FCFA",
                              ],
                            }),
                    }),
                    e.jsxs("p", {
                      className:
                        "text-center text-[11px] text-white/50 flex items-center justify-center gap-1",
                      children: [
                        e.jsx(P, { className: "w-3 h-3 text-sky-400" }),
                        " Mobile Money, carte bancaire, USDT — paiement sécurisé",
                      ],
                    }),
                  ],
                }),
          }),
        ],
      }),
    ],
  });
}
export { z as component };
