import {
  aq as b,
  f as u,
  ar as g,
  r as n,
  j as e,
  N as j,
  ao as w,
  C as y,
  a as k,
  k as p,
} from "./index-C5ThNCN-.js";
import { D as v } from "./DashboardLayout-XCzqIJrp.js";
import { a as N } from "./geniuspay.functions-D_URgro5.js";
import { C as f } from "./circle-alert-Adrk4haQ.js";
import { C as F } from "./circle-check-B56GEMOe.js";
import { A as C } from "./arrow-right-vdV6jsVn.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
function q() {
  const i = b({ from: "/paiement/succes" }),
    a =
      i.ref ??
      i.reference ??
      (typeof window < "u"
        ? (localStorage.getItem("lj_pending_ref") ?? void 0)
        : void 0),
    c = u(N),
    d = u(g),
    [t, r] = n.useState({ kind: "loading" }),
    [h, l] = n.useState(!1);
  return (
    n.useEffect(() => {
      if (!a) {
        r({ kind: "error", msg: "Aucune référence de transaction." });
        return;
      }
      c({ data: { reference: a } })
        .then(async (s) => {
          if (!s.ok) {
            s.status && s.status !== "completed"
              ? r({ kind: "pending", status: s.status })
              : r({ kind: "error", msg: s.error ?? "Vérification impossible" });
            return;
          }
          let m = !1;
          const o = s.key;
          if (o)
            try {
              const x = await d({ data: { key: o } });
              x.ok &&
                (localStorage.setItem("lj_access_token", x.token),
                window.dispatchEvent(new Event("lj-access-unlocked")),
                (m = !0));
            } catch {}
          r({
            kind: "success",
            key: o,
            durationDays: s.durationDays,
            already: !!s.alreadyCredited,
            autoActivated: m,
          });
          try {
            localStorage.removeItem("lj_pending_ref");
          } catch {}
        })
        .catch((s) => r({ kind: "error", msg: s?.message ?? "Erreur" }));
    }, [a, c, d]),
    e.jsxs(v, {
      children: [
        t.kind === "loading" &&
          e.jsxs("div", {
            className:
              "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-8 text-center flex flex-col items-center gap-3",
            children: [
              e.jsx(j, { className: "w-8 h-8 text-[#7B2FFF] animate-spin" }),
              e.jsx("p", {
                className: "text-white/70",
                children: "Vérification du paiement…",
              }),
            ],
          }),
        t.kind === "pending" &&
          e.jsxs("div", {
            className:
              "rounded-2xl border border-amber-500/30 bg-gradient-to-br from-amber-500/10 via-[#0F0B1F] to-[#0B0916] p-6 sm:p-8 text-center flex flex-col items-center gap-3",
            children: [
              e.jsx(f, { className: "w-10 h-10 text-amber-400" }),
              e.jsx("h1", {
                className: "font-display font-bold text-xl",
                children: "Paiement en cours de traitement",
              }),
              e.jsxs("p", {
                className: "text-white/70 text-sm max-w-md",
                children: [
                  "Statut : ",
                  e.jsx("span", {
                    className: "font-mono",
                    children: t.status ?? "pending",
                  }),
                  ". Cette page se mettra à jour automatiquement.",
                ],
              }),
              e.jsx("button", {
                onClick: () => window.location.reload(),
                className:
                  "mt-2 px-4 py-2 rounded-xl bg-white/10 border border-white/20 text-sm",
                children: "Actualiser",
              }),
            ],
          }),
        t.kind === "success" &&
          e.jsxs("div", {
            className:
              "rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 via-[#0F0B1F] to-[#0B0916] p-6 sm:p-8 flex flex-col items-center gap-4 text-center",
            children: [
              e.jsx("div", {
                className:
                  "h-16 w-16 rounded-full bg-emerald-500/20 flex items-center justify-center",
                children: e.jsx(F, { className: "w-10 h-10 text-emerald-400" }),
              }),
              e.jsx("h1", {
                className: "font-display font-black text-2xl",
                children: t.already
                  ? "Paiement déjà crédité"
                  : "Paiement confirmé",
              }),
              e.jsxs("p", {
                className: "text-white/70 max-w-md text-sm",
                children: [
                  "Votre abonnement VIP Premium est actif pour ",
                  e.jsxs("b", { children: [t.durationDays, " jours"] }),
                  ".",
                  t.autoActivated &&
                    " Votre accès est déjà ouvert — vous pouvez continuer directement.",
                  t.key &&
                    " Conservez précieusement votre clé au cas où vous vous déconnecteriez :",
                  !t.key &&
                    !t.autoActivated &&
                    " Utilisez la clé qui vous a été fournie précédemment pour vous connecter.",
                ],
              }),
              t.key &&
                e.jsxs("div", {
                  className:
                    "w-full max-w-md flex items-center gap-2 rounded-xl border border-[#7B2FFF]/40 bg-black/40 p-3",
                  children: [
                    e.jsx(w, { className: "w-5 h-5 text-[#E040FB] shrink-0" }),
                    e.jsx("code", {
                      className:
                        "flex-1 font-mono text-sm sm:text-base tracking-wider text-emerald-300 truncate",
                      children: t.key,
                    }),
                    e.jsx("button", {
                      onClick: () => {
                        (navigator.clipboard.writeText(t.key),
                          l(!0),
                          setTimeout(() => l(!1), 1500));
                      },
                      className:
                        "p-2 rounded-lg bg-white/[0.05] hover:bg-white/[0.1]",
                      children: h
                        ? e.jsx(y, { className: "w-4 h-4 text-emerald-400" })
                        : e.jsx(k, { className: "w-4 h-4" }),
                    }),
                  ],
                }),
              e.jsxs(p, {
                to: "/dashboard",
                className:
                  "mt-2 inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] font-bold text-sm",
                children: ["Aller au dashboard ", e.jsx(C, { size: 16 })],
              }),
            ],
          }),
        t.kind === "error" &&
          e.jsxs("div", {
            className:
              "rounded-2xl border border-red-500/30 bg-gradient-to-br from-red-500/10 via-[#0F0B1F] to-[#0B0916] p-8 text-center flex flex-col items-center gap-3",
            children: [
              e.jsx(f, { className: "w-10 h-10 text-red-400" }),
              e.jsx("h1", {
                className: "font-display font-bold text-xl",
                children: "Erreur",
              }),
              e.jsx("p", {
                className: "text-white/70 text-sm max-w-md",
                children: t.msg,
              }),
              e.jsx(p, {
                to: "/boutique",
                className:
                  "mt-2 px-4 py-2 rounded-xl bg-white/10 border border-white/20 text-sm",
                children: "Retour à l'abonnement",
              }),
            ],
          }),
      ],
    })
  );
}
export { q as component };
