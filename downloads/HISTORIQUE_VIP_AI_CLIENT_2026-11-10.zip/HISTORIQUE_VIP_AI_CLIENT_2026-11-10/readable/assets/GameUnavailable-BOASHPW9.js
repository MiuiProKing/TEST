import { j as e, k as t, l as a } from "./index-C5ThNCN-.js";
import { D as s } from "./DashboardLayout-XCzqIJrp.js";
import { L as o } from "./lock-DtZN1438.js";
function x({ name: r }) {
  return e.jsx(s, {
    children: e.jsxs("div", {
      className: "glass rounded-3xl p-8 sm:p-12 text-center max-w-2xl mx-auto",
      children: [
        e.jsx("div", {
          className:
            "w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-5 shadow-[0_0_28px_var(--neon-purple-glow)]",
          children: e.jsx(o, {
            className: "w-7 h-7 text-[var(--neon-purple)]",
          }),
        }),
        e.jsxs("h1", {
          className:
            "font-display font-black text-2xl sm:text-3xl tracking-tight bg-gradient-to-r from-[var(--neon-purple)] via-[var(--neon-blue)] to-[var(--neon-orange)] bg-clip-text text-transparent",
          children: [r, " — Indisponible"],
        }),
        e.jsx("p", {
          className: "text-sm text-muted-foreground mt-3",
          children:
            "Ce jeu est temporairement verrouillé. Nous travaillons à sa remise en service. Merci de votre patience.",
        }),
        e.jsxs(t, {
          to: "/jeux",
          className:
            "inline-flex items-center gap-2 mt-6 px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 hover:border-[var(--neon-purple)]/40 hover:shadow-[0_0_20px_var(--neon-purple-glow)] transition text-sm font-semibold",
          children: [e.jsx(a, { className: "w-4 h-4" }), "Retour aux jeux"],
        }),
      ],
    }),
  });
}
export { x as G };
