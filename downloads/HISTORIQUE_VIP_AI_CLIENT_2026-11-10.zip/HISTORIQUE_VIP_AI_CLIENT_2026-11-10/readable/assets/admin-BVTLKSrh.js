import {
  c as k,
  d as C,
  e as A,
  f as c,
  r,
  j as e,
  C as ne,
  g as te,
  u as J,
  h as ye,
  i as Ne,
  L as re,
  m as le,
  k as oe,
  l as ie,
  n as ve,
  o as we,
  p as Se,
  q as ke,
  s as Ce,
  t as Ae,
  v as _e,
  w as Te,
  x as Le,
  y as De,
  z as Me,
  B as Re,
  D as Fe,
  a as se,
  K as Be,
  F as Ee,
} from "./index-C5ThNCN-.js";
import { A as q } from "./admin-CZk1hmsV.js";
import { B as Ie } from "./bot-BCqi2W7b.js";
import { R as G, B as U } from "./button-4JeZmZFi.js";
import { T as W } from "./trash-2-DSXLM6oL.js";
import { a as $e, b as Oe } from "./tools.functions-DgdA5Uci.js";
import { W as Pe, L as qe, S as Ke, C as Ue } from "./wrench-DMPf9Lxe.js";
import { B as ze, T as Ve } from "./triangle-alert-CzDFXfJ_.js";
import { U as Je } from "./users-DGoEMYbj.js";
const Ge = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "M4.929 4.929 19.07 19.071", key: "196cmz" }],
  ],
  We = k("ban", Ge);
const He = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "M8 12h8", key: "1wcyev" }],
  ],
  Xe = k("circle-minus", He);
const Ye = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "M8 12h8", key: "1wcyev" }],
    ["path", { d: "M12 8v8", key: "napkw2" }],
  ],
  Qe = k("circle-plus", Ye);
const Ze = [
    [
      "path",
      {
        d: "M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2",
        key: "18mbvz",
      },
    ],
    ["path", { d: "M6.453 15h11.094", key: "3shlmq" }],
    ["path", { d: "M8.5 2h7", key: "csnxdl" }],
  ],
  et = k("flask-conical", Ze);
const tt = [
    ["path", { d: "M9 17H7A5 5 0 0 1 7 7h2", key: "8i5ue5" }],
    ["path", { d: "M15 7h2a5 5 0 1 1 0 10h-2", key: "1b9ql8" }],
    ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }],
  ],
  st = k("link-2", tt);
const at = [
    [
      "path",
      {
        d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
        key: "1a8usu",
      },
    ],
    ["path", { d: "m15 5 4 4", key: "1mk7zo" }],
  ],
  nt = k("pencil", at);
const rt = [
    ["path", { d: "M5 12h14", key: "1ays0h" }],
    ["path", { d: "M12 5v14", key: "s699le" }],
  ],
  ce = k("plus", rt);
const lt = [
    ["path", { d: "M12 2v10", key: "mnfbl" }],
    ["path", { d: "M18.4 6.6a9 9 0 1 1-12.77.04", key: "obofu9" }],
  ],
  de = k("power", lt);
const ot = [
    ["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }],
    ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ],
  it = k("search", ot);
const ct = [
    [
      "path",
      {
        d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
        key: "oel41y",
      },
    ],
  ],
  z = k("shield", ct),
  dt = C({ method: "POST" }).handler(
    A("84e67445303e1d00b4555f0ac4133c71d04e8a393b9e56d3e35e2c89fc5e49b2"),
  ),
  mt = C({ method: "POST" }).handler(
    A("94443d33d2803b3d38cade33d5ffe0bf686c4330b1c33ab618adb28c68549ffb"),
  ),
  xt = C({ method: "POST" }).handler(
    A("4392043944561315dff65e7d9c148a66fd95c7bf3f7efa3d61d53946a9ca9249"),
  ),
  ut = C({ method: "POST" }).handler(
    A("5cdd2b4217ae7e42a52b0711bf673f7a7f420f68c4c707177cf5d3be9aa01a4b"),
  ),
  pt = C({ method: "POST" }).handler(
    A("a5337045024156f1a19de78331f15bf5fcd4255621e7a6d1487a2990dd430162"),
  );
function ht({ token: s }) {
  const m = c(dt),
    n = c(mt),
    x = c(xt),
    h = c(ut),
    u = c(pt),
    [i, p] = r.useState([]),
    [o, b] = r.useState(!1),
    [y, N] = r.useState(""),
    [f, _] = r.useState("https://t.me/babelseyy"),
    [v, S] = r.useState(null);
  async function d() {
    if (s) {
      b(!0);
      try {
        const l = await m({ data: { token: s } });
        p(l.bots);
      } catch (l) {
        S(String(l));
      } finally {
        b(!1);
      }
    }
  }
  r.useEffect(() => {
    d();
  }, [s]);
  async function g(l) {
    if ((l.preventDefault(), !!y.trim())) {
      b(!0);
      try {
        const a = await n({
          data: { token: s, botToken: y.trim(), linkUrl: f },
        });
        (S(a.ok ? `Bot @${a.username} ajouté.` : `Erreur : ${a.error}`),
          a.ok && (N(""), await u({ data: { token: s, slug: a.slug } })),
          await d());
      } finally {
        b(!1);
      }
    }
  }
  return e.jsxs("section", {
    className:
      "glass rounded-2xl p-3 sm:p-4 border border-[var(--neon-blue)]/25",
    children: [
      e.jsxs("div", {
        className: "flex items-center justify-between gap-3 flex-wrap mb-3",
        children: [
          e.jsxs("h2", {
            className: "font-display font-bold text-lg flex items-center gap-2",
            children: [
              e.jsx(Ie, { className: "w-4 h-4 text-[var(--neon-blue)]" }),
              " Bots Telegram",
              e.jsxs("span", {
                className: "text-xs text-muted-foreground font-mono",
                children: ["(", i.length, ")"],
              }),
            ],
          }),
          e.jsxs("button", {
            onClick: d,
            disabled: o,
            className:
              "rounded-xl px-3 py-1.5 text-xs font-mono bg-white/5 border border-white/10 hover:bg-white/10 disabled:opacity-40 flex items-center gap-1.5",
            children: [
              e.jsx(G, { className: "w-3 h-3" }),
              " ",
              o ? "…" : "Rafraîchir",
            ],
          }),
        ],
      }),
      e.jsxs("form", {
        onSubmit: g,
        className: "grid grid-cols-1 sm:grid-cols-6 gap-2 mb-4",
        children: [
          e.jsx("input", {
            value: y,
            onChange: (l) => N(l.target.value),
            placeholder: "Jeton du bot (BotFather)",
            "aria-label": "Jeton du bot Telegram",
            className:
              "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs font-mono outline-none sm:col-span-3",
          }),
          e.jsx("input", {
            value: f,
            onChange: (l) => _(l.target.value),
            placeholder: "Lien Telegram à partager",
            "aria-label": "Lien Telegram partagé par le bot",
            className:
              "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs font-mono outline-none sm:col-span-2",
          }),
          e.jsxs("button", {
            type: "submit",
            disabled: o,
            className:
              "rounded-xl py-2 font-display font-bold text-xs bg-gradient-to-r from-[var(--neon-blue)] to-[var(--neon-purple)] text-white disabled:opacity-50 flex items-center justify-center gap-1.5",
            children: [e.jsx(ce, { className: "w-3.5 h-3.5" }), " Connecter"],
          }),
        ],
      }),
      v &&
        e.jsx("p", {
          className: "text-[11px] font-mono text-muted-foreground mb-3",
          children: v,
        }),
      e.jsxs("div", {
        className: "space-y-2",
        children: [
          i.map((l) =>
            e.jsxs(
              "div",
              {
                className: "rounded-xl bg-black/25 border border-white/10 p-3",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex items-center justify-between gap-3 flex-wrap",
                    children: [
                      e.jsxs("div", {
                        className: "min-w-0",
                        children: [
                          e.jsxs("p", {
                            className:
                              "font-display font-bold text-sm flex items-center gap-2",
                            children: [
                              l.name,
                              e.jsx("span", {
                                className: `text-[10px] px-2 py-0.5 rounded-full font-mono ${l.active ? "bg-[var(--neon-green)]/15 text-[var(--neon-green)]" : "bg-white/10 text-muted-foreground"}`,
                                children: l.active ? "ACTIF" : "INACTIF",
                              }),
                              !l.hasToken &&
                                e.jsx("span", {
                                  className:
                                    "text-[10px] text-red-400 font-mono",
                                  children: "jeton manquant",
                                }),
                            ],
                          }),
                          e.jsxs("p", {
                            className:
                              "text-[11px] font-mono text-muted-foreground truncate",
                            children: [
                              "@",
                              l.username ?? "—",
                              " · ",
                              l.subscribers,
                              " abonné(s) · jeux : ",
                              l.games.join(", ") || "—",
                            ],
                          }),
                          e.jsxs("p", {
                            className:
                              "text-[10px] font-mono text-muted-foreground truncate",
                            children: [
                              "webhook : ",
                              l.webhookUrl ?? "non configuré",
                              l.lastError ? ` · erreur : ${l.lastError}` : "",
                            ],
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsxs("button", {
                            onClick: async () => {
                              const a = await u({
                                data: { token: s, slug: l.slug },
                              });
                              (S(
                                a.ok
                                  ? `Webhook configuré : ${a.url}`
                                  : `Erreur : ${a.error}`,
                              ),
                                d());
                            },
                            title: "(Re)configurer le webhook et les commandes",
                            className:
                              "rounded-lg px-2.5 py-1.5 text-[11px] font-mono bg-white/5 border border-white/10 hover:bg-white/10 flex items-center gap-1",
                            children: [
                              e.jsx(st, { className: "w-3 h-3" }),
                              " Webhook",
                            ],
                          }),
                          e.jsxs("button", {
                            onClick: async () => {
                              (await x({
                                data: {
                                  token: s,
                                  slug: l.slug,
                                  active: !l.active,
                                },
                              }),
                                d());
                            },
                            title: l.active ? "Désactiver" : "Activer",
                            className:
                              "rounded-lg px-2.5 py-1.5 text-[11px] font-mono bg-white/5 border border-white/10 hover:bg-white/10 flex items-center gap-1",
                            children: [
                              e.jsx(de, { className: "w-3 h-3" }),
                              " ",
                              l.active ? "Off" : "On",
                            ],
                          }),
                          e.jsx("button", {
                            onClick: async () => {
                              confirm(`Supprimer ${l.name} ?`) &&
                                (await h({ data: { token: s, slug: l.slug } }),
                                d());
                            },
                            title: "Supprimer le bot",
                            className:
                              "rounded-lg px-2.5 py-1.5 text-[11px] font-mono bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20",
                            children: e.jsx(W, { className: "w-3 h-3" }),
                          }),
                        ],
                      }),
                    ],
                  }),
                  e.jsx("div", {
                    className:
                      "flex items-center gap-3 mt-2 text-[11px] font-mono",
                    children: ["luckyjet", "jetx"].map((a) =>
                      e.jsxs(
                        "label",
                        {
                          className: "flex items-center gap-1.5 cursor-pointer",
                          children: [
                            e.jsx("input", {
                              type: "checkbox",
                              checked: l.games.includes(a),
                              onChange: async (T) => {
                                const F = T.target.checked
                                  ? [...new Set([...l.games, a])]
                                  : l.games.filter((B) => B !== a);
                                (await x({
                                  data: { token: s, slug: l.slug, games: F },
                                }),
                                  d());
                              },
                            }),
                            a === "luckyjet"
                              ? "LuckyJet (1win)"
                              : "JetX (Betclic)",
                          ],
                        },
                        a,
                      ),
                    ),
                  }),
                ],
              },
              l.slug,
            ),
          ),
          i.length === 0 &&
            e.jsx("p", {
              className: "text-xs text-muted-foreground font-mono",
              children: "Aucun bot connecté.",
            }),
        ],
      }),
    ],
  });
}
const ft = {
  api_history: "API Historique",
  telegram_managed: "Telegram clé en main",
  telegram_custom: "Telegram sur mesure",
};
function gt({ token: s }) {
  const m = c($e),
    n = c(Oe),
    [x, h] = r.useState([]),
    [u, i] = r.useState(!1);
  async function p() {
    if (s) {
      i(!0);
      try {
        const o = await m({ data: { token: s } });
        h(o.orders);
      } finally {
        i(!1);
      }
    }
  }
  return (
    r.useEffect(() => {
      p();
    }, [s]),
    e.jsxs("section", {
      className:
        "glass rounded-2xl p-3 sm:p-4 border border-[var(--neon-purple)]/25",
      children: [
        e.jsxs("div", {
          className: "flex items-center justify-between gap-3 flex-wrap mb-3",
          children: [
            e.jsxs("h2", {
              className: "font-bold flex items-center gap-2",
              children: [
                e.jsx(Pe, { size: 16 }),
                " Commandes d'outils (",
                x.length,
                ")",
              ],
            }),
            e.jsxs("button", {
              onClick: p,
              className:
                "px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs inline-flex items-center gap-1.5",
              children: [
                e.jsx(G, { size: 13, className: u ? "animate-spin" : "" }),
                " Actualiser",
              ],
            }),
          ],
        }),
        x.length === 0 &&
          e.jsx("p", {
            className: "text-sm text-muted-foreground",
            children: "Aucune commande pour le moment.",
          }),
        e.jsx("div", {
          className: "space-y-2",
          children: x.map((o) =>
            e.jsx(
              "div",
              {
                className:
                  "rounded-xl border border-white/10 bg-black/30 p-3 text-sm",
                children: e.jsxs("div", {
                  className:
                    "flex items-center justify-between gap-2 flex-wrap",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsxs("p", {
                          className: "font-semibold",
                          children: [
                            ft[o.product] ?? o.product,
                            " — ",
                            o.customerName,
                          ],
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-muted-foreground",
                          children: [
                            o.contact,
                            o.telegram ? ` · ${o.telegram}` : "",
                            " · ",
                            o.amount.toLocaleString("fr-FR"),
                            " FCFA ·",
                            " ",
                            new Date(o.createdAt).toLocaleString("fr-FR"),
                          ],
                        }),
                        o.games.length > 0 &&
                          e.jsxs("p", {
                            className: "text-xs text-white/60 mt-1",
                            children: ["Jeux : ", o.games.join(", ")],
                          }),
                        o.note &&
                          e.jsxs("p", {
                            className: "text-xs text-white/60 mt-1",
                            children: ["Note : ", o.note],
                          }),
                        o.paymentReference &&
                          e.jsx("p", {
                            className:
                              "text-[11px] font-mono text-white/40 mt-1",
                            children: o.paymentReference,
                          }),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        e.jsxs("select", {
                          value: o.status,
                          onChange: async (b) => {
                            (await n({
                              data: {
                                token: s,
                                id: o.id,
                                status: b.target.value,
                              },
                            }),
                              p());
                          },
                          className:
                            "rounded-lg bg-black/50 border border-white/15 px-2 py-1.5 text-xs",
                          children: [
                            e.jsx("option", {
                              value: "pending",
                              children: "En attente",
                            }),
                            e.jsx("option", {
                              value: "paid",
                              children: "Payé",
                            }),
                            e.jsx("option", {
                              value: "active",
                              children: "Actif",
                            }),
                            e.jsx("option", {
                              value: "cancelled",
                              children: "Annulé",
                            }),
                          ],
                        }),
                        o.status === "active" &&
                          e.jsx(ne, {
                            size: 16,
                            className: "text-emerald-400",
                          }),
                        e.jsx("button", {
                          onClick: async () => {
                            (await n({
                              data: { token: s, id: o.id, remove: !0 },
                            }),
                              p());
                          },
                          className:
                            "p-1.5 rounded-lg bg-red-500/15 text-red-400 border border-red-500/30",
                          "aria-label": "Supprimer la commande",
                          children: e.jsx(W, { size: 14 }),
                        }),
                      ],
                    }),
                  ],
                }),
              },
              o.id,
            ),
          ),
        }),
      ],
    })
  );
}
const bt = C({ method: "POST" }).handler(
    A("b3b6fddeb16da0f20d89c0079696b5dfd5b5c2bcd0de7bd38f7b0d4988528ce5"),
  ),
  jt = C({ method: "POST" }).handler(
    A("e39b73156b05dbef9c141bcde5d09e6ac035bb8600223a0cf8391fbcecda44dd"),
  ),
  yt = C({ method: "POST" }).handler(
    A("1906019542f9ba4265d5b7bd50df59814de23b425d5316fd3644c5084e7a9033"),
  ),
  Nt = C({ method: "POST" }).handler(
    A("66bbb9737f20c43569c75db85fd30a042a03bffe3fdbb27d37a4e9f6652281a5"),
  ),
  ae = [
    "luckyjet",
    "astronaut",
    "rocketqueen",
    "aviator",
    "aviator_1win",
    "crash",
    "crash_1xbet",
    "jetx",
    "jetx_1win",
    "dragonscrash",
    "highflyer",
  ];
function vt({ token: s }) {
  const m = c(yt),
    n = c(jt),
    x = c(Nt),
    h = c(bt),
    [u, i] = r.useState(null),
    [p, o] = r.useState([]),
    [b, y] = r.useState("luckyjet"),
    [N, f] = r.useState(!1),
    [_, v] = r.useState(null);
  async function S() {
    o(await m({ data: { token: s } }));
  }
  r.useEffect(() => {
    S().catch(() => v("Rapports indisponibles."));
  }, [s]);
  const d = p[0],
    g = d?.report,
    l = (a) => (a == null ? "—" : `${(a * 100).toFixed(1)} %`);
  return e.jsxs("section", {
    className: "border-t border-border py-6 space-y-4",
    "aria-label": "Contrôles et évaluation IA",
    children: [
      e.jsxs("div", {
        className: "flex flex-wrap items-center justify-between gap-3",
        children: [
          e.jsxs("h2", {
            className: "font-display font-bold text-lg flex items-center gap-2",
            children: [
              e.jsx(te, { className: "size-5 text-primary" }),
              "Contrôles et évaluation IA",
            ],
          }),
          e.jsx(U, {
            size: "icon",
            variant: "ghost",
            "aria-label": "Actualiser les rapports",
            title: "Actualiser les rapports",
            onClick: () => S().catch(() => v("Rapports indisponibles.")),
            children: e.jsx(G, {}),
          }),
        ],
      }),
      e.jsxs("p", {
        className: "text-sm text-muted-foreground",
        children: [
          "Vigile : ",
          u
            ? `accès confirmé le ${new Date(u.checkedAt).toLocaleString("fr-FR")}`
            : "identifiant reçu, accès à vérifier",
          " · surveillance quotidienne inactive · corrections automatiques désactivées.",
        ],
      }),
      e.jsxs("div", {
        className: "flex flex-wrap gap-3",
        children: [
          e.jsxs(U, {
            variant: "outline",
            disabled: N,
            onClick: async () => {
              (f(!0), v(null), i(null));
              try {
                i(await h({ data: { token: s } }));
              } catch (a) {
                v(a instanceof Error ? a.message : "Vérification impossible.");
              } finally {
                f(!1);
              }
            },
            children: [e.jsx(te, {}), "Vérifier Vigile"],
          }),
          e.jsx("select", {
            "aria-label": "Jeu à évaluer",
            className:
              "bg-background text-foreground border border-input rounded-md px-3 py-2",
            value: b,
            onChange: (a) => {
              const T = ae.find((F) => F === a.target.value);
              T && y(T);
            },
            children: ae.map((a) =>
              e.jsx(
                "option",
                { value: a, children: a.replaceAll("_", " ") },
                a,
              ),
            ),
          }),
          e.jsxs(U, {
            variant: "outline",
            disabled: N,
            onClick: async () => {
              (f(!0), v(null));
              try {
                (await n({ data: { token: s, game: b } }), await S());
              } catch (a) {
                v(a instanceof Error ? a.message : "Évaluation impossible.");
              } finally {
                f(!1);
              }
            },
            children: [
              e.jsx(et, {}),
              N ? "Traitement…" : "Évaluer l'historique",
            ],
          }),
          e.jsxs(U, {
            disabled: N || !d || !!d.claude_review,
            onClick: async () => {
              if (d) {
                (f(!0), v(null));
                try {
                  (await x({ data: { token: s, id: d.id } }), await S());
                } catch (a) {
                  v(a instanceof Error ? a.message : "Analyse indisponible.");
                } finally {
                  f(!1);
                }
              }
            },
            children: [e.jsx(ze, {}), "Analyser avec Claude"],
          }),
        ],
      }),
      _ &&
        e.jsx("p", {
          role: "alert",
          className: "text-sm text-destructive",
          children: _,
        }),
      !g &&
        e.jsx("p", {
          className: "text-sm text-muted-foreground",
          children: "Aucun rapport enregistré.",
        }),
      g &&
        e.jsxs(e.Fragment, {
          children: [
            e.jsxs("p", {
              className: "text-sm font-mono",
              children: [
                d?.game,
                " · ",
                g.total.toLocaleString("fr-FR"),
                " tours · ",
                new Date(g.from ?? 0).toLocaleString("fr-FR"),
                " → ",
                new Date(g.to ?? 0).toLocaleString("fr-FR"),
              ],
            }),
            e.jsxs("div", {
              className: "grid grid-cols-2 md:grid-cols-4 gap-4 text-sm",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx("p", {
                      className: "text-muted-foreground",
                      children: "Période finale indépendante",
                    }),
                    e.jsxs("strong", { children: [g.holdout, " tours"] }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx("p", {
                      className: "text-muted-foreground",
                      children: "Fenêtres évaluées",
                    }),
                    e.jsx("strong", { children: g.currentAlgorithm.evaluated }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx("p", {
                      className: "text-muted-foreground",
                      children: "Cible atteinte dans la fenêtre",
                    }),
                    e.jsx("strong", {
                      children: l(g.currentAlgorithm.observedRate),
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx("p", {
                      className: "text-muted-foreground",
                      children: "Interruptions & fenêtres exclues",
                    }),
                    e.jsxs("strong", {
                      children: [
                        g.gaps,
                        " / ",
                        g.currentAlgorithm.excludedForMissingData,
                      ],
                    }),
                  ],
                }),
              ],
            }),
            e.jsx("div", {
              className: "overflow-x-auto",
              children: e.jsxs("table", {
                className: "w-full text-sm text-left",
                children: [
                  e.jsx("thead", {
                    children: e.jsxs("tr", {
                      className: "border-b border-border",
                      children: [
                        e.jsx("th", { className: "py-2", children: "Seuil" }),
                        e.jsx("th", { children: "Fréquence initiale" }),
                        e.jsx("th", { children: "Fréquence finale" }),
                        e.jsx("th", { children: "Erreur Brier" }),
                      ],
                    }),
                  }),
                  e.jsx("tbody", {
                    children: g.baseline.map((a) =>
                      e.jsxs(
                        "tr",
                        {
                          className: "border-b border-border",
                          children: [
                            e.jsxs("td", {
                              className: "py-2",
                              children: ["≥ ", a.threshold, "×"],
                            }),
                            e.jsx("td", { children: l(a.trainingRate) }),
                            e.jsx("td", { children: l(a.testRate) }),
                            e.jsx("td", { children: a.brier.toFixed(4) }),
                          ],
                        },
                        a.threshold,
                      ),
                    ),
                  }),
                ],
              }),
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Échantillon limité aux 5 000 derniers tours réels disponibles. Le score interne n’est pas un taux de réussite. Les fenêtres correspondent à un événement dans un intervalle, pas au prochain tour.",
            }),
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children: g.promotion,
            }),
            g.highCoefficients &&
              e.jsxs("div", {
                className: "space-y-3",
                children: [
                  e.jsx("h3", {
                    className: "font-semibold",
                    children: "Évaluation grosses cotes · 5 tours suivants",
                  }),
                  e.jsx("div", {
                    className: "overflow-x-auto",
                    children: e.jsxs("table", {
                      className: "w-full text-sm text-left",
                      children: [
                        e.jsx("thead", {
                          children: e.jsxs("tr", {
                            className: "border-b border-border",
                            children: [
                              e.jsx("th", {
                                className: "py-2",
                                children: "Cible",
                              }),
                              e.jsx("th", { children: "Méthode retenue" }),
                              e.jsx("th", { children: "Fenêtres / réussites" }),
                              e.jsx("th", {
                                children: "Brier référence / candidat",
                              }),
                              e.jsx("th", { children: "Conclusion" }),
                            ],
                          }),
                        }),
                        e.jsx("tbody", {
                          children: g.highCoefficients.comparisons.map((a) =>
                            e.jsxs(
                              "tr",
                              {
                                className: "border-b border-border",
                                children: [
                                  e.jsxs("td", {
                                    className: "py-2",
                                    children: ["≥ ", a.threshold, "×"],
                                  }),
                                  e.jsx("td", {
                                    children:
                                      a.selectedMethod === "baseline"
                                        ? "Fréquence historique"
                                        : a.selectedMethod === "cluster"
                                          ? "Concentration ≥20×"
                                          : "Série de 5 tours <2×",
                                  }),
                                  e.jsxs("td", {
                                    children: [
                                      a.testWindows,
                                      " / ",
                                      a.testEvents,
                                    ],
                                  }),
                                  e.jsxs("td", {
                                    children: [
                                      a.baselineBrier?.toFixed(4) ?? "—",
                                      " / ",
                                      a.candidateBrier?.toFixed(4) ?? "—",
                                    ],
                                  }),
                                  e.jsx("td", { children: a.evidence }),
                                ],
                              },
                              a.threshold,
                            ),
                          ),
                        }),
                      ],
                    }),
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children: g.highCoefficients.activation,
                  }),
                ],
              }),
            d?.claude_review &&
              e.jsx("p", {
                className:
                  "whitespace-pre-wrap text-sm border-l-2 border-primary pl-4",
                children: d.claude_review,
              }),
            e.jsxs("details", {
              children: [
                e.jsx("summary", {
                  className: "cursor-pointer text-sm",
                  children: "Rapport privé complet",
                }),
                e.jsx("pre", {
                  className:
                    "max-h-72 overflow-auto text-xs mt-3 whitespace-pre-wrap break-all",
                  children: JSON.stringify(d?.report, null, 2),
                }),
              ],
            }),
          ],
        }),
    ],
  });
}
function Et() {
  const { t: s } = J(),
    [m, n] = r.useState(null),
    [x, h] = r.useState(!1),
    u = c(ye);
  return (
    r.useEffect(() => {
      if (typeof window > "u") return;
      const i = localStorage.getItem(q);
      if (!i) {
        h(!0);
        return;
      }
      u({ data: { token: i } })
        .then((p) => {
          p.ok ? n(i) : localStorage.removeItem(q);
        })
        .catch(() => localStorage.removeItem(q))
        .finally(() => h(!0));
    }, [u]),
    x
      ? m
        ? e.jsx(St, {
            token: m,
            onLogout: () => {
              (localStorage.removeItem(q), n(null));
            },
          })
        : e.jsx(wt, {
            onAuth: (i) => {
              (localStorage.setItem(q, i), n(i));
            },
          })
      : null
  );
}
function wt({ onAuth: s }) {
  const { t: m } = J(),
    n = c(Ne),
    [x, h] = r.useState(""),
    [u, i] = r.useState(null),
    [p, o] = r.useState(!1);
  async function b(y) {
    (y.preventDefault(), o(!0), i(null));
    try {
      const N = await n({ data: { password: x } });
      N.ok ? s(N.token) : i(m("admin.bad_password"));
    } finally {
      o(!1);
    }
  }
  return e.jsxs("div", {
    className: "min-h-screen flex items-center justify-center px-4",
    children: [
      e.jsx("div", {
        className: "absolute top-4 right-4",
        children: e.jsx(re, {}),
      }),
      e.jsxs(le.div, {
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
        className: "glass rounded-3xl p-8 max-w-md w-full",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-3 mb-6",
            children: [
              e.jsx("div", {
                className:
                  "w-12 h-12 rounded-2xl bg-gradient-to-br from-[var(--neon-orange)] to-[var(--neon-purple)] flex items-center justify-center",
                children: e.jsx(z, { className: "w-6 h-6 text-white" }),
              }),
              e.jsx("h1", {
                className: "font-display font-bold text-2xl",
                children: m("admin.title"),
              }),
            ],
          }),
          e.jsxs("form", {
            onSubmit: b,
            className: "flex flex-col gap-4",
            children: [
              e.jsx("input", {
                type: "password",
                value: x,
                onChange: (y) => h(y.target.value),
                placeholder: m("admin.login"),
                "aria-label": m("admin.login"),
                autoFocus: !0,
                className:
                  "bg-black/30 border border-white/10 rounded-2xl px-4 py-3 font-mono text-sm outline-none focus:border-[var(--neon-purple)]/60",
              }),
              u &&
                e.jsx("p", {
                  className: "text-xs text-[var(--neon-orange)] font-mono",
                  children: u,
                }),
              e.jsx("button", {
                type: "submit",
                disabled: p,
                className:
                  "rounded-2xl py-3 font-display font-bold text-sm bg-gradient-to-r from-[var(--neon-purple)] to-[var(--neon-blue)] text-white disabled:opacity-50",
                children: m("admin.signin"),
              }),
            ],
          }),
          e.jsxs(oe, {
            to: "/",
            className:
              "mt-6 flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors",
            children: [e.jsx(ie, { className: "w-3 h-3" }), " Retour"],
          }),
        ],
      }),
    ],
  });
}
function St({ token: s, onLogout: m }) {
  const { t: n } = J(),
    x = c(ve),
    h = c(we),
    u = c(Se),
    i = c(ke),
    p = c(Ce),
    o = c(Ae),
    b = c(_e),
    y = c(Te),
    N = c(Le),
    f = c(De),
    _ = c(Me),
    v = c(Re),
    S = c(Fe),
    [d, g] = r.useState([]),
    [l, a] = r.useState([]),
    [T, F] = r.useState([]),
    [B, me] = r.useState([]),
    [K, H] = r.useState(""),
    [E, X] = r.useState(""),
    [I, Y] = r.useState(""),
    [R, xe] = r.useState("30"),
    [Q, ue] = r.useState("1"),
    [$, O] = r.useState(null),
    [pe, Z] = r.useState(null),
    [P, he] = r.useState(""),
    [D, fe] = r.useState("all"),
    V = d.filter((t) => {
      if (P.trim()) {
        const L = P.trim().toLowerCase();
        if (!(t.label || "").toLowerCase().includes(L)) return !1;
      }
      const j = t.source ?? "manual";
      return !(
        (D === "paid" && j !== "geniuspay") ||
        (D === "gifted" && j !== "admin_grant") ||
        (D === "activated" && !t.activated_at) ||
        (D === "pending" && t.activated_at)
      );
    }),
    ge = {
      all: d.length,
      paid: d.filter((t) => (t.source ?? "manual") === "geniuspay").length,
      gifted: d.filter((t) => (t.source ?? "manual") === "admin_grant").length,
      activated: d.filter((t) => !!t.activated_at).length,
      pending: d.filter((t) => !t.activated_at).length,
    };
  async function w() {
    try {
      const [t, j, L, M] = await Promise.all([
        x({ data: { token: s } }),
        o({ data: { token: s } }),
        b({ data: { token: s } }),
        y({ data: { token: s } }),
      ]);
      (g(t.keys), a(j.sessions), F(L.attempts), me(M.blocked));
    } catch {
      m();
    }
  }
  r.useEffect(() => {
    w();
  }, []);
  async function be(t) {
    t.preventDefault();
    const j = Math.max(1, Math.min(50, Number(Q) || 1)),
      L = await h({
        data: {
          token: s,
          label: K || void 0,
          expiresAt: E ? new Date(E).toISOString() : null,
          maxUses: I ? Number(I) : null,
          durationDays: R ? Number(R) : null,
          count: j,
        },
      });
    (O({ keys: L.keys }), H(""), X(""), Y(""), w());
  }
  async function je() {
    const t = await h({
      data: {
        token: s,
        label: K || `Lot ${new Date().toLocaleDateString()}`,
        expiresAt: E ? new Date(E).toISOString() : null,
        maxUses: I ? Number(I) : null,
        durationDays: R ? Number(R) : null,
        count: 10,
      },
    });
    (O({ keys: t.keys }), w());
  }
  return e.jsxs("div", {
    className:
      "min-h-screen px-3 sm:px-6 lg:px-10 py-4 sm:py-6 max-w-[1400px] mx-auto flex flex-col gap-5",
    children: [
      e.jsxs("header", {
        className:
          "glass rounded-3xl px-4 sm:px-6 py-4 flex items-center justify-between flex-wrap gap-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-3",
            children: [
              e.jsx("div", {
                className:
                  "w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--neon-orange)] to-[var(--neon-purple)] flex items-center justify-center",
                children: e.jsx(z, { className: "w-5 h-5 text-white" }),
              }),
              e.jsx("h1", {
                className: "font-display font-bold text-lg sm:text-xl",
                children: n("admin.title"),
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(re, {}),
              e.jsxs(oe, {
                to: "/",
                className:
                  "glass rounded-full px-3 py-1.5 text-xs font-mono flex items-center gap-1.5",
                children: [e.jsx(ie, { className: "w-3 h-3" }), " Site"],
              }),
              e.jsxs("button", {
                onClick: m,
                className:
                  "glass rounded-full px-3 py-1.5 text-xs font-mono text-[var(--neon-orange)] flex items-center gap-1.5",
                children: [
                  e.jsx(qe, { className: "w-3 h-3" }),
                  " ",
                  n("admin.logout"),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsx(vt, { token: s }),
      $ &&
        e.jsxs(le.div, {
          initial: { opacity: 0, y: -10 },
          animate: { opacity: 1, y: 0 },
          className:
            "glass rounded-2xl p-4 border border-[var(--neon-green)]/40 flex flex-col gap-3",
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between flex-wrap gap-2",
              children: [
                e.jsx("p", {
                  className: "text-xs text-muted-foreground font-mono",
                  children:
                    $.keys.length === 1
                      ? "Nouvelle clé (à copier maintenant) :"
                      : `${$.keys.length} nouvelles clés (à copier maintenant) :`,
                }),
                e.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    e.jsxs("button", {
                      onClick: () =>
                        navigator.clipboard.writeText(
                          $.keys.join(`
`),
                        ),
                      className:
                        "glass rounded-xl px-3 py-2 text-xs flex items-center gap-1.5",
                      children: [
                        e.jsx(se, { className: "w-3 h-3" }),
                        " Tout copier",
                      ],
                    }),
                    e.jsx("button", {
                      onClick: () => O(null),
                      className: "glass rounded-xl px-3 py-2 text-xs",
                      children: "OK",
                    }),
                  ],
                }),
              ],
            }),
            e.jsx("div", {
              className:
                "grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto",
              children: $.keys.map((t) =>
                e.jsxs(
                  "div",
                  {
                    className:
                      "flex items-center justify-between bg-black/30 rounded-lg px-3 py-2 gap-2",
                    children: [
                      e.jsx("span", {
                        className:
                          "font-mono text-sm text-[var(--neon-green)] text-glow tracking-wider truncate",
                        children: t,
                      }),
                      e.jsx("button", {
                        onClick: () => {
                          (navigator.clipboard.writeText(t),
                            Z(t),
                            setTimeout(() => Z(null), 1200));
                        },
                        className:
                          "text-muted-foreground hover:text-foreground",
                        children:
                          pe === t
                            ? e.jsx(ne, {
                                className:
                                  "w-3.5 h-3.5 text-[var(--neon-green)]",
                              })
                            : e.jsx(se, { className: "w-3.5 h-3.5" }),
                      }),
                    ],
                  },
                  t,
                ),
              ),
            }),
          ],
        }),
      e.jsxs("section", {
        className: "glass rounded-2xl p-3 sm:p-4",
        children: [
          e.jsxs("h2", {
            className:
              "font-display font-bold text-lg flex items-center gap-2 mb-4",
            children: [
              e.jsx(ce, { className: "w-4 h-4 text-[var(--neon-purple)]" }),
              " ",
              n("admin.new_key"),
            ],
          }),
          e.jsxs("form", {
            onSubmit: be,
            className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3",
            children: [
              e.jsx("input", {
                value: K,
                onChange: (t) => H(t.target.value),
                placeholder: n("admin.label"),
                "aria-label": n("admin.label"),
                className:
                  "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono outline-none lg:col-span-2",
              }),
              e.jsx("input", {
                type: "number",
                min: 1,
                max: 3650,
                value: R,
                onChange: (t) => xe(t.target.value),
                placeholder: "Durée (jours)",
                "aria-label": "Durée en jours",
                title: "Nombre de jours d'accès à partir de l'activation",
                className:
                  "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono outline-none",
              }),
              e.jsx("input", {
                type: "number",
                min: 1,
                value: I,
                onChange: (t) => Y(t.target.value),
                placeholder: n("admin.max_uses"),
                "aria-label": n("admin.max_uses"),
                className:
                  "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono outline-none",
              }),
              e.jsx("input", {
                type: "number",
                min: 1,
                max: 50,
                value: Q,
                onChange: (t) => ue(t.target.value),
                placeholder: "Nb clés",
                "aria-label": "Nombre de clés à générer",
                title: "Combien de clés générer en une fois",
                className:
                  "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono outline-none",
              }),
              e.jsx("button", {
                type: "submit",
                className:
                  "rounded-xl py-2 font-display font-bold text-sm bg-gradient-to-r from-[var(--neon-purple)] to-[var(--neon-blue)] text-white",
                children: n("admin.create"),
              }),
            ],
          }),
          e.jsxs("div", {
            className: "mt-3 flex flex-wrap gap-2 items-center",
            children: [
              e.jsx("button", {
                onClick: je,
                type: "button",
                className:
                  "rounded-xl px-4 py-2 font-display font-bold text-xs bg-gradient-to-r from-[var(--neon-orange)] to-[var(--neon-purple)] text-white",
                children: "⚡ Générer un lot de 10 clés",
              }),
              e.jsxs("button", {
                onClick: async () => {
                  const t = await h({
                    data: { token: s, label: K || void 0, isAdmin: !0 },
                  });
                  (O({ keys: t.keys }), w());
                },
                type: "button",
                className:
                  "rounded-xl px-4 py-2 font-display font-bold text-xs bg-gradient-to-r from-[var(--neon-green)] to-[var(--neon-blue)] text-black shadow-[0_0_25px_rgba(34,197,94,0.4)] flex items-center gap-1.5",
                title:
                  "Génère une clé administrateur sans expiration, sans limite d'usage et sans liaison à un appareil",
                children: [
                  e.jsx(z, { className: "w-3.5 h-3.5" }),
                  " Générer une clé ADMIN (illimitée)",
                ],
              }),
              e.jsxs("span", {
                className: "text-[11px] text-muted-foreground font-mono",
                children: [
                  "Chaque clé devient active automatiquement pour ",
                  R || "?",
                  " jours dès la 1ère utilisation, liée à un seul appareil.",
                ],
              }),
            ],
          }),
          e.jsx("input", {
            type: "datetime-local",
            value: E,
            onChange: (t) => X(t.target.value),
            placeholder: "Date d'expiration absolue (optionnel)",
            "aria-label": "Date d'expiration absolue",
            title:
              "Date limite absolue (optionnel — remplace la durée en jours)",
            className:
              "mt-3 w-full sm:w-72 bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs font-mono outline-none",
          }),
        ],
      }),
      e.jsx(kt, {
        onGranted: (t) => {
          (O({ keys: [t] }), w());
        },
        grant: _,
        token: s,
      }),
      e.jsx(ht, { token: s }),
      e.jsx(gt, { token: s }),
      e.jsx(Ct, { token: s }),
      e.jsxs("section", {
        className: "glass rounded-2xl p-3 sm:p-4",
        children: [
          e.jsxs("div", {
            className: "flex items-center justify-between gap-3 flex-wrap mb-3",
            children: [
              e.jsxs("h2", {
                className:
                  "font-display font-bold text-base flex items-center gap-2",
                children: [
                  e.jsx(Be, { className: "w-4 h-4 text-[var(--neon-blue)]" }),
                  " ",
                  n("admin.keys"),
                  e.jsxs("span", {
                    className: "text-xs text-muted-foreground font-mono",
                    children: [
                      "(",
                      V.length,
                      D !== "all" || P ? `/${d.length}` : "",
                      ")",
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "relative flex-1 sm:flex-none sm:w-64 max-w-full",
                children: [
                  e.jsx(it, {
                    className:
                      "w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground",
                  }),
                  e.jsx("input", {
                    value: P,
                    onChange: (t) => he(t.target.value),
                    placeholder: "Rechercher par nom du client…",
                    "aria-label": "Rechercher par nom du client",
                    className:
                      "w-full bg-black/30 border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs font-mono outline-none focus:border-[var(--neon-blue)]/60",
                  }),
                ],
              }),
            ],
          }),
          e.jsx("div", {
            className: "flex flex-wrap gap-1.5 mb-3",
            children: [
              { k: "all", label: "Tous", color: "white" },
              { k: "paid", label: "Abonnés", color: "var(--neon-blue)" },
              { k: "gifted", label: "Offerts", color: "var(--neon-purple)" },
              { k: "activated", label: "Activées", color: "var(--neon-green)" },
              {
                k: "pending",
                label: "En attente",
                color: "var(--neon-orange)",
              },
            ].map((t) => {
              const j = D === t.k;
              return e.jsxs(
                "button",
                {
                  type: "button",
                  onClick: () => fe(t.k),
                  className: `px-2.5 py-1 rounded-full text-[11px] font-mono border transition-all ${j ? "border-white/40 bg-white/10 text-white" : "border-white/10 bg-black/20 text-muted-foreground hover:text-white hover:border-white/20"}`,
                  style: j
                    ? {
                        boxShadow: `0 0 0 1px ${t.color === "white" ? "rgba(255,255,255,0.3)" : t.color}`,
                      }
                    : void 0,
                  children: [
                    t.label,
                    e.jsx("span", {
                      className: "ml-1.5 opacity-60",
                      children: ge[t.k],
                    }),
                  ],
                },
                t.k,
              );
            }),
          }),
          e.jsx("div", {
            className:
              "overflow-x-auto max-h-[420px] overflow-y-auto rounded-xl border border-white/5",
            children: e.jsxs("table", {
              className: "w-full text-xs sm:text-sm",
              children: [
                e.jsx("thead", {
                  className: "sticky top-0 bg-black/60 backdrop-blur z-10",
                  children: e.jsxs("tr", {
                    className:
                      "text-left text-muted-foreground font-mono uppercase text-[10px]",
                    children: [
                      e.jsx("th", {
                        className: "p-2",
                        children: "Nom du client",
                      }),
                      e.jsx("th", { className: "p-2", children: "Durée" }),
                      e.jsx("th", { className: "p-2", children: "Activée" }),
                      e.jsx("th", {
                        className: "p-2",
                        children: n("admin.expires"),
                      }),
                      e.jsx("th", { className: "p-2", children: "Appareil" }),
                      e.jsx("th", { className: "p-2", children: "Uses" }),
                      e.jsx("th", { className: "p-2", children: "Status" }),
                      e.jsx("th", { className: "p-2" }),
                    ],
                  }),
                }),
                e.jsxs("tbody", {
                  children: [
                    V.map((t) => {
                      const j = t.source ?? "manual",
                        L =
                          j === "geniuspay"
                            ? {
                                label: "PAIEMENT",
                                cls: "bg-[var(--neon-blue)]/15 text-[var(--neon-blue)]",
                              }
                            : j === "admin_grant"
                              ? {
                                  label: "OFFERT",
                                  cls: "bg-[var(--neon-purple)]/15 text-[var(--neon-purple)]",
                                }
                              : {
                                  label: "CLÉ",
                                  cls: "bg-white/10 text-white/60",
                                };
                      return e.jsxs(
                        "tr",
                        {
                          className: "border-t border-white/5",
                          children: [
                            e.jsxs("td", {
                              className: "p-2 font-mono",
                              children: [
                                t.is_admin &&
                                  e.jsxs("span", {
                                    className:
                                      "mr-1.5 inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-[var(--neon-green)]/15 text-[var(--neon-green)] text-[9px] font-bold uppercase tracking-wider",
                                    children: [
                                      e.jsx(z, { className: "w-2.5 h-2.5" }),
                                      " ADMIN",
                                    ],
                                  }),
                                e.jsx("span", {
                                  className: `mr-1.5 inline-flex items-center px-1.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${L.cls}`,
                                  children: L.label,
                                }),
                                e.jsxs("button", {
                                  title: "Modifier le nom du client",
                                  onClick: async () => {
                                    const M = window.prompt(
                                      "Nom du client :",
                                      t.label || "",
                                    );
                                    M !== null &&
                                      (await p({
                                        data: { token: s, id: t.id, label: M },
                                      }),
                                      w());
                                  },
                                  className:
                                    "inline-flex items-center gap-1 hover:text-[var(--neon-blue)] transition-colors",
                                  children: [
                                    e.jsx("span", {
                                      children:
                                        t.label ||
                                        e.jsx("span", {
                                          className:
                                            "text-muted-foreground italic",
                                          children: "— sans nom —",
                                        }),
                                    }),
                                    e.jsx(nt, {
                                      className: "w-2.5 h-2.5 opacity-40",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            e.jsx("td", {
                              className: "p-2 font-mono text-muted-foreground",
                              children: t.duration_days
                                ? `${t.duration_days}j`
                                : "—",
                            }),
                            e.jsx("td", {
                              className: "p-2 font-mono text-muted-foreground",
                              children: t.activated_at
                                ? new Date(t.activated_at).toLocaleDateString()
                                : e.jsx("span", {
                                    className: "text-[var(--neon-blue)]",
                                    children: "en attente",
                                  }),
                            }),
                            e.jsx("td", {
                              className: "p-2 font-mono text-muted-foreground",
                              children: t.expires_at
                                ? new Date(t.expires_at).toLocaleString()
                                : "∞",
                            }),
                            e.jsx("td", {
                              className:
                                "p-2 font-mono text-[10px] text-muted-foreground",
                              children: t.device_fingerprint
                                ? t.device_fingerprint.slice(0, 8) + "…"
                                : "—",
                            }),
                            e.jsxs("td", {
                              className: "p-2 font-mono",
                              children: [
                                t.uses,
                                t.max_uses ? `/${t.max_uses}` : "",
                              ],
                            }),
                            e.jsx("td", {
                              className: "p-2",
                              children: e.jsx("span", {
                                className: `text-[10px] px-2 py-1 rounded-full font-mono ${t.active ? "bg-[var(--neon-green)]/15 text-[var(--neon-green)]" : "bg-[var(--neon-orange)]/15 text-[var(--neon-orange)]"}`,
                                children: t.active ? "ON" : "OFF",
                              }),
                            }),
                            e.jsxs("td", {
                              className: "p-2 flex gap-1 justify-end flex-wrap",
                              children: [
                                !t.is_admin &&
                                  e.jsxs(e.Fragment, {
                                    children: [
                                      e.jsx("button", {
                                        title: "Ajouter 30 jours",
                                        onClick: async () => {
                                          (await v({
                                            data: {
                                              token: s,
                                              id: t.id,
                                              deltaDays: 30,
                                            },
                                          }),
                                            w());
                                        },
                                        className:
                                          "glass rounded-lg p-1.5 text-[var(--neon-green)]",
                                        children: e.jsx(Qe, {
                                          className: "w-3 h-3",
                                        }),
                                      }),
                                      e.jsx("button", {
                                        title: "Retirer 30 jours",
                                        onClick: async () => {
                                          confirm("Retirer 30 jours ?") &&
                                            (await v({
                                              data: {
                                                token: s,
                                                id: t.id,
                                                deltaDays: -30,
                                              },
                                            }),
                                            w());
                                        },
                                        className:
                                          "glass rounded-lg p-1.5 text-[var(--neon-orange)]",
                                        children: e.jsx(Xe, {
                                          className: "w-3 h-3",
                                        }),
                                      }),
                                    ],
                                  }),
                                e.jsx("button", {
                                  title: "Envoyer un message",
                                  onClick: async () => {
                                    const M =
                                      window.prompt("Titre du message ?");
                                    if (!M) return;
                                    const ee = window.prompt(
                                      "Contenu du message ?",
                                    );
                                    ee &&
                                      (await S({
                                        data: {
                                          token: s,
                                          keyId: t.id,
                                          title: M,
                                          body: ee,
                                          kind: "info",
                                        },
                                      }),
                                      alert("Message envoyé"));
                                  },
                                  className:
                                    "glass rounded-lg p-1.5 text-[var(--neon-blue)]",
                                  "aria-label": "Envoyer un message",
                                  children: e.jsx(Ke, { className: "w-3 h-3" }),
                                }),
                                e.jsx("button", {
                                  onClick: async () => {
                                    (await u({
                                      data: {
                                        token: s,
                                        id: t.id,
                                        active: !t.active,
                                      },
                                    }),
                                      w());
                                  },
                                  className: "glass rounded-lg p-1.5",
                                  "aria-label": t.active
                                    ? "Désactiver la clé"
                                    : "Activer la clé",
                                  children: e.jsx(de, { className: "w-3 h-3" }),
                                }),
                                e.jsx("button", {
                                  onClick: async () => {
                                    confirm("Supprimer ?") &&
                                      (await i({
                                        data: { token: s, id: t.id },
                                      }),
                                      w());
                                  },
                                  className:
                                    "glass rounded-lg p-1.5 text-[var(--neon-orange)]",
                                  "aria-label": "Supprimer la clé",
                                  children: e.jsx(W, { className: "w-3 h-3" }),
                                }),
                              ],
                            }),
                          ],
                        },
                        t.id,
                      );
                    }),
                    V.length === 0 &&
                      e.jsx("tr", {
                        children: e.jsx("td", {
                          colSpan: 8,
                          className:
                            "p-4 text-center text-muted-foreground font-mono text-xs",
                          children:
                            P || D !== "all"
                              ? "Aucun client trouvé pour ce filtre."
                              : "Aucune clé.",
                        }),
                      }),
                  ],
                }),
              ],
            }),
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-1 lg:grid-cols-2 gap-5",
        children: [
          e.jsxs("details", {
            className: "glass rounded-2xl p-3 sm:p-4 group",
            children: [
              e.jsxs("summary", {
                className:
                  "cursor-pointer list-none flex items-center justify-between gap-2",
                children: [
                  e.jsxs("h2", {
                    className:
                      "font-display font-bold text-sm flex items-center gap-2",
                    children: [
                      e.jsx(Je, {
                        className: "w-4 h-4 text-[var(--neon-green)]",
                      }),
                      " ",
                      n("admin.sessions"),
                      e.jsxs("span", {
                        className: "text-xs text-muted-foreground font-mono",
                        children: ["(", l.length, ")"],
                      }),
                    ],
                  }),
                  e.jsx("span", {
                    className:
                      "text-[10px] text-muted-foreground font-mono group-open:hidden",
                    children: "Afficher",
                  }),
                  e.jsx("span", {
                    className:
                      "text-[10px] text-muted-foreground font-mono hidden group-open:inline",
                    children: "Masquer",
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "space-y-1.5 max-h-56 overflow-y-auto mt-3",
                children: [
                  l.map((t, j) =>
                    e.jsxs(
                      "div",
                      {
                        className:
                          "flex items-center justify-between gap-2 text-xs font-mono p-2 rounded-lg hover:bg-white/5",
                        children: [
                          e.jsx("span", {
                            className: "text-[var(--neon-blue)]",
                            children: t.ip || "?",
                          }),
                          e.jsx("span", {
                            className: "text-muted-foreground truncate flex-1",
                            children: (t.user_agent || "").slice(0, 40),
                          }),
                          e.jsx("button", {
                            onClick: async () => {
                              (await N({ data: { token: s, ip: t.ip || "" } }),
                                w());
                            },
                            className: "text-[var(--neon-orange)] text-[10px]",
                            children: n("admin.block"),
                          }),
                        ],
                      },
                      j,
                    ),
                  ),
                  l.length === 0 &&
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground font-mono",
                      children: "—",
                    }),
                ],
              }),
            ],
          }),
          e.jsxs("details", {
            className: "glass rounded-2xl p-3 sm:p-4 group",
            children: [
              e.jsxs("summary", {
                className:
                  "cursor-pointer list-none flex items-center justify-between gap-2",
                children: [
                  e.jsxs("h2", {
                    className:
                      "font-display font-bold text-sm flex items-center gap-2",
                    children: [
                      e.jsx(Ve, {
                        className: "w-4 h-4 text-[var(--neon-orange)]",
                      }),
                      " ",
                      n("admin.attempts"),
                      e.jsxs("span", {
                        className: "text-xs text-muted-foreground font-mono",
                        children: ["(", T.length, ")"],
                      }),
                    ],
                  }),
                  e.jsx("span", {
                    className:
                      "text-[10px] text-muted-foreground font-mono group-open:hidden",
                    children: "Afficher",
                  }),
                  e.jsx("span", {
                    className:
                      "text-[10px] text-muted-foreground font-mono hidden group-open:inline",
                    children: "Masquer",
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "space-y-1.5 max-h-56 overflow-y-auto mt-3",
                children: [
                  T.map((t, j) =>
                    e.jsxs(
                      "div",
                      {
                        className:
                          "flex items-center justify-between gap-2 text-xs font-mono p-2 rounded-lg hover:bg-white/5",
                        children: [
                          e.jsxs("span", {
                            className: t.success
                              ? "text-[var(--neon-green)]"
                              : "text-[var(--neon-orange)]",
                            children: [t.success ? "✓" : "✗", " ", t.ip],
                          }),
                          e.jsx("span", {
                            className: "text-muted-foreground text-[10px]",
                            children: new Date(
                              t.created_at,
                            ).toLocaleTimeString(),
                          }),
                        ],
                      },
                      j,
                    ),
                  ),
                  T.length === 0 &&
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground font-mono",
                      children: "—",
                    }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        className: "glass rounded-2xl p-3 sm:p-4",
        children: [
          e.jsxs("h2", {
            className:
              "font-display font-bold text-lg flex items-center gap-2 mb-4",
            children: [
              e.jsx(We, { className: "w-4 h-4 text-[var(--neon-orange)]" }),
              " ",
              n("admin.blocked"),
              " (",
              B.length,
              ")",
            ],
          }),
          e.jsxs("div", {
            className: "flex flex-wrap gap-2",
            children: [
              B.map((t) =>
                e.jsxs(
                  "div",
                  {
                    className:
                      "glass rounded-full px-3 py-1.5 text-xs font-mono flex items-center gap-2",
                    children: [
                      e.jsx("span", {
                        className: "text-[var(--neon-orange)]",
                        children: t.ip,
                      }),
                      e.jsx("button", {
                        onClick: async () => {
                          (await f({ data: { token: s, ip: t.ip } }), w());
                        },
                        className: "text-[var(--neon-green)] text-[10px]",
                        children: n("admin.unblock"),
                      }),
                    ],
                  },
                  t.ip,
                ),
              ),
              B.length === 0 &&
                e.jsx("p", {
                  className: "text-xs text-muted-foreground font-mono",
                  children: "—",
                }),
            ],
          }),
        ],
      }),
    ],
  });
}
function kt({ grant: s, token: m, onGranted: n }) {
  const [x, h] = r.useState("1"),
    [u, i] = r.useState(""),
    [p, o] = r.useState(
      "Votre abonnement VIP Premium a été activé par l'équipe. Bienvenue !",
    ),
    [b, y] = r.useState(!1);
  async function N(f) {
    (f.preventDefault(), y(!0));
    try {
      const _ = await s({
        data: {
          token: m,
          months: Math.max(1, Math.min(60, Number(x) || 1)),
          label: u || void 0,
          note: p || void 0,
        },
      });
      (n(_.key), i(""));
    } finally {
      y(!1);
    }
  }
  return e.jsxs("section", {
    className:
      "glass rounded-2xl p-3 sm:p-4 border border-[var(--neon-purple)]/25",
    children: [
      e.jsxs("h2", {
        className:
          "font-display font-bold text-lg flex items-center gap-2 mb-1",
        children: [
          e.jsx(Ue, { className: "w-4 h-4 text-[var(--neon-purple)]" }),
          " Offrir un abonnement",
        ],
      }),
      e.jsxs("p", {
        className: "text-[11px] text-muted-foreground font-mono mb-4",
        children: [
          "Génère une clé d'abonnement (source ",
          e.jsx("b", { children: "OFFERT" }),
          ") valable pour N mois. Le message est déposé dans la messagerie interne rattachée à la clé.",
        ],
      }),
      e.jsxs("form", {
        onSubmit: N,
        className: "grid grid-cols-1 sm:grid-cols-6 gap-3",
        children: [
          e.jsx("input", {
            type: "number",
            min: 1,
            max: 60,
            value: x,
            onChange: (f) => h(f.target.value),
            placeholder: "Durée (mois)",
            "aria-label": "Durée en mois",
            title: "Nombre de mois",
            className:
              "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono outline-none",
          }),
          e.jsx("input", {
            value: u,
            onChange: (f) => i(f.target.value),
            placeholder: "Étiquette (optionnel)",
            "aria-label": "Étiquette de l'abonnement",
            className:
              "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono outline-none sm:col-span-2",
          }),
          e.jsx("input", {
            value: p,
            onChange: (f) => o(f.target.value),
            placeholder: "Message (optionnel)",
            "aria-label": "Message pour le client",
            className:
              "bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono outline-none sm:col-span-2",
          }),
          e.jsx("button", {
            type: "submit",
            disabled: b,
            className:
              "rounded-xl py-2 font-display font-bold text-sm bg-gradient-to-r from-[var(--neon-purple)] to-[var(--neon-blue)] text-white disabled:opacity-50",
            children: b ? "…" : "Générer",
          }),
        ],
      }),
    ],
  });
}
function Ct({ token: s }) {
  const m = c(Ee),
    [n, x] = r.useState(null),
    [h, u] = r.useState(!1);
  async function i() {
    if (s) {
      u(!0);
      try {
        x(await m({ data: { token: s } }));
      } catch (o) {
        x({ ok: !1, message: String(o) });
      } finally {
        u(!1);
      }
    }
  }
  r.useEffect(() => {
    s && i();
  }, [s]);
  const p = n?.ok;
  return e.jsxs("section", {
    className: "glass rounded-2xl p-3 sm:p-4",
    children: [
      e.jsxs("div", {
        className: "flex items-center justify-between gap-3 mb-3 flex-wrap",
        children: [
          e.jsxs("h2", {
            className: "font-display font-bold text-lg flex items-center gap-2",
            children: [
              "⚽ API Football (Sportmonks)",
              n &&
                e.jsx("span", {
                  className: `text-[10px] px-2 py-0.5 rounded-full font-mono ${p ? "bg-[var(--neon-green)]/15 text-[var(--neon-green)]" : "bg-red-500/15 text-red-400"}`,
                  children: p ? "ACTIVE" : "ERREUR",
                }),
            ],
          }),
          e.jsx("button", {
            onClick: i,
            disabled: h,
            className:
              "rounded-xl px-3 py-1.5 text-xs font-mono bg-white/5 border border-white/10 hover:bg-white/10 disabled:opacity-40",
            children: h ? "…" : "Rafraîchir",
          }),
        ],
      }),
      n
        ? e.jsxs("div", {
            className: "grid sm:grid-cols-2 gap-3 text-xs font-mono",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx("span", {
                    className: "text-muted-foreground",
                    children: "HTTP :",
                  }),
                  " ",
                  n.httpStatus ?? "—",
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("span", {
                    className: "text-muted-foreground",
                    children: "Plan :",
                  }),
                  " ",
                  n.planName ?? "—",
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("span", {
                    className: "text-muted-foreground",
                    children: "Requêtes restantes / heure :",
                  }),
                  " ",
                  n.remaining ?? "—",
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("span", {
                    className: "text-muted-foreground",
                    children: "Reset dans :",
                  }),
                  " ",
                  n.resetsInSeconds ? `${n.resetsInSeconds}s` : "—",
                ],
              }),
              n.message &&
                e.jsxs("div", {
                  className: "sm:col-span-2 text-red-400",
                  children: ["Message : ", n.message],
                }),
              n.subscriptionJson &&
                e.jsxs("details", {
                  className: "sm:col-span-2",
                  children: [
                    e.jsx("summary", {
                      className: "cursor-pointer text-muted-foreground",
                      children: "Détails abonnement (JSON)",
                    }),
                    e.jsx("pre", {
                      className:
                        "mt-2 p-2 bg-black/40 rounded text-[10px] overflow-x-auto",
                      children: n.subscriptionJson,
                    }),
                  ],
                }),
            ],
          })
        : e.jsx("p", {
            className: "text-xs text-muted-foreground font-mono",
            children: "Chargement…",
          }),
    ],
  });
}
export { Et as component };
