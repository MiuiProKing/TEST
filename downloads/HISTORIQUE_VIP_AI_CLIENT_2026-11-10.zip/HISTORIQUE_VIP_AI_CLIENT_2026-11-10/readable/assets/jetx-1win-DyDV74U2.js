import { r as i, Y as m, j as e } from "./index-C5ThNCN-.js";
import { R as x } from "./RoundCard-CZ-rEJ_D.js";
import { S as c, P as g } from "./PredictionPanel-BwmEfDz4.js";
import { D as p } from "./DashboardLayout-XCzqIJrp.js";
import "./analysis-data-BaiXRb_2.js";
import "./triangle-alert-CzDFXfJ_.js";
import "./database-80brKRBJ.js";
import "./trending-up-B5K2KKMW.js";
import "./activity-D198U5P3.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const u =
    "/__l5e/assets-v1/3d3f809d-d40f-4ceb-8264-53993261ffe3/jetx-1win-logo.png",
  f = { url: u };
function W() {
  const [t, o] = i.useState(!1);
  i.useEffect(() => {
    (localStorage.setItem("lj_current_game", "jetx-1win"), o(!0));
  }, []);
  const { rounds: s, status: r, newestId: d, errorMsg: l } = m();
  return e.jsxs(p, {
    children: [
      e.jsxs("div", {
        className:
          "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between flex-wrap gap-3 relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "absolute inset-0 bg-gradient-to-r from-yellow-500/10 via-transparent to-blue-600/10 pointer-events-none",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-3 min-w-0 relative",
            children: [
              e.jsx("img", {
                src: f.url,
                alt: "JetX 1Win",
                className:
                  "shrink-0 w-11 h-11 rounded-xl object-cover shadow-[0_0_20px_rgba(250,204,21,0.4)]",
              }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 flex-wrap",
                    children: [
                      e.jsx("h1", {
                        className:
                          "font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight bg-gradient-to-r from-yellow-300 via-yellow-400 to-orange-400 bg-clip-text text-transparent",
                        children: "JetX",
                      }),
                      e.jsx("span", {
                        className:
                          "text-muted-foreground font-light text-lg sm:text-xl",
                        children: "×",
                      }),
                      e.jsx("div", {
                        className:
                          "inline-flex items-center px-2.5 py-1 rounded-lg bg-gradient-to-br from-blue-600 to-blue-800 shadow-[0_0_18px_rgba(37,99,235,0.5)] border border-blue-400/30",
                        children: e.jsx("img", {
                          src: "/__l5e/assets-v1/52d46183-a69c-41f5-ab32-72c8336e53bb/1win-logo.png",
                          alt: "1Win",
                          className: "h-5 sm:h-6 w-auto object-contain",
                        }),
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    children: "Historique des 20 derniers tours en temps réel",
                  }),
                ],
              }),
            ],
          }),
          t &&
            e.jsxs("div", {
              className: "flex items-center gap-2 text-xs font-mono",
              children: [
                e.jsx("span", {
                  className: `w-2 h-2 rounded-full animate-pulse ${r === "live" ? "bg-[var(--neon-green)]" : r === "error" ? "bg-[var(--neon-orange)]" : "bg-[var(--neon-blue)]"}`,
                }),
                e.jsx("span", {
                  className: "text-muted-foreground",
                  children:
                    r === "live"
                      ? "LIVE"
                      : r === "error"
                        ? `Erreur API${l ? ` : ${l}` : ""}`
                        : "Connexion…",
                }),
              ],
            }),
        ],
      }),
      t && s.length > 0 && e.jsx(c, { rounds: s }),
      t && s.length > 0 && e.jsx(g, { rounds: s, table: "jetx_1win_rounds" }),
      e.jsxs("main", {
        className: "glass rounded-3xl p-4 sm:p-6 lg:p-8",
        children: [
          e.jsx("div", {
            className: "flex items-end justify-between flex-wrap gap-2 mb-5",
            children: e.jsxs("div", {
              children: [
                e.jsx("h2", {
                  className:
                    "font-display font-bold text-xl sm:text-2xl tracking-tight",
                  children: "20 derniers tours",
                }),
                e.jsx("p", {
                  className: "text-xs sm:text-sm text-muted-foreground mt-1",
                  children:
                    "Mise à jour en temps réel depuis l'API officielle JetX 1Win",
                }),
              ],
            }),
          }),
          t && s.length === 0
            ? e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: Array.from({ length: 20 }).map((a, n) =>
                  e.jsx(
                    "div",
                    {
                      className:
                        "rounded-2xl h-[56px] sm:h-[64px] glass animate-pulse",
                      style: { animationDelay: `${n * 50}ms` },
                    },
                    n,
                  ),
                ),
              })
            : e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: s.map((a) =>
                  e.jsx(x, { round: a, isNew: a.id === d }, a.id),
                ),
              }),
        ],
      }),
    ],
  });
}
export { W as component };
