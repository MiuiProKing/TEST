import {
  c as m,
  f as o,
  r as c,
  j as e,
  N as w,
  k,
  E as h,
} from "./index-C5ThNCN-.js";
import {
  l as N,
  m as y,
  b as _,
  D as v,
  M as B,
} from "./DashboardLayout-XCzqIJrp.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const M = [
    ["path", { d: "M18 6 7 17l-5-5", key: "116fxf" }],
    ["path", { d: "m22 10-7.5 7.5L13 16", key: "ke71qq" }],
  ],
  S = m("check-check", M);
const E = [
    [
      "polyline",
      { points: "22 12 16 12 14 15 10 15 8 12 2 12", key: "o97t9d" },
    ],
    [
      "path",
      {
        d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
        key: "oot6mr",
      },
    ],
  ],
  L = m("inbox", E),
  d = "lj_access_token";
function C() {
  const f = o(N),
    g = o(y),
    p = o(_),
    [n, l] = c.useState([]),
    [u, x] = c.useState(!0);
  async function b() {
    const t = typeof window < "u" ? localStorage.getItem(d) : null;
    if (!t) {
      x(!1);
      return;
    }
    try {
      const s = await f({ data: { token: t } });
      s.ok && l(s.messages);
    } finally {
      x(!1);
    }
  }
  c.useEffect(() => {
    b();
  }, []);
  async function F(t) {
    if (!t.read_at) {
      const s = localStorage.getItem(d);
      (s && (await g({ data: { token: s, id: t.id } })),
        l((a) =>
          a.map((i) =>
            i.id === t.id ? { ...i, read_at: new Date().toISOString() } : i,
          ),
        ));
    }
  }
  async function j() {
    const t = localStorage.getItem(d);
    t &&
      (await p({ data: { token: t } }),
      l((s) =>
        s.map((a) =>
          a.read_at ? a : { ...a, read_at: new Date().toISOString() },
        ),
      ));
  }
  const r = n.filter((t) => !t.read_at).length;
  return e.jsxs(v, {
    children: [
      e.jsxs("header", {
        className:
          "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-4 flex items-center justify-between flex-wrap gap-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-3",
            children: [
              e.jsx("div", {
                className:
                  "h-10 w-10 rounded-xl bg-gradient-to-br from-[#7B2FFF] to-[#E040FB] flex items-center justify-center",
                children: e.jsx(B, { size: 18 }),
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("h1", {
                    className: "font-display font-black text-xl",
                    children: "Messagerie",
                  }),
                  e.jsx("p", {
                    className: "text-xs text-white/50",
                    children:
                      r > 0
                        ? `${r} message${r > 1 ? "s" : ""} non lu${r > 1 ? "s" : ""}`
                        : "Tout est à jour",
                  }),
                ],
              }),
            ],
          }),
          r > 0 &&
            e.jsxs("button", {
              onClick: j,
              className:
                "inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs bg-white/[0.05] hover:bg-white/[0.1] border border-white/10",
              children: [e.jsx(S, { size: 14 }), " Tout marquer lu"],
            }),
        ],
      }),
      u
        ? e.jsx("div", {
            className:
              "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-10 flex items-center justify-center",
            children: e.jsx(w, {
              className: "w-6 h-6 animate-spin text-[#7B2FFF]",
            }),
          })
        : n.length === 0
          ? e.jsxs("div", {
              className:
                "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-10 text-center flex flex-col items-center gap-3",
              children: [
                e.jsx(L, { className: "w-10 h-10 text-white/30" }),
                e.jsx("p", {
                  className: "text-sm text-white/60",
                  children: "Aucun message pour le moment.",
                }),
              ],
            })
          : e.jsx("div", {
              className: "flex flex-col gap-2",
              children: n.map((t) => {
                const s = !t.read_at,
                  a =
                    t.kind === "success"
                      ? "border-emerald-500/30 bg-emerald-500/[0.03]"
                      : t.kind === "warning"
                        ? "border-amber-500/30 bg-amber-500/[0.03]"
                        : "border-white/[0.08] bg-[#0F0B1F]";
                return e.jsxs(
                  "div",
                  {
                    className: `rounded-xl border p-4 flex flex-col gap-2 ${a} ${s ? "ring-1 ring-[#7B2FFF]/40" : ""}`,
                    onClick: () => F(t),
                    children: [
                      e.jsxs("div", {
                        className: "flex items-start justify-between gap-3",
                        children: [
                          e.jsxs("div", {
                            className: "flex items-center gap-2 min-w-0",
                            children: [
                              s &&
                                e.jsx("span", {
                                  className:
                                    "h-2 w-2 rounded-full bg-[#E040FB] shrink-0",
                                }),
                              e.jsx("h2", {
                                className:
                                  "font-display font-bold text-sm truncate",
                                children: t.title,
                              }),
                            ],
                          }),
                          e.jsx("span", {
                            className:
                              "text-[10px] text-white/40 whitespace-nowrap",
                            children: new Date(t.created_at).toLocaleString(
                              "fr-FR",
                            ),
                          }),
                        ],
                      }),
                      e.jsx("p", {
                        className: "text-sm text-white/75 whitespace-pre-line",
                        children: t.body,
                      }),
                      t.cta_url &&
                        (t.cta_url.startsWith("/")
                          ? e.jsxs(k, {
                              to: t.cta_url,
                              className:
                                "inline-flex items-center gap-1.5 self-start px-3 py-1.5 rounded-lg bg-[#7B2FFF]/15 border border-[#7B2FFF]/30 text-xs font-semibold text-[#E040FB] hover:bg-[#7B2FFF]/25",
                              children: [
                                t.cta_label ?? "Ouvrir",
                                " ",
                                e.jsx(h, { size: 12 }),
                              ],
                            })
                          : e.jsxs("a", {
                              href: t.cta_url,
                              target: "_blank",
                              rel: "noopener noreferrer",
                              className:
                                "inline-flex items-center gap-1.5 self-start px-3 py-1.5 rounded-lg bg-[#7B2FFF]/15 border border-[#7B2FFF]/30 text-xs font-semibold text-[#E040FB] hover:bg-[#7B2FFF]/25",
                              children: [
                                t.cta_label ?? "Ouvrir",
                                " ",
                                e.jsx(h, { size: 12 }),
                              ],
                            })),
                    ],
                  },
                  t.id,
                );
              }),
            }),
    ],
  });
}
export { C as component };
