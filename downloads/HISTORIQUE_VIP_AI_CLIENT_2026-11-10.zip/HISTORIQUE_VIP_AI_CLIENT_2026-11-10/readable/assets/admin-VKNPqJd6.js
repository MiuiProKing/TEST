import { j as e } from "./index-C5ThNCN-.js";
import { A as n } from "./admin-CZk1hmsV.js";
const l = ({ error: o, reset: t }) => (
  typeof window < "u" && localStorage.removeItem(n),
  e.jsx("div", {
    className: "min-h-screen flex items-center justify-center px-4",
    children: e.jsxs("div", {
      className:
        "glass rounded-3xl p-8 max-w-md w-full text-center flex flex-col gap-4",
      children: [
        e.jsx("h1", {
          className: "font-display font-bold text-xl",
          children: "Session admin expirée",
        }),
        e.jsx("p", {
          className: "text-sm text-muted-foreground font-mono",
          children:
            o.message === "Unauthorized"
              ? "Votre session a expiré. Veuillez vous reconnecter."
              : o.message,
        }),
        e.jsx("button", {
          onClick: () => {
            (t(), window.location.reload());
          },
          className:
            "rounded-2xl py-3 font-display font-bold text-sm bg-gradient-to-r from-[var(--neon-purple)] to-[var(--neon-blue)] text-white",
          children: "Se reconnecter",
        }),
      ],
    }),
  })
);
export { l as errorComponent };
