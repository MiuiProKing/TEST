import { j as e, m as j, T as N, r as h, J as v } from "./index-C5ThNCN-.js";
import { D as y } from "./DashboardLayout-XCzqIJrp.js";
import { Z as w, c as F } from "./god-character.png.asset-BWFGzeh1.js";
import { l as k, j as E } from "./game-jetx-B-JXM8w7.js";
import { r as _ } from "./game-rocketqueen-CCl9MGDg.js";
import { T as R, a as S } from "./trending-up-B5K2KKMW.js";
import { R as I } from "./radio-B9K4C2ja.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const c = [
  {
    key: "luckyjet",
    table: "luckyjet_rounds",
    name: "Lucky Jet",
    img: k,
    tone: "purple",
  },
  {
    key: "rocketqueen",
    table: "rocketqueen_rounds",
    name: "Rocket Queen",
    img: _,
    tone: "pink",
  },
  { key: "jetx", table: "jetx_rounds", name: "JetX", img: E, tone: "orange" },
];
function D() {
  const a = new Date();
  return (a.setHours(0, 0, 0, 0), a.toISOString());
}
function T() {
  const [a, d] = h.useState({
    totalPredictions: 0,
    successRate: 0,
    perGame: {},
  });
  return (
    h.useEffect(() => {
      let i = !1;
      const t = async () => {
        const l = D(),
          r = {};
        let o = 0,
          x = 0;
        (await Promise.all(
          c.map(async (m) => {
            const { data: n, error: u } = await v
              .from(m.table)
              .select("coefficient, played_at")
              .gte("played_at", l)
              .order("played_at", { ascending: !1 });
            if (u || !n) {
              r[m.key] = { count: 0, wins: 0, last: null };
              return;
            }
            const p = n.length,
              f = n.filter((g) => Number(g.coefficient) >= 2).length;
            ((o += p), (x += f));
            const b = n[0]
              ? {
                  coef: Number(n[0].coefficient),
                  time: new Date(n[0].played_at).toLocaleTimeString("fr-FR", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                  }),
                }
              : null;
            r[m.key] = { count: p, wins: f, last: b };
          }),
        ),
          !i &&
            d({
              totalPredictions: o,
              successRate: o > 0 ? (x / o) * 100 : 0,
              perGame: r,
            }));
      };
      t();
      const s = setInterval(t, 15e3);
      return () => {
        ((i = !0), clearInterval(s));
      };
    }, []),
    a
  );
}
function G() {
  const a = T(),
    d = c.length,
    i = [
      {
        label: "PRÉDICTIONS (AUJOURD'HUI)",
        value: a.totalPredictions.toLocaleString("fr-FR"),
        hint: "Depuis 00h00",
        icon: R,
        color: "#7B2FFF",
        bg: "from-[#7B2FFF]/20 to-transparent",
      },
      {
        label: "TAUX DE RÉUSSITE",
        value: `${a.successRate.toFixed(2)}%`,
        hint: "Temps réel · coef ≥ 2.00",
        icon: S,
        color: "#3D5AFE",
        bg: "from-[#3D5AFE]/20 to-transparent",
      },
      {
        label: "ANALYSES EN COURS",
        value: String(d),
        hint: c.map((t) => t.name).join(" · "),
        icon: w,
        color: "#f59e0b",
        bg: "from-amber-500/20 to-transparent",
      },
    ];
  return e.jsxs(y, {
    children: [
      e.jsxs(j.div, {
        initial: { opacity: 0, y: 10 },
        animate: { opacity: 1, y: 0 },
        className:
          "relative overflow-hidden rounded-3xl border border-white/[0.08] bg-gradient-to-br from-[#1a0b2e] via-[#0f0a1f] to-[#0b0916] p-6 sm:p-8",
        children: [
          e.jsxs("div", {
            className: "relative z-10 max-w-xl",
            children: [
              e.jsxs("h1", {
                className:
                  "font-display text-3xl sm:text-4xl font-black tracking-tight",
                children: [
                  "Bienvenue sur ",
                  e.jsx("span", {
                    className: "italic text-white",
                    children: "GOD",
                  }),
                  " ",
                  e.jsx("span", {
                    className:
                      "italic text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                    children: "PREDITOR",
                  }),
                ],
              }),
              e.jsx("p", {
                className: "mt-2 text-sm text-white/60",
                children: "Vos prédictions en temps réel.",
              }),
            ],
          }),
          e.jsx("img", {
            src: F.url,
            alt: "",
            className:
              "pointer-events-none absolute right-0 top-0 h-full w-auto object-contain opacity-90 hidden sm:block",
          }),
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_80%_50%,rgba(123,47,255,0.25),transparent_60%)]",
          }),
        ],
      }),
      e.jsx("div", {
        className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
        children: i.map((t) => {
          const s = t.icon;
          return e.jsx(
            "div",
            {
              className: `relative overflow-hidden rounded-2xl border border-white/[0.08] bg-gradient-to-br ${t.bg} bg-[#0F0B1F] p-4`,
              children: e.jsxs("div", {
                className: "flex items-start gap-3",
                children: [
                  e.jsx("div", {
                    className:
                      "h-11 w-11 shrink-0 rounded-xl flex items-center justify-center",
                    style: { backgroundColor: `${t.color}22`, color: t.color },
                    children: e.jsx(s, { size: 20 }),
                  }),
                  e.jsxs("div", {
                    className: "min-w-0",
                    children: [
                      e.jsx("p", {
                        className:
                          "text-[10px] font-bold tracking-wider text-white/50",
                        children: t.label,
                      }),
                      e.jsx("p", {
                        className:
                          "mt-0.5 font-display text-xl sm:text-2xl font-black",
                        children: t.value,
                      }),
                      e.jsx("p", {
                        className: "text-[10px] text-white/50 mt-0.5 truncate",
                        children: t.hint,
                      }),
                    ],
                  }),
                ],
              }),
            },
            t.label,
          );
        }),
      }),
      e.jsxs("section", {
        className: "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-5",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2 mb-4",
            children: [
              e.jsx(I, { size: 16, className: "text-[#E040FB]" }),
              e.jsx("h2", {
                className: "font-display font-bold text-lg",
                children: "Prédictions Live",
              }),
              e.jsxs("span", {
                className:
                  "ml-auto flex items-center gap-1.5 text-[11px] text-emerald-400",
                children: [
                  e.jsx("span", {
                    className:
                      "h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse",
                  }),
                  " En direct",
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className:
              "hidden sm:grid grid-cols-[1.5fr_1fr_1fr_1.2fr_1fr] gap-3 text-[10px] font-bold tracking-wider text-white/40 px-2 pb-2 border-b border-white/[0.06]",
            children: [
              e.jsx("span", { children: "JEU" }),
              e.jsx("span", { children: "DERNIÈRE" }),
              e.jsx("span", { children: "COEFFICIENT" }),
              e.jsx("span", { children: "TAUX (JOUR)" }),
              e.jsx("span", { children: "STATUT" }),
            ],
          }),
          e.jsx("div", {
            className: "divide-y divide-white/[0.04]",
            children: c.map((t) => {
              const s = a.perGame[t.key],
                l = s && s.count > 0 ? (s.wins / s.count) * 100 : 0,
                r = s?.last?.coef;
              return e.jsxs(
                "div",
                {
                  className:
                    "grid grid-cols-2 sm:grid-cols-[1.5fr_1fr_1fr_1.2fr_1fr] gap-3 items-center px-2 py-3 text-sm",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-2 min-w-0",
                      children: [
                        e.jsx("img", {
                          src: t.img,
                          alt: "",
                          className: "h-7 w-7 rounded-md object-cover",
                        }),
                        e.jsx("span", {
                          className: "font-semibold truncate",
                          children: t.name,
                        }),
                      ],
                    }),
                    e.jsx("span", {
                      className: "text-white/60 text-xs font-mono",
                      children: s?.last?.time ?? "--:--:--",
                    }),
                    e.jsx("span", {
                      children: e.jsx("span", {
                        className: `inline-block rounded-md px-2 py-0.5 text-xs font-bold ${t.tone === "purple" ? "bg-[#7B2FFF]/20 text-[#c39bff]" : t.tone === "pink" ? "bg-[#E040FB]/20 text-[#f0a6ff]" : "bg-[#f59e0b]/20 text-[#fcd34d]"}`,
                        children: r ? `x${r.toFixed(2)}` : "—",
                      }),
                    }),
                    e.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        e.jsxs("span", {
                          className: "text-xs font-semibold w-12",
                          children: [l.toFixed(1), "%"],
                        }),
                        e.jsx("div", {
                          className:
                            "flex-1 h-1.5 rounded-full bg-white/[0.06] overflow-hidden",
                          children: e.jsx("div", {
                            className:
                              "h-full bg-gradient-to-r from-emerald-500 to-emerald-400",
                            style: { width: `${Math.min(100, l)}%` },
                          }),
                        }),
                      ],
                    }),
                    e.jsxs("span", {
                      className:
                        "flex items-center gap-1 text-xs text-amber-400",
                      children: [e.jsx(N, { size: 12 }), " Analyse"],
                    }),
                  ],
                },
                t.key,
              );
            }),
          }),
        ],
      }),
    ],
  });
}
export { G as component };
