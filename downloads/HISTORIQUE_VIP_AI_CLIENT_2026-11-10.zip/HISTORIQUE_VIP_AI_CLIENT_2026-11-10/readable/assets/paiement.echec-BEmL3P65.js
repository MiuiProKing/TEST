import { j as e, k as r, l as t } from "./index-C5ThNCN-.js";
import { D as a } from "./DashboardLayout-XCzqIJrp.js";
import { C as o } from "./circle-x-Bj11oEwU.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
function c() {
  return e.jsx(a, {
    children: e.jsxs("div", {
      className:
        "rounded-3xl border border-red-500/30 bg-gradient-to-br from-red-500/10 via-[#0F0B1F] to-[#0B0916] p-8 sm:p-12 text-center flex flex-col items-center gap-4",
      children: [
        e.jsx("div", {
          className:
            "h-20 w-20 rounded-full bg-red-500/20 flex items-center justify-center",
          children: e.jsx(o, { className: "w-12 h-12 text-red-400" }),
        }),
        e.jsx("h1", {
          className: "font-display font-black text-3xl",
          children: "Paiement non abouti",
        }),
        e.jsx("p", {
          className: "text-white/70 max-w-md",
          children:
            "La transaction n'a pas pu être finalisée. Aucun montant n'a été prélevé. Vous pouvez réessayer avec un autre moyen de paiement.",
        }),
        e.jsxs(r, {
          to: "/boutique",
          className:
            "mt-2 inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-white/10 border border-white/20 font-bold hover:bg-white/15",
          children: [e.jsx(t, { size: 16 }), " Retour à la boutique"],
        }),
      ],
    }),
  });
}
export { c as component };
