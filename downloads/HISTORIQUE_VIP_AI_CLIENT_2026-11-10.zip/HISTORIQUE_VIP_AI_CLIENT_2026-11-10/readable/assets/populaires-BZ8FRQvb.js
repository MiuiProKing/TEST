import { r, J as x, j as e, k as c } from "./index-C5ThNCN-.js";
import { f as n, D as m, F as o } from "./DashboardLayout-XCzqIJrp.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
function g() {
  const [a, i] = r.useState(null);
  r.useEffect(() => {
    x.rpc("popular_games", { _days: 7 }).then(({ data: s }) => i(s ?? []));
  }, []);
  const l = (a ?? []).filter((s) => n(s.game_path));
  return e.jsxs(m, {
    children: [
      e.jsxs("h1", {
        className: "font-display text-2xl font-black flex items-center gap-2",
        children: [
          e.jsx(o, { className: "text-[#E040FB]" }),
          " Jeux populaires",
        ],
      }),
      e.jsx("p", {
        className: "text-sm text-white/60",
        children:
          "Les jeux les plus joués par les membres ces 7 derniers jours.",
      }),
      a === null
        ? e.jsx("p", {
            className: "text-sm text-white/50",
            children: "Chargement…",
          })
        : l.length === 0
          ? e.jsx("p", {
              className: "text-sm text-white/50",
              children: "Pas encore assez de parties enregistrées.",
            })
          : e.jsx("ol", {
              className: "space-y-2",
              children: l.map((s, p) => {
                const t = n(s.game_path);
                return e.jsx(
                  "li",
                  {
                    children: e.jsxs(c, {
                      to: t.path,
                      className:
                        "flex items-center gap-3 rounded-xl bg-white/[0.04] px-4 py-3",
                      children: [
                        e.jsx("span", {
                          className: "w-6 font-black text-[#E040FB]",
                          children: p + 1,
                        }),
                        e.jsxs("span", {
                          className: "flex-1 text-sm",
                          children: [
                            t.name,
                            " ",
                            e.jsxs("span", {
                              className: "text-white/40",
                              children: ["· ", t.platform],
                            }),
                          ],
                        }),
                        e.jsxs("span", {
                          className: "text-xs text-white/50",
                          children: [
                            s.players,
                            " joueurs · ",
                            s.plays,
                            " visites",
                          ],
                        }),
                      ],
                    }),
                  },
                  s.game_path,
                );
              }),
            }),
    ],
  });
}
export { g as component };
