import { c as a, j as e, g as n } from "./index-C5ThNCN-.js";
import { D as o } from "./DashboardLayout-XCzqIJrp.js";
import { B as s } from "./bot-BCqi2W7b.js";
import { C as l } from "./circle-check-B56GEMOe.js";
import { R as i, P as c } from "./rocket-B4-ZWi-5.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const d = [
    ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
    ["path", { d: "M22 8c0-2.3-.8-4.3-2-6", key: "5bb3ad" }],
    [
      "path",
      {
        d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",
        key: "11g9vi",
      },
    ],
    ["path", { d: "M4 2C2.8 3.7 2 5.7 2 8", key: "tap9e0" }],
  ],
  x = a("bell-ring", d),
  m = "https://t.me/GODPREDITOR_bot",
  p = "https://historique-luckyjet.shop/",
  h = [
    {
      icon: s,
      title: "1. Ouvre le bot",
      text: "Clique sur le bouton ci-dessous, puis appuie sur « Démarrer » dans Telegram.",
    },
    {
      icon: n,
      title: "2. Inscris-toi sur 1win",
      text: "Utilise notre lien officiel et le code promo HAGA48, puis effectue ton premier dépôt.",
    },
    {
      icon: l,
      title: "3. Vérifie ton ID 1win",
      text: "Envoie ton ID au bot : s'il figure dans notre base, l'accès aux prédictions est activé instantanément.",
    },
    {
      icon: x,
      title: "4. Reçois les signaux",
      text: "Notifications automatiques à chaque signal, alerte grosse cote et confirmation verte quand la cote est validée.",
    },
  ];
function k() {
  return e.jsxs(o, {
    children: [
      e.jsxs("header", {
        className:
          "glass rounded-3xl px-4 sm:px-6 py-8 text-center relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(56,189,248,0.25),transparent_65%)]",
          }),
          e.jsx("div", {
            className:
              "relative mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-400/30 to-blue-600/30 border border-sky-400/30",
            children: e.jsx(s, { className: "h-8 w-8 text-sky-300" }),
          }),
          e.jsxs("h1", {
            className:
              "relative font-display font-bold text-2xl sm:text-3xl tracking-tight",
            children: [
              "BOT TELEGRAM ",
              e.jsx("span", {
                className: "text-sky-400 text-glow",
                children: "GOD PREDITOR",
              }),
            ],
          }),
          e.jsxs("p", {
            className:
              "relative text-sm text-muted-foreground mt-3 max-w-2xl mx-auto",
            children: [
              "Reçois les prédictions ",
              e.jsx("strong", {
                className: "text-foreground",
                children: "LuckyJet (1win)",
              }),
              " et",
              " ",
              e.jsx("strong", {
                className: "text-foreground",
                children: "JetX (Betclic)",
              }),
              " en automatique, directement dans Telegram.",
            ],
          }),
          e.jsxs("a", {
            href: m,
            target: "_blank",
            rel: "noopener noreferrer",
            className:
              "relative mt-6 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 px-6 py-3 font-semibold text-white shadow-[0_0_25px_rgba(56,189,248,0.45)] transition hover:brightness-110",
            children: [
              e.jsx(s, { className: "h-5 w-5" }),
              "Ouvrir @GODPREDITOR_bot",
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        className: "grid gap-3 sm:grid-cols-2",
        children: [
          e.jsx("h2", { className: "sr-only", children: "Comment ça marche" }),
          h.map((t) => {
            const r = t.icon;
            return e.jsxs(
              "article",
              {
                className: "glass rounded-2xl p-4 flex gap-3",
                children: [
                  e.jsx("div", {
                    className:
                      "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-500/15 border border-sky-400/20",
                    children: e.jsx(r, { className: "h-5 w-5 text-sky-300" }),
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("h3", {
                        className: "font-display font-bold text-sm",
                        children: t.title,
                      }),
                      e.jsx("p", {
                        className:
                          "text-xs text-muted-foreground mt-1 leading-relaxed",
                        children: t.text,
                      }),
                    ],
                  }),
                ],
              },
              t.title,
            );
          }),
        ],
      }),
      e.jsxs("section", {
        className: "glass rounded-3xl p-5 sm:p-6",
        children: [
          e.jsx("h2", {
            className: "font-display font-bold text-lg mb-4",
            children: "Format des prédictions envoyées",
          }),
          e.jsxs("div", {
            className:
              "rounded-2xl border border-sky-400/20 bg-black/30 p-4 font-mono text-xs sm:text-sm leading-relaxed",
            children: [
              e.jsx("p", {
                className: "text-sky-300 font-bold",
                children: "🎯 PRÉDICTION GOD PREDITOR",
              }),
              e.jsx("p", {
                className: "text-muted-foreground",
                children: "CÔTE ESTIMÉE : 4.85x",
              }),
              e.jsx("p", {
                className: "text-muted-foreground",
                children: "NIVEAU D'ASSURANCE : Élevé",
              }),
              e.jsx("p", {
                className: "text-muted-foreground",
                children: "FIABILITÉ : 82%",
              }),
              e.jsx("p", {
                className: "text-muted-foreground",
                children: "HEURE ESTIMÉE : 21h14",
              }),
              e.jsx("p", {
                className: "text-muted-foreground",
                children: "Fermeture estimée : 21h16",
              }),
              e.jsx("p", {
                className: "mt-3 text-emerald-400 font-bold",
                children: "🟢 CÔTE VALIDÉE — coefficient joué : 6.12x",
              }),
            ],
          }),
          e.jsxs("div", {
            className: "mt-4 grid gap-3 sm:grid-cols-2",
            children: [
              e.jsxs("div", {
                className: "glass rounded-2xl p-4 flex items-center gap-3",
                children: [
                  e.jsx(i, { className: "h-5 w-5 text-[var(--neon-orange)]" }),
                  e.jsx("span", {
                    className: "text-sm",
                    children: "LuckyJet — 1win",
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "glass rounded-2xl p-4 flex items-center gap-3",
                children: [
                  e.jsx(c, { className: "h-5 w-5 text-[var(--neon-purple)]" }),
                  e.jsx("span", {
                    className: "text-sm",
                    children: "JetX — Betclic",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        className: "glass rounded-3xl p-5 sm:p-6 text-center",
        children: [
          e.jsx("h2", {
            className: "font-display font-bold text-lg",
            children: "Pas encore de compte 1win ?",
          }),
          e.jsxs("p", {
            className: "text-sm text-muted-foreground mt-2",
            children: [
              "Inscris-toi avec le code promo ",
              e.jsx("strong", {
                className: "text-[var(--neon-orange)]",
                children: "HAGA48",
              }),
              " pour débloquer l'accès gratuit au bot.",
            ],
          }),
          e.jsx("a", {
            href: p,
            target: "_blank",
            rel: "noopener noreferrer",
            className:
              "mt-4 inline-flex items-center gap-2 rounded-2xl border border-[var(--neon-orange)]/40 bg-[var(--neon-orange)]/10 px-5 py-2.5 text-sm font-semibold text-[var(--neon-orange)] transition hover:bg-[var(--neon-orange)]/20",
            children: "S'inscrire sur 1win",
          }),
        ],
      }),
    ],
  });
}
export { k as component };
