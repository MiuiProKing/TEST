import {
  c as v,
  r as i,
  f as E,
  j as e,
  C as j,
  T as L,
  k as A,
  N as P,
  g as T,
} from "./index-C5ThNCN-.js";
import { D as I } from "./DashboardLayout-XCzqIJrp.js";
import { c as R } from "./tools.functions-DgdA5Uci.js";
import { D as O } from "./database-80brKRBJ.js";
import { B as y } from "./bot-BCqi2W7b.js";
import { W as V, S as J } from "./wrench-DMPf9Lxe.js";
import { G as w } from "./graduation-cap-XZTeMn7p.js";
import { Z as H } from "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
const U = [
    ["path", { d: "m18 16 4-4-4-4", key: "1inbqp" }],
    ["path", { d: "m6 8-4 4 4 4", key: "15zrgr" }],
    ["path", { d: "m14.5 4-5 16", key: "e7oirm" }],
  ],
  G = v("code-xml", U);
const $ = [
    [
      "rect",
      {
        width: "20",
        height: "8",
        x: "2",
        y: "2",
        rx: "2",
        ry: "2",
        key: "ngkwjq",
      },
    ],
    [
      "rect",
      {
        width: "20",
        height: "8",
        x: "2",
        y: "14",
        rx: "2",
        ry: "2",
        key: "iecqi9",
      },
    ],
    ["line", { x1: "6", x2: "6.01", y1: "6", y2: "6", key: "16zg32" }],
    ["line", { x1: "6", x2: "6.01", y1: "18", y2: "18", key: "nzw8ys" }],
  ],
  M = v("server", $),
  Z = [
    "LuckyJet (1win)",
    "JetX (1win)",
    "JetX (Betclic)",
    "Aviator (Betclic)",
    "Rocket Queen (1win)",
    "Dragon's Crash (Betclic)",
  ],
  N = [
    {
      id: "api_history",
      icon: O,
      title: "API Historique de jeux",
      tagline: "Accès brut aux tours de nos collecteurs, en temps réel.",
      price: 5e4,
      priceLabel: "50 000 FCFA / mois",
      features: [
        "Endpoint REST JSON sécurisé par clé API",
        "Historique brut : coefficient, horodatage, round ID",
        "Jusqu'à 6 jeux crash au choix",
        "Latence temps réel (mise à jour continue)",
        "Documentation + exemples d'intégration",
      ],
      accent: "#7B2FFF",
    },
    {
      id: "telegram_managed",
      icon: y,
      title: "Hébergement Telegram — clé en main",
      tagline: "Votre bot, notre moteur de signaux. Zéro code.",
      price: 5e4,
      priceLabel: "50 000 FCFA / mois",
      features: [
        "Vous fournissez le token, on branche tout",
        "Signaux automatiques + alertes grosse cote",
        "Menu, clés d'activation, gestion des abonnés",
        "Votre marque affichée dans les messages",
        "Hébergement 24/7 et supervision incluse",
      ],
      accent: "#E040FB",
    },
    {
      id: "telegram_custom",
      icon: M,
      title: "Hébergement Telegram — votre code",
      tagline: "Vous avez déjà votre bot ? On l'héberge.",
      price: null,
      priceLabel: "Sur devis",
      features: [
        "Déploiement de votre propre code de bot",
        "Webhook HTTPS, redémarrage automatique",
        "Logs et supervision",
        "Ressources dédiées selon la charge",
        "Devis sous 24h après votre demande",
      ],
      accent: "#22D3EE",
    },
  ],
  X = (o) => `${o.toLocaleString("fr-FR")} FCFA`;
function ie() {
  const [o, F] = i.useState("api_history"),
    [d, k] = i.useState(["LuckyJet (1win)"]),
    [m, B] = i.useState(""),
    [x, _] = i.useState(""),
    [u, S] = i.useState(""),
    [p, C] = i.useState(""),
    [h, g] = i.useState(!1),
    [b, n] = i.useState(null),
    [f, l] = i.useState(null),
    q = E(R),
    a = i.useMemo(() => N.find((t) => t.id === o), [o]);
  function D(t) {
    k((s) => (s.includes(t) ? s.filter((r) => r !== t) : [...s, t]));
  }
  async function z(t) {
    (t.preventDefault(), n(null), l(null), g(!0));
    try {
      const s = (() => {
          try {
            return window.top?.location.origin ?? window.location.origin;
          } catch {
            return window.location.origin;
          }
        })(),
        r = await q({
          data: {
            product: a.id,
            plan: a.title,
            games: a.id === "api_history" ? d : [],
            customerName: m,
            contact: x,
            telegram: u || void 0,
            note: p || void 0,
            amount: a.price ?? 0,
            origin: s,
          },
        });
      r.ok
        ? r.checkoutUrl
          ? (r.reference && localStorage.setItem("gp_tool_ref", r.reference),
            window.open(r.checkoutUrl, "_blank", "noopener,noreferrer") ||
              (window.location.href = r.checkoutUrl),
            l(
              "Commande enregistrée — finalisez le paiement dans l'onglet ouvert. Votre clé API est livrée automatiquement dès validation.",
            ))
          : l("Demande enregistrée. Notre équipe vous contacte sous 24h.")
        : n(r.error ?? "Impossible d'enregistrer la commande");
    } catch (s) {
      n(s?.message ?? "Erreur");
    } finally {
      g(!1);
    }
  }
  return e.jsxs(I, {
    children: [
      e.jsxs("header", {
        className:
          "rounded-3xl border border-white/[0.08] bg-gradient-to-br from-[#1a0b2e] via-[#0f0a1f] to-[#0b0916] px-4 sm:px-6 py-7 text-center relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(123,47,255,0.28),transparent_60%)]",
          }),
          e.jsxs("div", {
            className:
              "relative inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/15 bg-white/5 text-[11px] font-bold tracking-widest uppercase text-white/70",
            children: [e.jsx(V, { size: 13 }), " Outils Pro"],
          }),
          e.jsxs("h1", {
            className:
              "relative font-display font-black text-2xl sm:text-4xl tracking-tight mt-3",
            children: [
              "Nos",
              " ",
              e.jsx("span", {
                className:
                  "italic text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                children: "OUTILS",
              }),
              " ",
              "à vendre",
            ],
          }),
          e.jsx("p", {
            className: "relative text-sm text-white/60 mt-2 max-w-2xl mx-auto",
            children:
              "Branchez vos applications sur nos API d'historique de jeux crash, ou faites héberger votre bot Telegram de prédictions par notre infrastructure 24/7.",
          }),
        ],
      }),
      e.jsxs("section", {
        className: "mt-3 grid grid-cols-1 md:grid-cols-3 gap-3",
        children: [
          e.jsx("h2", { className: "sr-only", children: "Catalogue d'outils" }),
          N.map((t) => {
            const s = t.icon,
              r = o === t.id;
            return e.jsxs(
              "button",
              {
                type: "button",
                onClick: () => F(t.id),
                className: `text-left rounded-2xl border p-4 transition-all bg-[#0F0B1F] ${r ? "border-[#7B2FFF] shadow-[0_0_28px_rgba(123,47,255,0.28)]" : "border-white/[0.08] hover:border-white/20"}`,
                children: [
                  e.jsx("div", {
                    className:
                      "h-10 w-10 rounded-xl flex items-center justify-center mb-3",
                    style: { background: `${t.accent}22`, color: t.accent },
                    children: e.jsx(s, { size: 20 }),
                  }),
                  e.jsx("h3", {
                    className: "font-display font-bold text-base",
                    children: t.title,
                  }),
                  e.jsx("p", {
                    className: "text-xs text-white/55 mt-1",
                    children: t.tagline,
                  }),
                  e.jsx("p", {
                    className:
                      "mt-3 font-black text-lg text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                    children: t.priceLabel,
                  }),
                  e.jsx("ul", {
                    className: "mt-3 space-y-1.5",
                    children: t.features.map((c) =>
                      e.jsxs(
                        "li",
                        {
                          className: "flex gap-2 text-xs text-white/70",
                          children: [
                            e.jsx(j, {
                              size: 14,
                              className: "text-emerald-400 shrink-0 mt-0.5",
                            }),
                            e.jsx("span", { children: c }),
                          ],
                        },
                        c,
                      ),
                    ),
                  }),
                ],
              },
              t.id,
            );
          }),
        ],
      }),
      e.jsxs("section", {
        className:
          "mt-3 rounded-2xl border border-sky-400/20 bg-gradient-to-br from-[#0b1a2e] via-[#0a1220] to-[#0b0916] p-4 sm:p-6 relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_85%_0%,rgba(56,189,248,0.18),transparent_55%)]",
          }),
          e.jsxs("div", {
            className:
              "relative flex flex-col lg:flex-row lg:items-center gap-4",
            children: [
              e.jsx("div", {
                className:
                  "h-12 w-12 rounded-2xl bg-sky-400/15 text-sky-400 flex items-center justify-center shrink-0",
                children: e.jsx(w, { size: 24 }),
              }),
              e.jsxs("div", {
                className: "flex-1",
                children: [
                  e.jsxs("h2", {
                    className: "font-display font-bold text-lg",
                    children: [
                      "Formation ",
                      e.jsx("span", {
                        className:
                          "italic text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300",
                        children: "VIP Discord",
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-xs text-white/55 mt-1 max-w-2xl",
                    children:
                      "Rejoignez le salon privé « groupe-de-formation-vip » : tous nos échanges et explications en direct. Rôle VIP Formation attribué automatiquement dès le paiement, accès 6 mois complets.",
                  }),
                  e.jsx("ul", {
                    className: "mt-2 flex flex-wrap gap-x-4 gap-y-1",
                    children: [
                      "Salon privé Discord",
                      "Échanges en direct",
                      "Accès 6 mois",
                    ].map((t) =>
                      e.jsxs(
                        "li",
                        {
                          className:
                            "flex items-center gap-1.5 text-xs text-white/70",
                          children: [
                            e.jsx(j, {
                              size: 13,
                              className: "text-emerald-400 shrink-0",
                            }),
                            t,
                          ],
                        },
                        t,
                      ),
                    ),
                  }),
                ],
              }),
              e.jsxs("div", {
                className:
                  "flex flex-col items-start lg:items-end gap-2 shrink-0",
                children: [
                  e.jsx("p", {
                    className:
                      "font-black text-xl text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300",
                    children: "25 000 FCFA",
                  }),
                  e.jsxs("p", {
                    className:
                      "text-[10px] text-white/50 flex items-center gap-1 -mt-1",
                    children: [e.jsx(L, { size: 11 }), " 6 mois d'accès"],
                  }),
                  e.jsxs(A, {
                    to: "/formation",
                    className:
                      "inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-400 font-display font-black tracking-wider text-black text-sm shadow-lg shadow-sky-500/30",
                    children: [
                      e.jsx(w, { size: 15 }),
                      " Rejoindre la Formation",
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        className:
          "mt-3 rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-4 sm:p-6",
        children: [
          e.jsxs("h2", {
            className: "font-display font-bold text-lg flex items-center gap-2",
            children: [
              e.jsx(G, { size: 18, className: "text-[#7B2FFF]" }),
              " Aperçu de l'API historique",
            ],
          }),
          e.jsx("p", {
            className: "text-xs text-white/55 mt-1",
            children:
              "Une requête, tous les derniers tours d'un jeu. Format JSON stable, prêt pour vos bots et dashboards.",
          }),
          e.jsx("pre", {
            className:
              "mt-3 overflow-x-auto rounded-xl bg-black/50 border border-white/10 p-3 text-[11px] sm:text-xs text-emerald-300 font-mono",
            children: `GET /api/public/v1/rounds?game=luckyjet&limit=50
Authorization: Bearer <VOTRE_CLE_API>

{
  "game": "luckyjet",
  "rounds": [
    { "round_id": "8241993", "coefficient": 12.47, "at": "2026-08-10T14:58:31Z" },
    { "round_id": "8241992", "coefficient": 1.08,  "at": "2026-08-10T14:57:52Z" }
  ]
}`,
          }),
        ],
      }),
      e.jsxs("section", {
        className: "mt-3 grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-3",
        children: [
          e.jsxs("form", {
            onSubmit: z,
            className:
              "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-4 sm:p-6",
            children: [
              e.jsxs("h2", {
                className: "font-display font-bold text-lg",
                children: ["Commander : ", a.title],
              }),
              e.jsx("p", {
                className: "text-xs text-white/55 mt-1",
                children: a.priceLabel,
              }),
              a.id === "api_history" &&
                e.jsxs("div", {
                  className: "mt-4",
                  children: [
                    e.jsx("p", {
                      className:
                        "text-xs font-bold uppercase tracking-wider text-white/50 mb-2",
                      children: "Jeux souhaités",
                    }),
                    e.jsx("div", {
                      className: "flex flex-wrap gap-2",
                      children: Z.map((t) => {
                        const s = d.includes(t);
                        return e.jsx(
                          "button",
                          {
                            type: "button",
                            onClick: () => D(t),
                            className: `px-3 py-1.5 rounded-xl text-xs border transition-all ${s ? "border-[#7B2FFF] bg-[#7B2FFF]/20 text-white" : "border-white/10 bg-white/[0.03] text-white/60 hover:text-white"}`,
                            children: t,
                          },
                          t,
                        );
                      }),
                    }),
                  ],
                }),
              e.jsxs("div", {
                className: "mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3",
                children: [
                  e.jsxs("label", {
                    className: "text-xs text-white/60",
                    children: [
                      "Nom / société",
                      e.jsx("input", {
                        required: !0,
                        minLength: 2,
                        value: m,
                        onChange: (t) => B(t.target.value),
                        className:
                          "mt-1 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white outline-none focus:border-[#7B2FFF]",
                        placeholder: "Ex : Haga Prediction",
                      }),
                    ],
                  }),
                  e.jsxs("label", {
                    className: "text-xs text-white/60",
                    children: [
                      "Email ou téléphone",
                      e.jsx("input", {
                        required: !0,
                        value: x,
                        onChange: (t) => _(t.target.value),
                        className:
                          "mt-1 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white outline-none focus:border-[#7B2FFF]",
                        placeholder: "Ex : contact@site.com",
                      }),
                    ],
                  }),
                  e.jsxs("label", {
                    className: "text-xs text-white/60",
                    children: [
                      "Telegram (facultatif)",
                      e.jsx("input", {
                        value: u,
                        onChange: (t) => S(t.target.value),
                        className:
                          "mt-1 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white outline-none focus:border-[#7B2FFF]",
                        placeholder: "@votrepseudo",
                      }),
                    ],
                  }),
                  e.jsxs("label", {
                    className: "text-xs text-white/60 sm:col-span-2",
                    children: [
                      "Détails de votre besoin",
                      e.jsx("textarea", {
                        rows: 3,
                        value: p,
                        onChange: (t) => C(t.target.value),
                        className:
                          "mt-1 w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-sm text-white outline-none focus:border-[#7B2FFF]",
                        placeholder:
                          a.id === "telegram_managed"
                            ? "Nom du bot, marque à afficher, jeux à diffuser…"
                            : "Volume de requêtes, technologie utilisée, contraintes…",
                      }),
                    ],
                  }),
                ],
              }),
              b &&
                e.jsx("p", {
                  className: "mt-3 text-sm text-red-400",
                  children: b,
                }),
              f &&
                e.jsx("p", {
                  className: "mt-3 text-sm text-emerald-400",
                  children: f,
                }),
              e.jsxs("button", {
                type: "submit",
                disabled: h,
                className:
                  "mt-4 w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] font-bold text-sm disabled:opacity-60",
                children: [
                  h
                    ? e.jsx(P, { className: "w-4 h-4 animate-spin" })
                    : e.jsx(J, { size: 16 }),
                  a.price ? `Payer ${X(a.price)}` : "Demander un devis",
                ],
              }),
              e.jsx("p", {
                className: "mt-2 text-[11px] text-white/40 text-center",
                children:
                  "Paiement sécurisé par Mobile Money, carte bancaire ou USDT.",
              }),
            ],
          }),
          e.jsxs("aside", {
            className:
              "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-4 space-y-3 h-fit",
            children: [
              e.jsx("h2", {
                className: "font-display font-bold text-base",
                children: "Pourquoi nos outils ?",
              }),
              [
                {
                  icon: H,
                  t: "Données temps réel",
                  s: "Collecteurs actifs 24/7 sur plusieurs opérateurs.",
                },
                {
                  icon: T,
                  t: "Clé API sécurisée",
                  s: "Quota et révocation à tout moment.",
                },
                {
                  icon: y,
                  t: "Bots supervisés",
                  s: "Redémarrage auto et surveillance des webhooks.",
                },
              ].map((t) =>
                e.jsxs(
                  "div",
                  {
                    className: "flex gap-3",
                    children: [
                      e.jsx("div", {
                        className:
                          "h-9 w-9 rounded-xl bg-[#7B2FFF]/15 text-[#B388FF] flex items-center justify-center shrink-0",
                        children: e.jsx(t.icon, { size: 16 }),
                      }),
                      e.jsxs("div", {
                        children: [
                          e.jsx("p", {
                            className: "text-sm font-semibold",
                            children: t.t,
                          }),
                          e.jsx("p", {
                            className: "text-xs text-white/55",
                            children: t.s,
                          }),
                        ],
                      }),
                    ],
                  },
                  t.t,
                ),
              ),
            ],
          }),
        ],
      }),
    ],
  });
}
export { ie as component };
