import {
  c as T,
  u as C,
  V as G,
  r as c,
  J as h,
  j as e,
  m as I,
  M as $,
} from "./index-C5ThNCN-.js";
import { R as P } from "./RoundCard-CZ-rEJ_D.js";
import { D as R } from "./DashboardLayout-XCzqIJrp.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const F = [
    ["path", { d: "M8 2v4", key: "1cmpym" }],
    ["path", { d: "M16 2v4", key: "4m81vk" }],
    [
      "rect",
      { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" },
    ],
    ["path", { d: "M3 10h18", key: "8toen8" }],
  ],
  O = T("calendar", F);
function k() {
  try {
    const n = new Date();
    return (
      n.setMinutes(n.getMinutes() - n.getTimezoneOffset()),
      n.toISOString().slice(0, 10)
    );
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}
const w = [
  {
    key: "luckyjet",
    label: "Lucky Jet — 1Win",
    table: "luckyjet_rounds",
    accent: "text-[var(--neon-purple)]",
  },
  {
    key: "astronaut",
    label: "Astronaut — 1Win",
    table: "astronaut_rounds",
    accent: "text-[var(--neon-blue)]",
  },
  {
    key: "crash",
    label: "Crash — 1Win",
    table: "crash_rounds",
    accent: "text-[var(--neon-blue)]",
  },
  {
    key: "rocketqueen",
    label: "Rocket Queen — 1Win",
    table: "rocketqueen_rounds",
    accent: "text-[var(--neon-orange)]",
  },
  {
    key: "jetx",
    label: "JetX — Betclic",
    table: "jetx_rounds",
    accent: "text-orange-400",
  },
  {
    key: "aviator",
    label: "Aviator — Betclic",
    table: "aviator_rounds",
    accent: "text-[var(--neon-orange)]",
  },
  {
    key: "jetx1win",
    label: "JetX — 1Win",
    table: "jetx_1win_rounds",
    accent: "text-pink-400",
  },
  {
    key: "highflyer",
    label: "High Flyer — Betclic",
    table: "highflyer_rounds",
    accent: "text-fuchsia-400",
  },
  {
    key: "dragonscrash",
    label: "Dragon's Crash — Betclic",
    table: "dragonscrash_rounds",
    accent: "text-emerald-400",
  },
];
function S() {
  if (typeof window > "u") return "luckyjet";
  const n = localStorage.getItem("lj_current_game");
  return n === "crash" ||
    n === "rocketqueen" ||
    n === "jetx" ||
    n === "jetx1win" ||
    n === "highflyer" ||
    n === "dragonscrash" ||
    n === "astronaut" ||
    n === "aviator"
    ? n
    : "luckyjet";
}
function X() {
  const { t: n } = C(),
    u = G.useSearch(),
    [o, _] = c.useState(k()),
    [b, j] = c.useState(() => u.game ?? S()),
    [x, g] = c.useState([]),
    [E, f] = c.useState(!1),
    i = w.find((t) => t.key === b);
  (c.useEffect(() => {
    j(u.game ?? S());
  }, [u.game]),
    c.useEffect(() => {
      if (!o || !/^\d{4}-\d{2}-\d{2}$/.test(o)) return;
      let t = !1;
      (f(!0), g([]));
      const a = new Date(`${o}T00:00:00`),
        s = new Date(`${o}T23:59:59.999`);
      if (isNaN(a.getTime()) || isNaN(s.getTime())) {
        f(!1);
        return;
      }
      return (
        (async () => {
          const l = [];
          for (let d = 0; d < 20; d++) {
            const { data: p, error: M } = await h
              .from(i.table)
              .select("id,coefficient,color,played_at")
              .gte("played_at", a.toISOString())
              .lte("played_at", s.toISOString())
              .order("played_at", { ascending: !1 })
              .range(d * 1e3, d * 1e3 + 1e3 - 1);
            if (t) return;
            if (M || !p || (l.push(...p), p.length < 1e3)) break;
          }
          if (t) return;
          const N = new Set();
          (g(l.filter((d) => (N.has(d.id) ? !1 : (N.add(d.id), !0)))), f(!1));
        })(),
        () => {
          t = !0;
        }
      );
    }, [o, i.table]),
    c.useEffect(() => {
      const t = h
        .channel(`hist-${i.table}`)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: i.table },
          (a) => {
            const s = a.new;
            s?.played_at &&
              s.played_at.slice(0, 10) === o &&
              g((r) => (r.some((l) => l.id === s.id) ? r : [s, ...r]));
          },
        )
        .subscribe();
      return () => {
        h.removeChannel(t);
      };
    }, [o, i.table]));
  const v = c.useMemo(() => {
      const t = new Map();
      for (const a of x) {
        const s = new Date(a.played_at).getHours();
        (t.has(s) || t.set(s, []), t.get(s).push(a));
      }
      return Array.from(t.entries()).sort((a, s) => s[0] - a[0]);
    }, [x]),
    m = x.length,
    A = m ? x.reduce((t, a) => t + Number(a.coefficient), 0) / m : 0,
    D = x.reduce(
      (t, a) => (Number(a.coefficient) > t ? Number(a.coefficient) : t),
      0,
    );
  return e.jsxs(R, {
    children: [
      e.jsxs("header", {
        className:
          "glass rounded-3xl px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-3",
        children: [
          e.jsxs("h1", {
            className:
              "font-display font-bold text-lg sm:text-2xl tracking-tight",
            children: [
              n("home.history_title"),
              " — ",
              e.jsx("span", {
                className: `${i.accent} text-glow`,
                children: i.label,
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2 flex-wrap",
            children: [
              e.jsx("div", {
                className: "flex items-center gap-1 glass rounded-xl p-1",
                children: w.map((t) =>
                  e.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        (localStorage.setItem("lj_current_game", t.key),
                          j(t.key));
                      },
                      className: `px-3 py-1.5 rounded-lg text-xs font-display font-bold transition-colors ${b === t.key ? "bg-white/10 text-foreground shadow-inner" : "text-muted-foreground hover:text-foreground"}`,
                      children: t.label,
                    },
                    t.key,
                  ),
                ),
              }),
              e.jsxs("div", {
                className: "flex items-center gap-2 glass rounded-xl px-3 py-2",
                children: [
                  e.jsx(O, { className: "w-4 h-4 text-[var(--neon-blue)]" }),
                  e.jsx("input", {
                    type: "date",
                    value: o,
                    onChange: (t) => _(t.target.value),
                    max: k(),
                    "aria-label": "Sélectionner la date",
                    className: "bg-transparent outline-none text-sm font-mono",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-3 gap-3 sm:gap-4",
        children: [
          e.jsx(y, {
            label: "Tours joués",
            value: String(m),
            accent: "text-[var(--neon-blue)]",
          }),
          e.jsx(y, {
            label: "Coef. moyen",
            value: m ? `${A.toFixed(2)}x` : "—",
            accent: "text-[var(--neon-purple)]",
          }),
          e.jsx(y, {
            label: "Plus gros multi",
            value: m ? `${D.toFixed(2)}x` : "—",
            accent: "text-[var(--neon-orange)]",
          }),
        ],
      }),
      E
        ? e.jsx("div", {
            className:
              "glass rounded-3xl p-8 text-center text-muted-foreground font-mono text-sm",
            children: "Chargement de l'historique…",
          })
        : v.length === 0
          ? e.jsx("div", {
              className:
                "glass rounded-3xl p-8 text-center text-muted-foreground font-mono text-sm",
              children: "Aucun tour archivé pour cette journée.",
            })
          : e.jsx("div", {
              className: "flex flex-col gap-4",
              children: v.map(([t, a], s) =>
                e.jsxs(
                  I.section,
                  {
                    initial: { opacity: 0, y: 10 },
                    animate: { opacity: 1, y: 0 },
                    transition: { delay: s * 0.03 },
                    className: "glass rounded-3xl p-4 sm:p-6",
                    children: [
                      e.jsxs("div", {
                        className:
                          "flex items-end justify-between flex-wrap gap-2 mb-4",
                        children: [
                          e.jsxs("h2", {
                            className:
                              "font-display font-bold text-base sm:text-lg tracking-tight",
                            children: [
                              e.jsxs("span", {
                                className: "text-[var(--neon-blue)] text-glow",
                                children: [String(t).padStart(2, "0"), "h00"],
                              }),
                              " ",
                              "— ",
                              String((t + 1) % 24).padStart(2, "0"),
                              "h00",
                            ],
                          }),
                          e.jsxs("div", {
                            className:
                              "flex flex-wrap gap-3 text-[11px] font-mono text-muted-foreground",
                            children: [
                              e.jsxs("span", {
                                children: [a.length, " tours"],
                              }),
                              e.jsxs("span", {
                                children: [
                                  "moy.",
                                  " ",
                                  e.jsxs("span", {
                                    className: "text-foreground",
                                    children: [
                                      (
                                        a.reduce(
                                          (r, l) => r + Number(l.coefficient),
                                          0,
                                        ) / a.length
                                      ).toFixed(2),
                                      "x",
                                    ],
                                  }),
                                ],
                              }),
                              e.jsxs("span", {
                                children: [
                                  "max",
                                  " ",
                                  e.jsxs("span", {
                                    className: "text-[var(--neon-orange)]",
                                    children: [
                                      Math.max(
                                        ...a.map((r) => Number(r.coefficient)),
                                      ).toFixed(2),
                                      "x",
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      e.jsx("div", {
                        className:
                          "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                        children: a.map((r) => {
                          const l = {
                            id: r.id,
                            coefficient: Number(r.coefficient),
                            color: $(Number(r.coefficient)),
                            timestamp: new Date(r.played_at).getTime(),
                          };
                          return e.jsx(P, { round: l }, r.id);
                        }),
                      }),
                    ],
                  },
                  t,
                ),
              ),
            }),
    ],
  });
}
function y({ label: n, value: u, accent: o }) {
  return e.jsxs("div", {
    className: "glass rounded-2xl p-3 sm:p-4 flex flex-col gap-1",
    children: [
      e.jsx("span", {
        className:
          "text-[10px] sm:text-xs uppercase tracking-widest text-muted-foreground",
        children: n,
      }),
      e.jsx("span", {
        className: `font-display font-bold text-lg sm:text-2xl text-glow ${o}`,
        children: u,
      }),
    ],
  });
}
export { X as component };
