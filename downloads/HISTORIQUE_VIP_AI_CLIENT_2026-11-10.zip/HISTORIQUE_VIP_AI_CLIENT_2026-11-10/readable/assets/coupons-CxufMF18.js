import {
  O as E,
  R as v,
  r as g,
  J as w,
  j as s,
  a as S,
} from "./index-C5ThNCN-.js";
import { D as T, T as N } from "./DashboardLayout-XCzqIJrp.js";
import { T as C } from "./trash-2-DSXLM6oL.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
E();
function R(d) {
  if (typeof document > "u") return;
  let a = document.head || document.getElementsByTagName("head")[0],
    t = document.createElement("style");
  ((t.type = "text/css"),
    a.appendChild(t),
    t.styleSheet
      ? (t.styleSheet.cssText = d)
      : t.appendChild(document.createTextNode(d)));
}
Array(12).fill(0);
let j = 1;
class Y {
  constructor() {
    ((this.subscribe = (a) => (
      this.subscribers.push(a),
      () => {
        const t = this.subscribers.indexOf(a);
        this.subscribers.splice(t, 1);
      }
    )),
      (this.publish = (a) => {
        this.subscribers.forEach((t) => t(a));
      }),
      (this.addToast = (a) => {
        (this.publish(a), (this.toasts = [...this.toasts, a]));
      }),
      (this.create = (a) => {
        var t;
        const { message: r, ...b } = a,
          i =
            typeof a?.id == "number" ||
            ((t = a.id) == null ? void 0 : t.length) > 0
              ? a.id
              : j++,
          u = this.toasts.find((l) => l.id === i),
          p = a.dismissible === void 0 ? !0 : a.dismissible;
        return (
          this.dismissedToasts.has(i) && this.dismissedToasts.delete(i),
          u
            ? (this.toasts = this.toasts.map((l) =>
                l.id === i
                  ? (this.publish({ ...l, ...a, id: i, title: r }),
                    { ...l, ...a, id: i, dismissible: p, title: r })
                  : l,
              ))
            : this.addToast({ title: r, ...b, dismissible: p, id: i }),
          i
        );
      }),
      (this.dismiss = (a) => (
        a
          ? (this.dismissedToasts.add(a),
            requestAnimationFrame(() =>
              this.subscribers.forEach((t) => t({ id: a, dismiss: !0 })),
            ))
          : this.toasts.forEach((t) => {
              this.subscribers.forEach((r) => r({ id: t.id, dismiss: !0 }));
            }),
        a
      )),
      (this.message = (a, t) => this.create({ ...t, message: a })),
      (this.error = (a, t) => this.create({ ...t, message: a, type: "error" })),
      (this.success = (a, t) =>
        this.create({ ...t, type: "success", message: a })),
      (this.info = (a, t) => this.create({ ...t, type: "info", message: a })),
      (this.warning = (a, t) =>
        this.create({ ...t, type: "warning", message: a })),
      (this.loading = (a, t) =>
        this.create({ ...t, type: "loading", message: a })),
      (this.promise = (a, t) => {
        if (!t) return;
        let r;
        t.loading !== void 0 &&
          (r = this.create({
            ...t,
            promise: a,
            type: "loading",
            message: t.loading,
            description:
              typeof t.description != "function" ? t.description : void 0,
          }));
        const b = Promise.resolve(a instanceof Function ? a() : a);
        let i = r !== void 0,
          u;
        const p = b
            .then(async (o) => {
              if (((u = ["resolve", o]), v.isValidElement(o)))
                ((i = !1), this.create({ id: r, type: "default", message: o }));
              else if (F(o) && !o.ok) {
                i = !1;
                const n =
                    typeof t.error == "function"
                      ? await t.error(`HTTP error! status: ${o.status}`)
                      : t.error,
                  f =
                    typeof t.description == "function"
                      ? await t.description(`HTTP error! status: ${o.status}`)
                      : t.description,
                  h =
                    typeof n == "object" && !v.isValidElement(n)
                      ? n
                      : { message: n };
                this.create({ id: r, type: "error", description: f, ...h });
              } else if (o instanceof Error) {
                i = !1;
                const n =
                    typeof t.error == "function" ? await t.error(o) : t.error,
                  f =
                    typeof t.description == "function"
                      ? await t.description(o)
                      : t.description,
                  h =
                    typeof n == "object" && !v.isValidElement(n)
                      ? n
                      : { message: n };
                this.create({ id: r, type: "error", description: f, ...h });
              } else if (t.success !== void 0) {
                i = !1;
                const n =
                    typeof t.success == "function"
                      ? await t.success(o)
                      : t.success,
                  f =
                    typeof t.description == "function"
                      ? await t.description(o)
                      : t.description,
                  h =
                    typeof n == "object" && !v.isValidElement(n)
                      ? n
                      : { message: n };
                this.create({ id: r, type: "success", description: f, ...h });
              }
            })
            .catch(async (o) => {
              if (((u = ["reject", o]), t.error !== void 0)) {
                i = !1;
                const m =
                    typeof t.error == "function" ? await t.error(o) : t.error,
                  n =
                    typeof t.description == "function"
                      ? await t.description(o)
                      : t.description,
                  y =
                    typeof m == "object" && !v.isValidElement(m)
                      ? m
                      : { message: m };
                this.create({ id: r, type: "error", description: n, ...y });
              }
            })
            .finally(() => {
              (i && (this.dismiss(r), (r = void 0)),
                t.finally == null || t.finally.call(t));
            }),
          l = () =>
            new Promise((o, m) =>
              p.then(() => (u[0] === "reject" ? m(u[1]) : o(u[1]))).catch(m),
            );
        return typeof r != "string" && typeof r != "number"
          ? { unwrap: l }
          : Object.assign(r, { unwrap: l });
      }),
      (this.custom = (a, t) => {
        const r = t?.id || j++;
        return (this.create({ jsx: a(r), id: r, ...t }), r);
      }),
      (this.getActiveToasts = () =>
        this.toasts.filter((a) => !this.dismissedToasts.has(a.id))),
      (this.subscribers = []),
      (this.toasts = []),
      (this.dismissedToasts = new Set()));
  }
}
const c = new Y(),
  z = (d, a) => {
    const t = a?.id || j++;
    return (c.addToast({ title: d, ...a, id: t }), t);
  },
  F = (d) =>
    d &&
    typeof d == "object" &&
    "ok" in d &&
    typeof d.ok == "boolean" &&
    "status" in d &&
    typeof d.status == "number",
  _ = z,
  B = () => c.toasts,
  D = () => c.getActiveToasts(),
  k = Object.assign(
    _,
    {
      success: c.success,
      info: c.info,
      warning: c.warning,
      error: c.error,
      custom: c.custom,
      message: c.message,
      promise: c.promise,
      dismiss: c.dismiss,
      loading: c.loading,
    },
    { getHistory: B, getToasts: D },
  );
R(
  "[data-sonner-toaster][dir=ltr],html[dir=ltr]{--toast-icon-margin-start:-3px;--toast-icon-margin-end:4px;--toast-svg-margin-start:-1px;--toast-svg-margin-end:0px;--toast-button-margin-start:auto;--toast-button-margin-end:0;--toast-close-button-start:0;--toast-close-button-end:unset;--toast-close-button-transform:translate(-35%, -35%)}[data-sonner-toaster][dir=rtl],html[dir=rtl]{--toast-icon-margin-start:4px;--toast-icon-margin-end:-3px;--toast-svg-margin-start:0px;--toast-svg-margin-end:-1px;--toast-button-margin-start:0;--toast-button-margin-end:auto;--toast-close-button-start:unset;--toast-close-button-end:0;--toast-close-button-transform:translate(35%, -35%)}[data-sonner-toaster]{position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1:hsl(0, 0%, 99%);--gray2:hsl(0, 0%, 97.3%);--gray3:hsl(0, 0%, 95.1%);--gray4:hsl(0, 0%, 93%);--gray5:hsl(0, 0%, 90.9%);--gray6:hsl(0, 0%, 88.7%);--gray7:hsl(0, 0%, 85.8%);--gray8:hsl(0, 0%, 78%);--gray9:hsl(0, 0%, 56.1%);--gray10:hsl(0, 0%, 52.3%);--gray11:hsl(0, 0%, 43.5%);--gray12:hsl(0, 0%, 9%);--border-radius:8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:0;z-index:999999999;transition:transform .4s ease}@media (hover:none) and (pointer:coarse){[data-sonner-toaster][data-lifted=true]{transform:none}}[data-sonner-toaster][data-x-position=right]{right:var(--offset-right)}[data-sonner-toaster][data-x-position=left]{left:var(--offset-left)}[data-sonner-toaster][data-x-position=center]{left:50%;transform:translateX(-50%)}[data-sonner-toaster][data-y-position=top]{top:var(--offset-top)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--offset-bottom)}[data-sonner-toast]{--y:translateY(100%);--lift-amount:calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:0;overflow-wrap:anywhere}[data-sonner-toast][data-styled=true]{padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px rgba(0,0,0,.1);width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}[data-sonner-toast]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-y-position=top]{top:0;--y:translateY(-100%);--lift:1;--lift-amount:calc(1 * var(--gap))}[data-sonner-toast][data-y-position=bottom]{bottom:0;--y:translateY(100%);--lift:-1;--lift-amount:calc(var(--lift) * var(--gap))}[data-sonner-toast][data-styled=true] [data-description]{font-weight:400;line-height:1.4;color:#3f3f3f}[data-rich-colors=true][data-sonner-toast][data-styled=true] [data-description]{color:inherit}[data-sonner-toaster][data-sonner-theme=dark] [data-description]{color:#e8e8e8}[data-sonner-toast][data-styled=true] [data-title]{font-weight:500;line-height:1.5;color:inherit}[data-sonner-toast][data-styled=true] [data-icon]{display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}[data-sonner-toast][data-promise=true] [data-icon]>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}[data-sonner-toast][data-styled=true] [data-icon]>*{flex-shrink:0}[data-sonner-toast][data-styled=true] [data-icon] svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}[data-sonner-toast][data-styled=true] [data-content]{display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;font-weight:500;cursor:pointer;outline:0;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}[data-sonner-toast][data-styled=true] [data-button]:focus-visible{box-shadow:0 0 0 2px rgba(0,0,0,.4)}[data-sonner-toast][data-styled=true] [data-button]:first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}[data-sonner-toast][data-styled=true] [data-cancel]{color:var(--normal-text);background:rgba(0,0,0,.08)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-styled=true] [data-cancel]{background:rgba(255,255,255,.3)}[data-sonner-toast][data-styled=true] [data-close-button]{position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);background:var(--normal-bg);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast][data-styled=true] [data-close-button]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-styled=true] [data-disabled=true]{cursor:not-allowed}[data-sonner-toast][data-styled=true]:hover [data-close-button]:hover{background:var(--gray2);border-color:var(--gray5)}[data-sonner-toast][data-swiping=true]::before{content:'';position:absolute;left:-100%;right:-100%;height:100%;z-index:-1}[data-sonner-toast][data-y-position=top][data-swiping=true]::before{bottom:50%;transform:scaleY(3) translateY(50%)}[data-sonner-toast][data-y-position=bottom][data-swiping=true]::before{top:50%;transform:scaleY(3) translateY(-50%)}[data-sonner-toast][data-swiping=false][data-removed=true]::before{content:'';position:absolute;inset:0;transform:scaleY(2)}[data-sonner-toast][data-expanded=true]::after{content:'';position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}[data-sonner-toast][data-mounted=true]{--y:translateY(0);opacity:1}[data-sonner-toast][data-expanded=false][data-front=false]{--scale:var(--toasts-before) * 0.05 + 1;--y:translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}[data-sonner-toast]>*{transition:opacity .4s}[data-sonner-toast][data-x-position=right]{right:0}[data-sonner-toast][data-x-position=left]{left:0}[data-sonner-toast][data-expanded=false][data-front=false][data-styled=true]>*{opacity:0}[data-sonner-toast][data-visible=false]{opacity:0;pointer-events:none}[data-sonner-toast][data-mounted=true][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}[data-sonner-toast][data-removed=true][data-front=true][data-swipe-out=false]{--y:translateY(calc(var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=false]{--y:translateY(40%);opacity:0;transition:transform .5s,opacity .2s}[data-sonner-toast][data-removed=true][data-front=false]::before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y,0)) translateX(var(--swipe-amount-x,0));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width:600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-sonner-theme=light]{--normal-bg:#fff;--normal-border:var(--gray4);--normal-text:var(--gray12);--success-bg:hsl(143, 85%, 96%);--success-border:hsl(145, 92%, 87%);--success-text:hsl(140, 100%, 27%);--info-bg:hsl(208, 100%, 97%);--info-border:hsl(221, 91%, 93%);--info-text:hsl(210, 92%, 45%);--warning-bg:hsl(49, 100%, 97%);--warning-border:hsl(49, 91%, 84%);--warning-text:hsl(31, 92%, 45%);--error-bg:hsl(359, 100%, 97%);--error-border:hsl(359, 100%, 94%);--error-text:hsl(360, 100%, 45%)}[data-sonner-toaster][data-sonner-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg:#000;--normal-border:hsl(0, 0%, 20%);--normal-text:var(--gray1)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg:#fff;--normal-border:var(--gray3);--normal-text:var(--gray12)}[data-sonner-toaster][data-sonner-theme=dark]{--normal-bg:#000;--normal-bg-hover:hsl(0, 0%, 12%);--normal-border:hsl(0, 0%, 20%);--normal-border-hover:hsl(0, 0%, 25%);--normal-text:var(--gray1);--success-bg:hsl(150, 100%, 6%);--success-border:hsl(147, 100%, 12%);--success-text:hsl(150, 86%, 65%);--info-bg:hsl(215, 100%, 6%);--info-border:hsl(223, 43%, 17%);--info-text:hsl(216, 87%, 65%);--warning-bg:hsl(64, 100%, 6%);--warning-border:hsl(60, 100%, 9%);--warning-text:hsl(46, 87%, 65%);--error-bg:hsl(358, 76%, 10%);--error-border:hsl(357, 89%, 16%);--error-text:hsl(358, 100%, 81%)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size:16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:first-child{animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}100%{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}100%{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}100%{opacity:.15}}@media (prefers-reduced-motion){.sonner-loading-bar,[data-sonner-toast],[data-sonner-toast]>*{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}",
);
const A = ["1xBet", "1Win", "Melbet", "Betclic", "Autre"];
function I() {
  const [d, a] = g.useState([]),
    [t, r] = g.useState(null),
    [b, i] = g.useState("1xBet"),
    [u, p] = g.useState(""),
    [l, o] = g.useState(""),
    [m, n] = g.useState(!1),
    f = async () => {
      const { data: e } = await w
        .from("bet_coupons")
        .select("*")
        .order("created_at", { ascending: !1 })
        .limit(100);
      a(e ?? []);
    };
  g.useEffect(() => {
    (w.auth.getUser().then(({ data: e }) => {
      const x = e.user;
      x &&
        r({
          id: x.id,
          name: (
            x.user_metadata?.first_name ||
            x.email?.split("@")[0] ||
            "Utilisateur"
          ).slice(0, 40),
        });
    }),
      f());
  }, []);
  const y = async (e) => {
      if ((e.preventDefault(), !t))
        return k.error("Connectez-vous pour publier un coupon.");
      if (!u.trim()) return;
      n(!0);
      const { error: x } = await w
        .from("bet_coupons")
        .insert({
          user_id: t.id,
          author_name: t.name,
          bookmaker: b,
          code: u.trim().slice(0, 60),
          description: l.trim().slice(0, 300) || null,
        });
      if ((n(!1), x)) return k.error("Publication impossible.");
      (p(""), o(""), k.success("Coupon publié !"), f());
    },
    h = async (e) => {
      (await w.from("bet_coupons").delete().eq("id", e), f());
    };
  return s.jsxs(T, {
    children: [
      s.jsxs("h1", {
        className: "font-display text-2xl font-black flex items-center gap-2",
        children: [
          s.jsx(N, { className: "text-[#E040FB]" }),
          " Coupons de paris",
        ],
      }),
      s.jsxs("form", {
        onSubmit: y,
        className:
          "space-y-2 rounded-2xl border border-white/[0.08] bg-white/[0.03] p-4",
        children: [
          s.jsxs("div", {
            className: "flex gap-2",
            children: [
              s.jsx("select", {
                value: b,
                onChange: (e) => i(e.target.value),
                className:
                  "rounded-lg bg-[#12101F] border border-white/10 px-2 py-2 text-sm",
                children: A.map((e) => s.jsx("option", { children: e }, e)),
              }),
              s.jsx("input", {
                value: u,
                onChange: (e) => p(e.target.value),
                maxLength: 60,
                placeholder: "Code du coupon",
                className:
                  "flex-1 rounded-lg bg-[#12101F] border border-white/10 px-3 py-2 text-sm",
              }),
            ],
          }),
          s.jsx("input", {
            value: l,
            onChange: (e) => o(e.target.value),
            maxLength: 300,
            placeholder: "Description (matchs, cote totale…)",
            className:
              "w-full rounded-lg bg-[#12101F] border border-white/10 px-3 py-2 text-sm",
          }),
          s.jsx("button", {
            disabled: m,
            className:
              "w-full rounded-lg bg-gradient-to-r from-[#7B2FFF] to-[#E040FB] py-2 text-sm font-semibold disabled:opacity-50",
            children: "Publier le coupon",
          }),
        ],
      }),
      s.jsxs("div", {
        className: "space-y-2",
        children: [
          d.length === 0 &&
            s.jsx("p", {
              className: "text-sm text-white/50",
              children: "Aucun coupon pour l'instant.",
            }),
          d.map((e) =>
            s.jsxs(
              "div",
              {
                className: "rounded-xl bg-white/[0.04] p-3",
                children: [
                  s.jsxs("div", {
                    className: "flex items-center justify-between gap-2",
                    children: [
                      s.jsx("span", {
                        className:
                          "text-xs rounded bg-[#7B2FFF]/30 px-2 py-0.5",
                        children: e.bookmaker,
                      }),
                      s.jsxs("span", {
                        className: "text-[10px] text-white/40",
                        children: [
                          e.author_name,
                          " · ",
                          new Date(e.created_at).toLocaleString("fr-FR"),
                        ],
                      }),
                    ],
                  }),
                  s.jsxs("div", {
                    className: "mt-2 flex items-center gap-2",
                    children: [
                      s.jsx("code", {
                        className: "flex-1 font-mono text-base font-bold",
                        children: e.code,
                      }),
                      s.jsx("button", {
                        "aria-label": "Copier",
                        onClick: () => {
                          (navigator.clipboard.writeText(e.code),
                            k.success("Code copié"));
                        },
                        className: "text-white/60",
                        children: s.jsx(S, { size: 16 }),
                      }),
                      t?.id === e.user_id &&
                        s.jsx("button", {
                          "aria-label": "Supprimer",
                          onClick: () => h(e.id),
                          className: "text-[#ff5577]",
                          children: s.jsx(C, { size: 16 }),
                        }),
                    ],
                  }),
                  e.description &&
                    s.jsx("p", {
                      className: "mt-1 text-xs text-white/60",
                      children: e.description,
                    }),
                ],
              },
              e.id,
            ),
          ),
        ],
      }),
    ],
  });
}
export { I as component };
