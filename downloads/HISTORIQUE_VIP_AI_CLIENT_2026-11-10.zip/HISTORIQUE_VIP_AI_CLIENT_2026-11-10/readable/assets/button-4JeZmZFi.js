import { c as De, r as C, j as ae, Q as Ue } from "./index-C5ThNCN-.js";
const Ye = [
    [
      "path",
      {
        d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
        key: "v9h5vc",
      },
    ],
    ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
    [
      "path",
      {
        d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
        key: "3uifl3",
      },
    ],
    ["path", { d: "M8 16H3v5", key: "1cv678" }],
  ],
  Ko = De("refresh-cw", Ye);
function ye(e, t) {
  if (typeof e == "function") return e(t);
  e != null && (e.current = t);
}
function qe(...e) {
  return (t) => {
    let o = !1;
    const r = e.map((n) => {
      const s = ye(n, t);
      return (!o && typeof s == "function" && (o = !0), s);
    });
    if (o)
      return () => {
        for (let n = 0; n < r.length; n++) {
          const s = r[n];
          typeof s == "function" ? s() : ye(e[n], null);
        }
      };
  };
}
var He = Symbol.for("react.lazy"),
  K = Ue[" use ".trim().toString()];
function Xe(e) {
  return typeof e == "object" && e !== null && "then" in e;
}
function Re(e) {
  return (
    e != null &&
    typeof e == "object" &&
    "$$typeof" in e &&
    e.$$typeof === He &&
    "_payload" in e &&
    Xe(e._payload)
  );
}
function Ze(e) {
  const t = Ke(e),
    o = C.forwardRef((r, n) => {
      let { children: s, ...a } = r;
      Re(s) && typeof K == "function" && (s = K(s._payload));
      const u = C.Children.toArray(s),
        c = u.find(eo);
      if (c) {
        const p = c.props.children,
          b = u.map((g) =>
            g === c
              ? C.Children.count(p) > 1
                ? C.Children.only(null)
                : C.isValidElement(p)
                  ? p.props.children
                  : null
              : g,
          );
        return ae.jsx(t, {
          ...a,
          ref: n,
          children: C.isValidElement(p) ? C.cloneElement(p, void 0, b) : null,
        });
      }
      return ae.jsx(t, { ...a, ref: n, children: s });
    });
  return ((o.displayName = `${e}.Slot`), o);
}
var Je = Ze("Slot");
function Ke(e) {
  const t = C.forwardRef((o, r) => {
    let { children: n, ...s } = o;
    if (
      (Re(n) && typeof K == "function" && (n = K(n._payload)),
      C.isValidElement(n))
    ) {
      const a = ro(n),
        u = oo(s, n.props);
      return (
        n.type !== C.Fragment && (u.ref = r ? qe(r, a) : a),
        C.cloneElement(n, u)
      );
    }
    return C.Children.count(n) > 1 ? C.Children.only(null) : null;
  });
  return ((t.displayName = `${e}.SlotClone`), t);
}
var Qe = Symbol("radix.slottable");
function eo(e) {
  return (
    C.isValidElement(e) &&
    typeof e.type == "function" &&
    "__radixId" in e.type &&
    e.type.__radixId === Qe
  );
}
function oo(e, t) {
  const o = { ...t };
  for (const r in t) {
    const n = e[r],
      s = t[r];
    /^on[A-Z]/.test(r)
      ? n && s
        ? (o[r] = (...u) => {
            const c = s(...u);
            return (n(...u), c);
          })
        : n && (o[r] = n)
      : r === "style"
        ? (o[r] = { ...n, ...s })
        : r === "className" && (o[r] = [n, s].filter(Boolean).join(" "));
  }
  return { ...e, ...o };
}
function ro(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get,
    o = t && "isReactWarning" in t && t.isReactWarning;
  return o
    ? e.ref
    : ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
      (o = t && "isReactWarning" in t && t.isReactWarning),
      o ? e.props.ref : e.props.ref || e.ref);
}
function Ie(e) {
  var t,
    o,
    r = "";
  if (typeof e == "string" || typeof e == "number") r += e;
  else if (typeof e == "object")
    if (Array.isArray(e)) {
      var n = e.length;
      for (t = 0; t < n; t++)
        e[t] && (o = Ie(e[t])) && (r && (r += " "), (r += o));
    } else for (o in e) e[o] && (r && (r += " "), (r += o));
  return r;
}
function Pe() {
  for (var e, t, o = 0, r = "", n = arguments.length; o < n; o++)
    (e = arguments[o]) && (t = Ie(e)) && (r && (r += " "), (r += t));
  return r;
}
const xe = (e) => (typeof e == "boolean" ? `${e}` : e === 0 ? "0" : e),
  we = Pe,
  to = (e, t) => (o) => {
    var r;
    if (t?.variants == null) return we(e, o?.class, o?.className);
    const { variants: n, defaultVariants: s } = t,
      a = Object.keys(n).map((p) => {
        const b = o?.[p],
          g = s?.[p];
        if (b === null) return null;
        const x = xe(b) || xe(g);
        return n[p][x];
      }),
      u =
        o &&
        Object.entries(o).reduce((p, b) => {
          let [g, x] = b;
          return (x === void 0 || (p[g] = x), p);
        }, {}),
      c =
        t == null || (r = t.compoundVariants) === null || r === void 0
          ? void 0
          : r.reduce((p, b) => {
              let { class: g, className: x, ...R } = b;
              return Object.entries(R).every((I) => {
                let [z, w] = I;
                return Array.isArray(w)
                  ? w.includes({ ...s, ...u }[z])
                  : { ...s, ...u }[z] === w;
              })
                ? [...p, g, x]
                : p;
            }, []);
    return we(e, a, c, o?.class, o?.className);
  },
  no = (e, t) => {
    const o = new Array(e.length + t.length);
    for (let r = 0; r < e.length; r++) o[r] = e[r];
    for (let r = 0; r < t.length; r++) o[e.length + r] = t[r];
    return o;
  },
  so = (e, t) => ({ classGroupId: e, validator: t }),
  Me = (e = new Map(), t = null, o) => ({
    nextPart: e,
    validators: t,
    classGroupId: o,
  }),
  Q = "-",
  ve = [],
  ao = "arbitrary..",
  io = (e) => {
    const t = co(e),
      { conflictingClassGroups: o, conflictingClassGroupModifiers: r } = e;
    return {
      getClassGroupId: (a) => {
        if (a.startsWith("[") && a.endsWith("]")) return lo(a);
        const u = a.split(Q),
          c = u[0] === "" && u.length > 1 ? 1 : 0;
        return je(u, c, t);
      },
      getConflictingClassGroupIds: (a, u) => {
        if (u) {
          const c = r[a],
            p = o[a];
          return c ? (p ? no(p, c) : c) : p || ve;
        }
        return o[a] || ve;
      },
    };
  },
  je = (e, t, o) => {
    if (e.length - t === 0) return o.classGroupId;
    const n = e[t],
      s = o.nextPart.get(n);
    if (s) {
      const p = je(e, t + 1, s);
      if (p) return p;
    }
    const a = o.validators;
    if (a === null) return;
    const u = t === 0 ? e.join(Q) : e.slice(t).join(Q),
      c = a.length;
    for (let p = 0; p < c; p++) {
      const b = a[p];
      if (b.validator(u)) return b.classGroupId;
    }
  },
  lo = (e) =>
    e.slice(1, -1).indexOf(":") === -1
      ? void 0
      : (() => {
          const t = e.slice(1, -1),
            o = t.indexOf(":"),
            r = t.slice(0, o);
          return r ? ao + r : void 0;
        })(),
  co = (e) => {
    const { theme: t, classGroups: o } = e;
    return mo(o, t);
  },
  mo = (e, t) => {
    const o = Me();
    for (const r in e) {
      const n = e[r];
      le(n, o, r, t);
    }
    return o;
  },
  le = (e, t, o, r) => {
    const n = e.length;
    for (let s = 0; s < n; s++) {
      const a = e[s];
      uo(a, t, o, r);
    }
  },
  uo = (e, t, o, r) => {
    if (typeof e == "string") {
      po(e, t, o);
      return;
    }
    if (typeof e == "function") {
      fo(e, t, o, r);
      return;
    }
    bo(e, t, o, r);
  },
  po = (e, t, o) => {
    const r = e === "" ? t : Ee(t, e);
    r.classGroupId = o;
  },
  fo = (e, t, o, r) => {
    if (go(e)) {
      le(e(r), t, o, r);
      return;
    }
    (t.validators === null && (t.validators = []), t.validators.push(so(o, e)));
  },
  bo = (e, t, o, r) => {
    const n = Object.entries(e),
      s = n.length;
    for (let a = 0; a < s; a++) {
      const [u, c] = n[a];
      le(c, Ee(t, u), o, r);
    }
  },
  Ee = (e, t) => {
    let o = e;
    const r = t.split(Q),
      n = r.length;
    for (let s = 0; s < n; s++) {
      const a = r[s];
      let u = o.nextPart.get(a);
      (u || ((u = Me()), o.nextPart.set(a, u)), (o = u));
    }
    return o;
  },
  go = (e) => "isThemeGetter" in e && e.isThemeGetter === !0,
  ho = (e) => {
    if (e < 1) return { get: () => {}, set: () => {} };
    let t = 0,
      o = Object.create(null),
      r = Object.create(null);
    const n = (s, a) => {
      ((o[s] = a), t++, t > e && ((t = 0), (r = o), (o = Object.create(null))));
    };
    return {
      get(s) {
        let a = o[s];
        if (a !== void 0) return a;
        if ((a = r[s]) !== void 0) return (n(s, a), a);
      },
      set(s, a) {
        s in o ? (o[s] = a) : n(s, a);
      },
    };
  },
  ie = "!",
  ke = ":",
  yo = [],
  Ce = (e, t, o, r, n) => ({
    modifiers: e,
    hasImportantModifier: t,
    baseClassName: o,
    maybePostfixModifierPosition: r,
    isExternal: n,
  }),
  xo = (e) => {
    const { prefix: t, experimentalParseClassName: o } = e;
    let r = (n) => {
      const s = [];
      let a = 0,
        u = 0,
        c = 0,
        p;
      const b = n.length;
      for (let z = 0; z < b; z++) {
        const w = n[z];
        if (a === 0 && u === 0) {
          if (w === ke) {
            (s.push(n.slice(c, z)), (c = z + 1));
            continue;
          }
          if (w === "/") {
            p = z;
            continue;
          }
        }
        w === "[" ? a++ : w === "]" ? a-- : w === "(" ? u++ : w === ")" && u--;
      }
      const g = s.length === 0 ? n : n.slice(c);
      let x = g,
        R = !1;
      g.endsWith(ie)
        ? ((x = g.slice(0, -1)), (R = !0))
        : g.startsWith(ie) && ((x = g.slice(1)), (R = !0));
      const I = p && p > c ? p - c : void 0;
      return Ce(s, R, x, I);
    };
    if (t) {
      const n = t + ke,
        s = r;
      r = (a) =>
        a.startsWith(n) ? s(a.slice(n.length)) : Ce(yo, !1, a, void 0, !0);
    }
    if (o) {
      const n = r;
      r = (s) => o({ className: s, parseClassName: n });
    }
    return r;
  },
  wo = (e) => {
    const t = new Map();
    return (
      e.orderSensitiveModifiers.forEach((o, r) => {
        t.set(o, 1e6 + r);
      }),
      (o) => {
        const r = [];
        let n = [];
        for (let s = 0; s < o.length; s++) {
          const a = o[s],
            u = a[0] === "[",
            c = t.has(a);
          u || c
            ? (n.length > 0 && (n.sort(), r.push(...n), (n = [])), r.push(a))
            : n.push(a);
        }
        return (n.length > 0 && (n.sort(), r.push(...n)), r);
      }
    );
  },
  vo = (e) => ({
    cache: ho(e.cacheSize),
    parseClassName: xo(e),
    sortModifiers: wo(e),
    ...io(e),
  }),
  ko = /\s+/,
  Co = (e, t) => {
    const {
        parseClassName: o,
        getClassGroupId: r,
        getConflictingClassGroupIds: n,
        sortModifiers: s,
      } = t,
      a = [],
      u = e.trim().split(ko);
    let c = "";
    for (let p = u.length - 1; p >= 0; p -= 1) {
      const b = u[p],
        {
          isExternal: g,
          modifiers: x,
          hasImportantModifier: R,
          baseClassName: I,
          maybePostfixModifierPosition: z,
        } = o(b);
      if (g) {
        c = b + (c.length > 0 ? " " + c : c);
        continue;
      }
      let w = !!z,
        T = r(w ? I.substring(0, z) : I);
      if (!T) {
        if (!w) {
          c = b + (c.length > 0 ? " " + c : c);
          continue;
        }
        if (((T = r(I)), !T)) {
          c = b + (c.length > 0 ? " " + c : c);
          continue;
        }
        w = !1;
      }
      const D = x.length === 0 ? "" : x.length === 1 ? x[0] : s(x).join(":"),
        B = R ? D + ie : D,
        G = B + T;
      if (a.indexOf(G) > -1) continue;
      a.push(G);
      const L = n(T, w);
      for (let N = 0; N < L.length; ++N) {
        const F = L[N];
        a.push(B + F);
      }
      c = b + (c.length > 0 ? " " + c : c);
    }
    return c;
  },
  zo = (...e) => {
    let t = 0,
      o,
      r,
      n = "";
    for (; t < e.length;)
      (o = e[t++]) && (r = Te(o)) && (n && (n += " "), (n += r));
    return n;
  },
  Te = (e) => {
    if (typeof e == "string") return e;
    let t,
      o = "";
    for (let r = 0; r < e.length; r++)
      e[r] && (t = Te(e[r])) && (o && (o += " "), (o += t));
    return o;
  },
  So = (e, ...t) => {
    let o, r, n, s;
    const a = (c) => {
        const p = t.reduce((b, g) => g(b), e());
        return (
          (o = vo(p)),
          (r = o.cache.get),
          (n = o.cache.set),
          (s = u),
          u(c)
        );
      },
      u = (c) => {
        const p = r(c);
        if (p) return p;
        const b = Co(c, o);
        return (n(c, b), b);
      };
    return ((s = a), (...c) => s(zo(...c)));
  },
  Ao = [],
  h = (e) => {
    const t = (o) => o[e] || Ao;
    return ((t.isThemeGetter = !0), t);
  },
  Ne = /^\[(?:(\w[\w-]*):)?(.+)\]$/i,
  Ve = /^\((?:(\w[\w-]*):)?(.+)\)$/i,
  Ro = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,
  Io = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
  Po =
    /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
  Mo = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
  jo = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
  Eo =
    /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
  M = (e) => Ro.test(e),
  f = (e) => !!e && !Number.isNaN(Number(e)),
  j = (e) => !!e && Number.isInteger(Number(e)),
  se = (e) => e.endsWith("%") && f(e.slice(0, -1)),
  P = (e) => Io.test(e),
  Oe = () => !0,
  To = (e) => Po.test(e) && !Mo.test(e),
  ce = () => !1,
  No = (e) => jo.test(e),
  Vo = (e) => Eo.test(e),
  Oo = (e) => !i(e) && !l(e),
  _o = (e) => E(e, Le, ce),
  i = (e) => Ne.test(e),
  O = (e) => E(e, We, To),
  ze = (e) => E(e, Uo, f),
  Go = (e) => E(e, Fe, Oe),
  Lo = (e) => E(e, Be, ce),
  Se = (e) => E(e, _e, ce),
  Wo = (e) => E(e, Ge, Vo),
  Z = (e) => E(e, $e, No),
  l = (e) => Ve.test(e),
  $ = (e) => _(e, We),
  Bo = (e) => _(e, Be),
  Ae = (e) => _(e, _e),
  Fo = (e) => _(e, Le),
  $o = (e) => _(e, Ge),
  J = (e) => _(e, $e, !0),
  Do = (e) => _(e, Fe, !0),
  E = (e, t, o) => {
    const r = Ne.exec(e);
    return r ? (r[1] ? t(r[1]) : o(r[2])) : !1;
  },
  _ = (e, t, o = !1) => {
    const r = Ve.exec(e);
    return r ? (r[1] ? t(r[1]) : o) : !1;
  },
  _e = (e) => e === "position" || e === "percentage",
  Ge = (e) => e === "image" || e === "url",
  Le = (e) => e === "length" || e === "size" || e === "bg-size",
  We = (e) => e === "length",
  Uo = (e) => e === "number",
  Be = (e) => e === "family-name",
  Fe = (e) => e === "number" || e === "weight",
  $e = (e) => e === "shadow",
  Yo = () => {
    const e = h("color"),
      t = h("font"),
      o = h("text"),
      r = h("font-weight"),
      n = h("tracking"),
      s = h("leading"),
      a = h("breakpoint"),
      u = h("container"),
      c = h("spacing"),
      p = h("radius"),
      b = h("shadow"),
      g = h("inset-shadow"),
      x = h("text-shadow"),
      R = h("drop-shadow"),
      I = h("blur"),
      z = h("perspective"),
      w = h("aspect"),
      T = h("ease"),
      D = h("animate"),
      B = () => [
        "auto",
        "avoid",
        "all",
        "avoid-page",
        "page",
        "left",
        "right",
        "column",
      ],
      G = () => [
        "center",
        "top",
        "bottom",
        "left",
        "right",
        "top-left",
        "left-top",
        "top-right",
        "right-top",
        "bottom-right",
        "right-bottom",
        "bottom-left",
        "left-bottom",
      ],
      L = () => [...G(), l, i],
      N = () => ["auto", "hidden", "clip", "visible", "scroll"],
      F = () => ["auto", "contain", "none"],
      d = () => [l, i, c],
      S = () => [M, "full", "auto", ...d()],
      de = () => [j, "none", "subgrid", l, i],
      me = () => ["auto", { span: ["full", j, l, i] }, j, l, i],
      U = () => [j, "auto", l, i],
      ue = () => ["auto", "min", "max", "fr", l, i],
      ee = () => [
        "start",
        "end",
        "center",
        "between",
        "around",
        "evenly",
        "stretch",
        "baseline",
        "center-safe",
        "end-safe",
      ],
      W = () => [
        "start",
        "end",
        "center",
        "stretch",
        "center-safe",
        "end-safe",
      ],
      A = () => ["auto", ...d()],
      V = () => [
        M,
        "auto",
        "full",
        "dvw",
        "dvh",
        "lvw",
        "lvh",
        "svw",
        "svh",
        "min",
        "max",
        "fit",
        ...d(),
      ],
      oe = () => [
        M,
        "screen",
        "full",
        "dvw",
        "lvw",
        "svw",
        "min",
        "max",
        "fit",
        ...d(),
      ],
      re = () => [
        M,
        "screen",
        "full",
        "lh",
        "dvh",
        "lvh",
        "svh",
        "min",
        "max",
        "fit",
        ...d(),
      ],
      m = () => [e, l, i],
      pe = () => [...G(), Ae, Se, { position: [l, i] }],
      fe = () => ["no-repeat", { repeat: ["", "x", "y", "space", "round"] }],
      be = () => ["auto", "cover", "contain", Fo, _o, { size: [l, i] }],
      te = () => [se, $, O],
      v = () => ["", "none", "full", p, l, i],
      k = () => ["", f, $, O],
      Y = () => ["solid", "dashed", "dotted", "double"],
      ge = () => [
        "normal",
        "multiply",
        "screen",
        "overlay",
        "darken",
        "lighten",
        "color-dodge",
        "color-burn",
        "hard-light",
        "soft-light",
        "difference",
        "exclusion",
        "hue",
        "saturation",
        "color",
        "luminosity",
      ],
      y = () => [f, se, Ae, Se],
      he = () => ["", "none", I, l, i],
      q = () => ["none", f, l, i],
      H = () => ["none", f, l, i],
      ne = () => [f, l, i],
      X = () => [M, "full", ...d()];
    return {
      cacheSize: 500,
      theme: {
        animate: ["spin", "ping", "pulse", "bounce"],
        aspect: ["video"],
        blur: [P],
        breakpoint: [P],
        color: [Oe],
        container: [P],
        "drop-shadow": [P],
        ease: ["in", "out", "in-out"],
        font: [Oo],
        "font-weight": [
          "thin",
          "extralight",
          "light",
          "normal",
          "medium",
          "semibold",
          "bold",
          "extrabold",
          "black",
        ],
        "inset-shadow": [P],
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
        perspective: [
          "dramatic",
          "near",
          "normal",
          "midrange",
          "distant",
          "none",
        ],
        radius: [P],
        shadow: [P],
        spacing: ["px", f],
        text: [P],
        "text-shadow": [P],
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"],
      },
      classGroups: {
        aspect: [{ aspect: ["auto", "square", M, i, l, w] }],
        container: ["container"],
        columns: [{ columns: [f, i, l, u] }],
        "break-after": [{ "break-after": B() }],
        "break-before": [{ "break-before": B() }],
        "break-inside": [
          { "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"] },
        ],
        "box-decoration": [{ "box-decoration": ["slice", "clone"] }],
        box: [{ box: ["border", "content"] }],
        display: [
          "block",
          "inline-block",
          "inline",
          "flex",
          "inline-flex",
          "table",
          "inline-table",
          "table-caption",
          "table-cell",
          "table-column",
          "table-column-group",
          "table-footer-group",
          "table-header-group",
          "table-row-group",
          "table-row",
          "flow-root",
          "grid",
          "inline-grid",
          "contents",
          "list-item",
          "hidden",
        ],
        sr: ["sr-only", "not-sr-only"],
        float: [{ float: ["right", "left", "none", "start", "end"] }],
        clear: [{ clear: ["left", "right", "both", "none", "start", "end"] }],
        isolation: ["isolate", "isolation-auto"],
        "object-fit": [
          { object: ["contain", "cover", "fill", "none", "scale-down"] },
        ],
        "object-position": [{ object: L() }],
        overflow: [{ overflow: N() }],
        "overflow-x": [{ "overflow-x": N() }],
        "overflow-y": [{ "overflow-y": N() }],
        overscroll: [{ overscroll: F() }],
        "overscroll-x": [{ "overscroll-x": F() }],
        "overscroll-y": [{ "overscroll-y": F() }],
        position: ["static", "fixed", "absolute", "relative", "sticky"],
        inset: [{ inset: S() }],
        "inset-x": [{ "inset-x": S() }],
        "inset-y": [{ "inset-y": S() }],
        start: [{ "inset-s": S(), start: S() }],
        end: [{ "inset-e": S(), end: S() }],
        "inset-bs": [{ "inset-bs": S() }],
        "inset-be": [{ "inset-be": S() }],
        top: [{ top: S() }],
        right: [{ right: S() }],
        bottom: [{ bottom: S() }],
        left: [{ left: S() }],
        visibility: ["visible", "invisible", "collapse"],
        z: [{ z: [j, "auto", l, i] }],
        basis: [{ basis: [M, "full", "auto", u, ...d()] }],
        "flex-direction": [
          { flex: ["row", "row-reverse", "col", "col-reverse"] },
        ],
        "flex-wrap": [{ flex: ["nowrap", "wrap", "wrap-reverse"] }],
        flex: [{ flex: [f, M, "auto", "initial", "none", i] }],
        grow: [{ grow: ["", f, l, i] }],
        shrink: [{ shrink: ["", f, l, i] }],
        order: [{ order: [j, "first", "last", "none", l, i] }],
        "grid-cols": [{ "grid-cols": de() }],
        "col-start-end": [{ col: me() }],
        "col-start": [{ "col-start": U() }],
        "col-end": [{ "col-end": U() }],
        "grid-rows": [{ "grid-rows": de() }],
        "row-start-end": [{ row: me() }],
        "row-start": [{ "row-start": U() }],
        "row-end": [{ "row-end": U() }],
        "grid-flow": [
          { "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"] },
        ],
        "auto-cols": [{ "auto-cols": ue() }],
        "auto-rows": [{ "auto-rows": ue() }],
        gap: [{ gap: d() }],
        "gap-x": [{ "gap-x": d() }],
        "gap-y": [{ "gap-y": d() }],
        "justify-content": [{ justify: [...ee(), "normal"] }],
        "justify-items": [{ "justify-items": [...W(), "normal"] }],
        "justify-self": [{ "justify-self": ["auto", ...W()] }],
        "align-content": [{ content: ["normal", ...ee()] }],
        "align-items": [{ items: [...W(), { baseline: ["", "last"] }] }],
        "align-self": [{ self: ["auto", ...W(), { baseline: ["", "last"] }] }],
        "place-content": [{ "place-content": ee() }],
        "place-items": [{ "place-items": [...W(), "baseline"] }],
        "place-self": [{ "place-self": ["auto", ...W()] }],
        p: [{ p: d() }],
        px: [{ px: d() }],
        py: [{ py: d() }],
        ps: [{ ps: d() }],
        pe: [{ pe: d() }],
        pbs: [{ pbs: d() }],
        pbe: [{ pbe: d() }],
        pt: [{ pt: d() }],
        pr: [{ pr: d() }],
        pb: [{ pb: d() }],
        pl: [{ pl: d() }],
        m: [{ m: A() }],
        mx: [{ mx: A() }],
        my: [{ my: A() }],
        ms: [{ ms: A() }],
        me: [{ me: A() }],
        mbs: [{ mbs: A() }],
        mbe: [{ mbe: A() }],
        mt: [{ mt: A() }],
        mr: [{ mr: A() }],
        mb: [{ mb: A() }],
        ml: [{ ml: A() }],
        "space-x": [{ "space-x": d() }],
        "space-x-reverse": ["space-x-reverse"],
        "space-y": [{ "space-y": d() }],
        "space-y-reverse": ["space-y-reverse"],
        size: [{ size: V() }],
        "inline-size": [{ inline: ["auto", ...oe()] }],
        "min-inline-size": [{ "min-inline": ["auto", ...oe()] }],
        "max-inline-size": [{ "max-inline": ["none", ...oe()] }],
        "block-size": [{ block: ["auto", ...re()] }],
        "min-block-size": [{ "min-block": ["auto", ...re()] }],
        "max-block-size": [{ "max-block": ["none", ...re()] }],
        w: [{ w: [u, "screen", ...V()] }],
        "min-w": [{ "min-w": [u, "screen", "none", ...V()] }],
        "max-w": [
          { "max-w": [u, "screen", "none", "prose", { screen: [a] }, ...V()] },
        ],
        h: [{ h: ["screen", "lh", ...V()] }],
        "min-h": [{ "min-h": ["screen", "lh", "none", ...V()] }],
        "max-h": [{ "max-h": ["screen", "lh", ...V()] }],
        "font-size": [{ text: ["base", o, $, O] }],
        "font-smoothing": ["antialiased", "subpixel-antialiased"],
        "font-style": ["italic", "not-italic"],
        "font-weight": [{ font: [r, Do, Go] }],
        "font-stretch": [
          {
            "font-stretch": [
              "ultra-condensed",
              "extra-condensed",
              "condensed",
              "semi-condensed",
              "normal",
              "semi-expanded",
              "expanded",
              "extra-expanded",
              "ultra-expanded",
              se,
              i,
            ],
          },
        ],
        "font-family": [{ font: [Bo, Lo, t] }],
        "font-features": [{ "font-features": [i] }],
        "fvn-normal": ["normal-nums"],
        "fvn-ordinal": ["ordinal"],
        "fvn-slashed-zero": ["slashed-zero"],
        "fvn-figure": ["lining-nums", "oldstyle-nums"],
        "fvn-spacing": ["proportional-nums", "tabular-nums"],
        "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
        tracking: [{ tracking: [n, l, i] }],
        "line-clamp": [{ "line-clamp": [f, "none", l, ze] }],
        leading: [{ leading: [s, ...d()] }],
        "list-image": [{ "list-image": ["none", l, i] }],
        "list-style-position": [{ list: ["inside", "outside"] }],
        "list-style-type": [{ list: ["disc", "decimal", "none", l, i] }],
        "text-alignment": [
          { text: ["left", "center", "right", "justify", "start", "end"] },
        ],
        "placeholder-color": [{ placeholder: m() }],
        "text-color": [{ text: m() }],
        "text-decoration": [
          "underline",
          "overline",
          "line-through",
          "no-underline",
        ],
        "text-decoration-style": [{ decoration: [...Y(), "wavy"] }],
        "text-decoration-thickness": [
          { decoration: [f, "from-font", "auto", l, O] },
        ],
        "text-decoration-color": [{ decoration: m() }],
        "underline-offset": [{ "underline-offset": [f, "auto", l, i] }],
        "text-transform": [
          "uppercase",
          "lowercase",
          "capitalize",
          "normal-case",
        ],
        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
        "text-wrap": [{ text: ["wrap", "nowrap", "balance", "pretty"] }],
        indent: [{ indent: d() }],
        "vertical-align": [
          {
            align: [
              "baseline",
              "top",
              "middle",
              "bottom",
              "text-top",
              "text-bottom",
              "sub",
              "super",
              l,
              i,
            ],
          },
        ],
        whitespace: [
          {
            whitespace: [
              "normal",
              "nowrap",
              "pre",
              "pre-line",
              "pre-wrap",
              "break-spaces",
            ],
          },
        ],
        break: [{ break: ["normal", "words", "all", "keep"] }],
        wrap: [{ wrap: ["break-word", "anywhere", "normal"] }],
        hyphens: [{ hyphens: ["none", "manual", "auto"] }],
        content: [{ content: ["none", l, i] }],
        "bg-attachment": [{ bg: ["fixed", "local", "scroll"] }],
        "bg-clip": [{ "bg-clip": ["border", "padding", "content", "text"] }],
        "bg-origin": [{ "bg-origin": ["border", "padding", "content"] }],
        "bg-position": [{ bg: pe() }],
        "bg-repeat": [{ bg: fe() }],
        "bg-size": [{ bg: be() }],
        "bg-image": [
          {
            bg: [
              "none",
              {
                linear: [
                  { to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"] },
                  j,
                  l,
                  i,
                ],
                radial: ["", l, i],
                conic: [j, l, i],
              },
              $o,
              Wo,
            ],
          },
        ],
        "bg-color": [{ bg: m() }],
        "gradient-from-pos": [{ from: te() }],
        "gradient-via-pos": [{ via: te() }],
        "gradient-to-pos": [{ to: te() }],
        "gradient-from": [{ from: m() }],
        "gradient-via": [{ via: m() }],
        "gradient-to": [{ to: m() }],
        rounded: [{ rounded: v() }],
        "rounded-s": [{ "rounded-s": v() }],
        "rounded-e": [{ "rounded-e": v() }],
        "rounded-t": [{ "rounded-t": v() }],
        "rounded-r": [{ "rounded-r": v() }],
        "rounded-b": [{ "rounded-b": v() }],
        "rounded-l": [{ "rounded-l": v() }],
        "rounded-ss": [{ "rounded-ss": v() }],
        "rounded-se": [{ "rounded-se": v() }],
        "rounded-ee": [{ "rounded-ee": v() }],
        "rounded-es": [{ "rounded-es": v() }],
        "rounded-tl": [{ "rounded-tl": v() }],
        "rounded-tr": [{ "rounded-tr": v() }],
        "rounded-br": [{ "rounded-br": v() }],
        "rounded-bl": [{ "rounded-bl": v() }],
        "border-w": [{ border: k() }],
        "border-w-x": [{ "border-x": k() }],
        "border-w-y": [{ "border-y": k() }],
        "border-w-s": [{ "border-s": k() }],
        "border-w-e": [{ "border-e": k() }],
        "border-w-bs": [{ "border-bs": k() }],
        "border-w-be": [{ "border-be": k() }],
        "border-w-t": [{ "border-t": k() }],
        "border-w-r": [{ "border-r": k() }],
        "border-w-b": [{ "border-b": k() }],
        "border-w-l": [{ "border-l": k() }],
        "divide-x": [{ "divide-x": k() }],
        "divide-x-reverse": ["divide-x-reverse"],
        "divide-y": [{ "divide-y": k() }],
        "divide-y-reverse": ["divide-y-reverse"],
        "border-style": [{ border: [...Y(), "hidden", "none"] }],
        "divide-style": [{ divide: [...Y(), "hidden", "none"] }],
        "border-color": [{ border: m() }],
        "border-color-x": [{ "border-x": m() }],
        "border-color-y": [{ "border-y": m() }],
        "border-color-s": [{ "border-s": m() }],
        "border-color-e": [{ "border-e": m() }],
        "border-color-bs": [{ "border-bs": m() }],
        "border-color-be": [{ "border-be": m() }],
        "border-color-t": [{ "border-t": m() }],
        "border-color-r": [{ "border-r": m() }],
        "border-color-b": [{ "border-b": m() }],
        "border-color-l": [{ "border-l": m() }],
        "divide-color": [{ divide: m() }],
        "outline-style": [{ outline: [...Y(), "none", "hidden"] }],
        "outline-offset": [{ "outline-offset": [f, l, i] }],
        "outline-w": [{ outline: ["", f, $, O] }],
        "outline-color": [{ outline: m() }],
        shadow: [{ shadow: ["", "none", b, J, Z] }],
        "shadow-color": [{ shadow: m() }],
        "inset-shadow": [{ "inset-shadow": ["none", g, J, Z] }],
        "inset-shadow-color": [{ "inset-shadow": m() }],
        "ring-w": [{ ring: k() }],
        "ring-w-inset": ["ring-inset"],
        "ring-color": [{ ring: m() }],
        "ring-offset-w": [{ "ring-offset": [f, O] }],
        "ring-offset-color": [{ "ring-offset": m() }],
        "inset-ring-w": [{ "inset-ring": k() }],
        "inset-ring-color": [{ "inset-ring": m() }],
        "text-shadow": [{ "text-shadow": ["none", x, J, Z] }],
        "text-shadow-color": [{ "text-shadow": m() }],
        opacity: [{ opacity: [f, l, i] }],
        "mix-blend": [
          { "mix-blend": [...ge(), "plus-darker", "plus-lighter"] },
        ],
        "bg-blend": [{ "bg-blend": ge() }],
        "mask-clip": [
          {
            "mask-clip": [
              "border",
              "padding",
              "content",
              "fill",
              "stroke",
              "view",
            ],
          },
          "mask-no-clip",
        ],
        "mask-composite": [
          { mask: ["add", "subtract", "intersect", "exclude"] },
        ],
        "mask-image-linear-pos": [{ "mask-linear": [f] }],
        "mask-image-linear-from-pos": [{ "mask-linear-from": y() }],
        "mask-image-linear-to-pos": [{ "mask-linear-to": y() }],
        "mask-image-linear-from-color": [{ "mask-linear-from": m() }],
        "mask-image-linear-to-color": [{ "mask-linear-to": m() }],
        "mask-image-t-from-pos": [{ "mask-t-from": y() }],
        "mask-image-t-to-pos": [{ "mask-t-to": y() }],
        "mask-image-t-from-color": [{ "mask-t-from": m() }],
        "mask-image-t-to-color": [{ "mask-t-to": m() }],
        "mask-image-r-from-pos": [{ "mask-r-from": y() }],
        "mask-image-r-to-pos": [{ "mask-r-to": y() }],
        "mask-image-r-from-color": [{ "mask-r-from": m() }],
        "mask-image-r-to-color": [{ "mask-r-to": m() }],
        "mask-image-b-from-pos": [{ "mask-b-from": y() }],
        "mask-image-b-to-pos": [{ "mask-b-to": y() }],
        "mask-image-b-from-color": [{ "mask-b-from": m() }],
        "mask-image-b-to-color": [{ "mask-b-to": m() }],
        "mask-image-l-from-pos": [{ "mask-l-from": y() }],
        "mask-image-l-to-pos": [{ "mask-l-to": y() }],
        "mask-image-l-from-color": [{ "mask-l-from": m() }],
        "mask-image-l-to-color": [{ "mask-l-to": m() }],
        "mask-image-x-from-pos": [{ "mask-x-from": y() }],
        "mask-image-x-to-pos": [{ "mask-x-to": y() }],
        "mask-image-x-from-color": [{ "mask-x-from": m() }],
        "mask-image-x-to-color": [{ "mask-x-to": m() }],
        "mask-image-y-from-pos": [{ "mask-y-from": y() }],
        "mask-image-y-to-pos": [{ "mask-y-to": y() }],
        "mask-image-y-from-color": [{ "mask-y-from": m() }],
        "mask-image-y-to-color": [{ "mask-y-to": m() }],
        "mask-image-radial": [{ "mask-radial": [l, i] }],
        "mask-image-radial-from-pos": [{ "mask-radial-from": y() }],
        "mask-image-radial-to-pos": [{ "mask-radial-to": y() }],
        "mask-image-radial-from-color": [{ "mask-radial-from": m() }],
        "mask-image-radial-to-color": [{ "mask-radial-to": m() }],
        "mask-image-radial-shape": [{ "mask-radial": ["circle", "ellipse"] }],
        "mask-image-radial-size": [
          {
            "mask-radial": [
              { closest: ["side", "corner"], farthest: ["side", "corner"] },
            ],
          },
        ],
        "mask-image-radial-pos": [{ "mask-radial-at": G() }],
        "mask-image-conic-pos": [{ "mask-conic": [f] }],
        "mask-image-conic-from-pos": [{ "mask-conic-from": y() }],
        "mask-image-conic-to-pos": [{ "mask-conic-to": y() }],
        "mask-image-conic-from-color": [{ "mask-conic-from": m() }],
        "mask-image-conic-to-color": [{ "mask-conic-to": m() }],
        "mask-mode": [{ mask: ["alpha", "luminance", "match"] }],
        "mask-origin": [
          {
            "mask-origin": [
              "border",
              "padding",
              "content",
              "fill",
              "stroke",
              "view",
            ],
          },
        ],
        "mask-position": [{ mask: pe() }],
        "mask-repeat": [{ mask: fe() }],
        "mask-size": [{ mask: be() }],
        "mask-type": [{ "mask-type": ["alpha", "luminance"] }],
        "mask-image": [{ mask: ["none", l, i] }],
        filter: [{ filter: ["", "none", l, i] }],
        blur: [{ blur: he() }],
        brightness: [{ brightness: [f, l, i] }],
        contrast: [{ contrast: [f, l, i] }],
        "drop-shadow": [{ "drop-shadow": ["", "none", R, J, Z] }],
        "drop-shadow-color": [{ "drop-shadow": m() }],
        grayscale: [{ grayscale: ["", f, l, i] }],
        "hue-rotate": [{ "hue-rotate": [f, l, i] }],
        invert: [{ invert: ["", f, l, i] }],
        saturate: [{ saturate: [f, l, i] }],
        sepia: [{ sepia: ["", f, l, i] }],
        "backdrop-filter": [{ "backdrop-filter": ["", "none", l, i] }],
        "backdrop-blur": [{ "backdrop-blur": he() }],
        "backdrop-brightness": [{ "backdrop-brightness": [f, l, i] }],
        "backdrop-contrast": [{ "backdrop-contrast": [f, l, i] }],
        "backdrop-grayscale": [{ "backdrop-grayscale": ["", f, l, i] }],
        "backdrop-hue-rotate": [{ "backdrop-hue-rotate": [f, l, i] }],
        "backdrop-invert": [{ "backdrop-invert": ["", f, l, i] }],
        "backdrop-opacity": [{ "backdrop-opacity": [f, l, i] }],
        "backdrop-saturate": [{ "backdrop-saturate": [f, l, i] }],
        "backdrop-sepia": [{ "backdrop-sepia": ["", f, l, i] }],
        "border-collapse": [{ border: ["collapse", "separate"] }],
        "border-spacing": [{ "border-spacing": d() }],
        "border-spacing-x": [{ "border-spacing-x": d() }],
        "border-spacing-y": [{ "border-spacing-y": d() }],
        "table-layout": [{ table: ["auto", "fixed"] }],
        caption: [{ caption: ["top", "bottom"] }],
        transition: [
          {
            transition: [
              "",
              "all",
              "colors",
              "opacity",
              "shadow",
              "transform",
              "none",
              l,
              i,
            ],
          },
        ],
        "transition-behavior": [{ transition: ["normal", "discrete"] }],
        duration: [{ duration: [f, "initial", l, i] }],
        ease: [{ ease: ["linear", "initial", T, l, i] }],
        delay: [{ delay: [f, l, i] }],
        animate: [{ animate: ["none", D, l, i] }],
        backface: [{ backface: ["hidden", "visible"] }],
        perspective: [{ perspective: [z, l, i] }],
        "perspective-origin": [{ "perspective-origin": L() }],
        rotate: [{ rotate: q() }],
        "rotate-x": [{ "rotate-x": q() }],
        "rotate-y": [{ "rotate-y": q() }],
        "rotate-z": [{ "rotate-z": q() }],
        scale: [{ scale: H() }],
        "scale-x": [{ "scale-x": H() }],
        "scale-y": [{ "scale-y": H() }],
        "scale-z": [{ "scale-z": H() }],
        "scale-3d": ["scale-3d"],
        skew: [{ skew: ne() }],
        "skew-x": [{ "skew-x": ne() }],
        "skew-y": [{ "skew-y": ne() }],
        transform: [{ transform: [l, i, "", "none", "gpu", "cpu"] }],
        "transform-origin": [{ origin: L() }],
        "transform-style": [{ transform: ["3d", "flat"] }],
        translate: [{ translate: X() }],
        "translate-x": [{ "translate-x": X() }],
        "translate-y": [{ "translate-y": X() }],
        "translate-z": [{ "translate-z": X() }],
        "translate-none": ["translate-none"],
        accent: [{ accent: m() }],
        appearance: [{ appearance: ["none", "auto"] }],
        "caret-color": [{ caret: m() }],
        "color-scheme": [
          {
            scheme: [
              "normal",
              "dark",
              "light",
              "light-dark",
              "only-dark",
              "only-light",
            ],
          },
        ],
        cursor: [
          {
            cursor: [
              "auto",
              "default",
              "pointer",
              "wait",
              "text",
              "move",
              "help",
              "not-allowed",
              "none",
              "context-menu",
              "progress",
              "cell",
              "crosshair",
              "vertical-text",
              "alias",
              "copy",
              "no-drop",
              "grab",
              "grabbing",
              "all-scroll",
              "col-resize",
              "row-resize",
              "n-resize",
              "e-resize",
              "s-resize",
              "w-resize",
              "ne-resize",
              "nw-resize",
              "se-resize",
              "sw-resize",
              "ew-resize",
              "ns-resize",
              "nesw-resize",
              "nwse-resize",
              "zoom-in",
              "zoom-out",
              l,
              i,
            ],
          },
        ],
        "field-sizing": [{ "field-sizing": ["fixed", "content"] }],
        "pointer-events": [{ "pointer-events": ["auto", "none"] }],
        resize: [{ resize: ["none", "", "y", "x"] }],
        "scroll-behavior": [{ scroll: ["auto", "smooth"] }],
        "scroll-m": [{ "scroll-m": d() }],
        "scroll-mx": [{ "scroll-mx": d() }],
        "scroll-my": [{ "scroll-my": d() }],
        "scroll-ms": [{ "scroll-ms": d() }],
        "scroll-me": [{ "scroll-me": d() }],
        "scroll-mbs": [{ "scroll-mbs": d() }],
        "scroll-mbe": [{ "scroll-mbe": d() }],
        "scroll-mt": [{ "scroll-mt": d() }],
        "scroll-mr": [{ "scroll-mr": d() }],
        "scroll-mb": [{ "scroll-mb": d() }],
        "scroll-ml": [{ "scroll-ml": d() }],
        "scroll-p": [{ "scroll-p": d() }],
        "scroll-px": [{ "scroll-px": d() }],
        "scroll-py": [{ "scroll-py": d() }],
        "scroll-ps": [{ "scroll-ps": d() }],
        "scroll-pe": [{ "scroll-pe": d() }],
        "scroll-pbs": [{ "scroll-pbs": d() }],
        "scroll-pbe": [{ "scroll-pbe": d() }],
        "scroll-pt": [{ "scroll-pt": d() }],
        "scroll-pr": [{ "scroll-pr": d() }],
        "scroll-pb": [{ "scroll-pb": d() }],
        "scroll-pl": [{ "scroll-pl": d() }],
        "snap-align": [{ snap: ["start", "end", "center", "align-none"] }],
        "snap-stop": [{ snap: ["normal", "always"] }],
        "snap-type": [{ snap: ["none", "x", "y", "both"] }],
        "snap-strictness": [{ snap: ["mandatory", "proximity"] }],
        touch: [{ touch: ["auto", "none", "manipulation"] }],
        "touch-x": [{ "touch-pan": ["x", "left", "right"] }],
        "touch-y": [{ "touch-pan": ["y", "up", "down"] }],
        "touch-pz": ["touch-pinch-zoom"],
        select: [{ select: ["none", "text", "all", "auto"] }],
        "will-change": [
          { "will-change": ["auto", "scroll", "contents", "transform", l, i] },
        ],
        fill: [{ fill: ["none", ...m()] }],
        "stroke-w": [{ stroke: [f, $, O, ze] }],
        stroke: [{ stroke: ["none", ...m()] }],
        "forced-color-adjust": [{ "forced-color-adjust": ["auto", "none"] }],
      },
      conflictingClassGroups: {
        overflow: ["overflow-x", "overflow-y"],
        overscroll: ["overscroll-x", "overscroll-y"],
        inset: [
          "inset-x",
          "inset-y",
          "inset-bs",
          "inset-be",
          "start",
          "end",
          "top",
          "right",
          "bottom",
          "left",
        ],
        "inset-x": ["right", "left"],
        "inset-y": ["top", "bottom"],
        flex: ["basis", "grow", "shrink"],
        gap: ["gap-x", "gap-y"],
        p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
        px: ["pr", "pl"],
        py: ["pt", "pb"],
        m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
        mx: ["mr", "ml"],
        my: ["mt", "mb"],
        size: ["w", "h"],
        "font-size": ["leading"],
        "fvn-normal": [
          "fvn-ordinal",
          "fvn-slashed-zero",
          "fvn-figure",
          "fvn-spacing",
          "fvn-fraction",
        ],
        "fvn-ordinal": ["fvn-normal"],
        "fvn-slashed-zero": ["fvn-normal"],
        "fvn-figure": ["fvn-normal"],
        "fvn-spacing": ["fvn-normal"],
        "fvn-fraction": ["fvn-normal"],
        "line-clamp": ["display", "overflow"],
        rounded: [
          "rounded-s",
          "rounded-e",
          "rounded-t",
          "rounded-r",
          "rounded-b",
          "rounded-l",
          "rounded-ss",
          "rounded-se",
          "rounded-ee",
          "rounded-es",
          "rounded-tl",
          "rounded-tr",
          "rounded-br",
          "rounded-bl",
        ],
        "rounded-s": ["rounded-ss", "rounded-es"],
        "rounded-e": ["rounded-se", "rounded-ee"],
        "rounded-t": ["rounded-tl", "rounded-tr"],
        "rounded-r": ["rounded-tr", "rounded-br"],
        "rounded-b": ["rounded-br", "rounded-bl"],
        "rounded-l": ["rounded-tl", "rounded-bl"],
        "border-spacing": ["border-spacing-x", "border-spacing-y"],
        "border-w": [
          "border-w-x",
          "border-w-y",
          "border-w-s",
          "border-w-e",
          "border-w-bs",
          "border-w-be",
          "border-w-t",
          "border-w-r",
          "border-w-b",
          "border-w-l",
        ],
        "border-w-x": ["border-w-r", "border-w-l"],
        "border-w-y": ["border-w-t", "border-w-b"],
        "border-color": [
          "border-color-x",
          "border-color-y",
          "border-color-s",
          "border-color-e",
          "border-color-bs",
          "border-color-be",
          "border-color-t",
          "border-color-r",
          "border-color-b",
          "border-color-l",
        ],
        "border-color-x": ["border-color-r", "border-color-l"],
        "border-color-y": ["border-color-t", "border-color-b"],
        translate: ["translate-x", "translate-y", "translate-none"],
        "translate-none": [
          "translate",
          "translate-x",
          "translate-y",
          "translate-z",
        ],
        "scroll-m": [
          "scroll-mx",
          "scroll-my",
          "scroll-ms",
          "scroll-me",
          "scroll-mbs",
          "scroll-mbe",
          "scroll-mt",
          "scroll-mr",
          "scroll-mb",
          "scroll-ml",
        ],
        "scroll-mx": ["scroll-mr", "scroll-ml"],
        "scroll-my": ["scroll-mt", "scroll-mb"],
        "scroll-p": [
          "scroll-px",
          "scroll-py",
          "scroll-ps",
          "scroll-pe",
          "scroll-pbs",
          "scroll-pbe",
          "scroll-pt",
          "scroll-pr",
          "scroll-pb",
          "scroll-pl",
        ],
        "scroll-px": ["scroll-pr", "scroll-pl"],
        "scroll-py": ["scroll-pt", "scroll-pb"],
        touch: ["touch-x", "touch-y", "touch-pz"],
        "touch-x": ["touch"],
        "touch-y": ["touch"],
        "touch-pz": ["touch"],
      },
      conflictingClassGroupModifiers: { "font-size": ["leading"] },
      orderSensitiveModifiers: [
        "*",
        "**",
        "after",
        "backdrop",
        "before",
        "details-content",
        "file",
        "first-letter",
        "first-line",
        "marker",
        "placeholder",
        "selection",
      ],
    };
  },
  qo = So(Yo);
function Ho(...e) {
  return qo(Pe(e));
}
const Xo = to(
    "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
    {
      variants: {
        variant: {
          default:
            "bg-primary text-primary-foreground shadow hover:bg-primary/90",
          destructive:
            "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
          outline:
            "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
          secondary:
            "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
          ghost: "hover:bg-accent hover:text-accent-foreground",
          link: "text-primary underline-offset-4 hover:underline",
        },
        size: {
          default: "h-9 px-4 py-2",
          sm: "h-8 rounded-md px-3 text-xs",
          lg: "h-10 rounded-md px-8",
          icon: "h-9 w-9",
        },
      },
      defaultVariants: { variant: "default", size: "default" },
    },
  ),
  Zo = C.forwardRef(
    ({ className: e, variant: t, size: o, asChild: r = !1, ...n }, s) => {
      const a = r ? Je : "button";
      return ae.jsx(a, {
        className: Ho(Xo({ variant: t, size: o, className: e })),
        ref: s,
        ...n,
      });
    },
  );
Zo.displayName = "Button";
export { Zo as B, Ko as R };
