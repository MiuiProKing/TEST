function m(s, i = 300, e = 1 / 0) {
  const n = new Set();
  return [...s]
    .sort((t, a) => a.timestamp - t.timestamp)
    .filter((t) =>
      !Number.isFinite(t.coefficient) ||
      t.coefficient < 1 ||
      !Number.isFinite(t.timestamp) ||
      t.timestamp <= 0 ||
      t.timestamp > e ||
      (t.id && n.has(t.id))
        ? !1
        : (t.id && n.add(t.id), !0),
    )
    .slice(0, i);
}
function f(s, i = Date.now()) {
  const e = s[0]?.timestamp;
  return e !== void 0 && e <= i + 3e4 && i - e <= 18e4;
}
export { f as a, m as o };
