import {
  c as L,
  f as j,
  $ as I,
  a0 as $,
  r as t,
  j as e,
  g as y,
  T as C,
  a1 as M,
  a2 as D,
  a3 as A,
  N as S,
  C as F,
} from "./index-C5ThNCN-.js";
import { L as q } from "./wrench-DMPf9Lxe.js";
import { L as O } from "./lock-DtZN1438.js";
import { D as R } from "./DashboardLayout-XCzqIJrp.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
const T = [
    ["path", { d: "M18 20a6 6 0 0 0-12 0", key: "1qehca" }],
    ["circle", { cx: "12", cy: "10", r: "4", key: "1h16sb" }],
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ],
  z = L("circle-user-round", T);
const H = [
    ["path", { d: "M10 15H6a4 4 0 0 0-4 4v2", key: "1nfge6" }],
    ["path", { d: "m14.305 16.53.923-.382", key: "1itpsq" }],
    ["path", { d: "m15.228 13.852-.923-.383", key: "eplpkm" }],
    ["path", { d: "m16.852 12.228-.383-.923", key: "13v3q0" }],
    ["path", { d: "m16.852 17.772-.383.924", key: "1i8mnm" }],
    ["path", { d: "m19.148 12.228.383-.923", key: "1q8j1v" }],
    ["path", { d: "m19.53 18.696-.382-.924", key: "vk1qj3" }],
    ["path", { d: "m20.772 13.852.924-.383", key: "n880s0" }],
    ["path", { d: "m20.772 16.148.924.383", key: "1g6xey" }],
    ["circle", { cx: "18", cy: "15", r: "3", key: "gjjjvw" }],
    ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ],
  K = L("user-cog", H),
  P = "lj_access_token";
function U(i) {
  if (i <= 0) return "Expirée";
  const c = Math.floor(i / 1e3),
    s = Math.floor(c / 86400),
    d = Math.floor((c % 86400) / 3600),
    a = Math.floor((c % 3600) / 60),
    x = c % 60;
  return s > 0
    ? `${s}j ${d}h ${a}m`
    : d > 0
      ? `${d}h ${a}m ${x}s`
      : a > 0
        ? `${a}m ${x}s`
        : `${x}s`;
}
function V() {
  const i = j(I),
    c = j($),
    [s, d] = t.useState(null),
    [a, x] = t.useState(!1),
    [o, N] = t.useState(Date.now()),
    [m, f] = t.useState(!0),
    [b, g] = t.useState(!1);
  (t.useEffect(() => {
    const r = typeof window < "u" ? localStorage.getItem(P) : null;
    if (!r) {
      f(!1);
      return;
    }
    i({ data: { token: r } })
      .then((l) => {
        l.ok && l.unlimited
          ? x(!0)
          : l.ok
            ? d(l.keyExpiresAt ?? l.expiresAt ?? null)
            : g(!0);
      })
      .catch(() => g(!0))
      .finally(() => f(!1));
  }, [i]),
    t.useEffect(() => {
      const r = setInterval(() => N(Date.now()), 1e3);
      return () => clearInterval(r);
    }, []));
  async function k() {
    const r = localStorage.getItem(P);
    if (r)
      try {
        await c({ data: { token: r } });
      } catch {}
    (M(), window.location.reload());
  }
  const h = s ? new Date(s).getTime() - o : 0,
    v = s ? h <= 0 : !1;
  return e.jsxs("section", {
    id: "profil",
    className: "glass rounded-3xl p-4 sm:p-6 lg:p-8 flex flex-col gap-4",
    children: [
      e.jsxs("div", {
        className: "flex items-center justify-between flex-wrap gap-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-3",
            children: [
              e.jsx("div", {
                className:
                  "w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--neon-purple)] to-[var(--neon-blue)] flex items-center justify-center shadow-[0_0_25px_rgba(168,85,247,0.4)]",
                children: e.jsx(z, { className: "w-6 h-6 text-white" }),
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("h2", {
                    className:
                      "font-display font-bold text-lg sm:text-xl tracking-tight",
                    children: "Profil",
                  }),
                  e.jsxs("p", {
                    className:
                      "text-xs text-muted-foreground flex items-center gap-1.5",
                    children: [
                      e.jsx(y, {
                        className: "w-3.5 h-3.5 text-[var(--neon-green)]",
                      }),
                      "Session sécurisée",
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("button", {
            onClick: k,
            className:
              "inline-flex items-center gap-2 glass rounded-xl px-3 py-2 text-xs font-mono hover:text-[var(--neon-orange)] hover:border-[var(--neon-orange)]/40 transition-colors",
            children: [e.jsx(q, { className: "w-3.5 h-3.5" }), "Déconnexion"],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4",
        children: [
          e.jsxs("div", {
            className: "glass rounded-2xl p-4 flex items-center gap-3",
            children: [
              e.jsx(C, {
                className: `w-5 h-5 ${v ? "text-[var(--neon-orange)]" : "text-[var(--neon-blue)]"}`,
              }),
              e.jsxs("div", {
                className: "flex flex-col",
                children: [
                  e.jsx("span", {
                    className:
                      "text-[10px] uppercase tracking-widest text-muted-foreground",
                    children: "Temps restant avant expiration",
                  }),
                  e.jsx("span", {
                    className: `font-display font-bold text-xl text-glow ${v ? "text-[var(--neon-orange)]" : "text-[var(--neon-purple)]"}`,
                    children: m
                      ? "…"
                      : a
                        ? "Illimitée ∞"
                        : s
                          ? U(h)
                          : b
                            ? "Indisponible"
                            : "—",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "glass rounded-2xl p-4 flex items-center gap-3",
            children: [
              e.jsx(y, { className: "w-5 h-5 text-[var(--neon-green)]" }),
              e.jsxs("div", {
                className: "flex flex-col",
                children: [
                  e.jsx("span", {
                    className:
                      "text-[10px] uppercase tracking-widest text-muted-foreground",
                    children: "Date d'expiration",
                  }),
                  e.jsx("span", {
                    className: "font-mono text-sm text-foreground",
                    children: m
                      ? "…"
                      : a
                        ? "Aucune (accès permanent)"
                        : s
                          ? new Date(s).toLocaleString("fr-FR")
                          : "—",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const _ = "lj_access_token";
function Y() {
  const i = j(D),
    c = j(A),
    [s, d] = t.useState(""),
    [a, x] = t.useState(""),
    [o, N] = t.useState(""),
    [m, f] = t.useState(""),
    [b, g] = t.useState(!1),
    [k, h] = t.useState(!0),
    [v, r] = t.useState(!1),
    [l, p] = t.useState(null);
  t.useEffect(() => {
    const n = typeof window < "u" ? localStorage.getItem(_) : null;
    if (!n) {
      h(!1);
      return;
    }
    i({ data: { token: n } })
      .then((u) => {
        u.ok && (d(u.firstName ?? ""), x(u.lastName ?? ""), g(u.hasPin));
      })
      .finally(() => h(!1));
  }, [i]);
  async function E(n) {
    n.preventDefault();
    const u = localStorage.getItem(_);
    if (u) {
      if ((p(null), o || m)) {
        if (o !== m)
          return p({ ok: !1, text: "Les deux PIN ne correspondent pas." });
        if (!/^\d{4,6}$/.test(o))
          return p({ ok: !1, text: "PIN : 4 à 6 chiffres." });
      }
      r(!0);
      try {
        const w = await c({
          data: {
            token: u,
            firstName: s.trim() || null,
            lastName: a.trim() || null,
            pin: o || void 0,
          },
        });
        w.ok
          ? (p({ ok: !0, text: "Modifications enregistrées ✓" }),
            o && g(!0),
            N(""),
            f(""))
          : p({ ok: !1, text: w.error ?? "Erreur d'enregistrement" });
      } catch {
        p({ ok: !1, text: "Erreur réseau" });
      } finally {
        r(!1);
      }
    }
  }
  return e.jsxs("section", {
    className: "glass rounded-3xl p-4 sm:p-6 lg:p-8 flex flex-col gap-5",
    children: [
      e.jsxs("div", {
        className: "flex items-center gap-3",
        children: [
          e.jsx("div", {
            className:
              "w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--neon-blue)] to-[var(--neon-purple)] flex items-center justify-center shadow-[0_0_25px_rgba(59,130,246,0.4)]",
            children: e.jsx(K, { className: "w-6 h-6 text-white" }),
          }),
          e.jsxs("div", {
            children: [
              e.jsx("h2", {
                className:
                  "font-display font-bold text-lg sm:text-xl tracking-tight",
                children: "Paramètres",
              }),
              e.jsx("p", {
                className: "text-xs text-muted-foreground",
                children: "Modifiez votre identité et votre code de sécurité",
              }),
            ],
          }),
        ],
      }),
      k
        ? e.jsxs("div", {
            className: "flex items-center gap-2 text-sm text-muted-foreground",
            children: [
              e.jsx(S, { className: "w-4 h-4 animate-spin" }),
              " Chargement…",
            ],
          })
        : e.jsxs("form", {
            onSubmit: E,
            className: "flex flex-col gap-4",
            children: [
              e.jsxs("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
                children: [
                  e.jsxs("label", {
                    className: "flex flex-col gap-1.5",
                    children: [
                      e.jsx("span", {
                        className:
                          "text-[10px] uppercase tracking-widest text-muted-foreground",
                        children: "Prénom",
                      }),
                      e.jsx("input", {
                        value: s,
                        onChange: (n) => d(n.target.value),
                        maxLength: 60,
                        placeholder: "Votre prénom",
                        className:
                          "bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[var(--neon-blue)]/60 focus:ring-2 focus:ring-[var(--neon-blue)]/20 transition",
                      }),
                    ],
                  }),
                  e.jsxs("label", {
                    className: "flex flex-col gap-1.5",
                    children: [
                      e.jsx("span", {
                        className:
                          "text-[10px] uppercase tracking-widest text-muted-foreground",
                        children: "Nom",
                      }),
                      e.jsx("input", {
                        value: a,
                        onChange: (n) => x(n.target.value),
                        maxLength: 60,
                        placeholder: "Votre nom",
                        className:
                          "bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[var(--neon-blue)]/60 focus:ring-2 focus:ring-[var(--neon-blue)]/20 transition",
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "glass rounded-2xl p-4 flex flex-col gap-3",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      e.jsx(O, {
                        className: "w-4 h-4 text-[var(--neon-purple)]",
                      }),
                      e.jsx("h3", {
                        className: "font-display font-bold text-sm",
                        children: b
                          ? "Changer votre PIN de sécurité"
                          : "Définir un PIN de sécurité",
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-[11px] text-muted-foreground -mt-1",
                    children:
                      "4 à 6 chiffres — protection supplémentaire pour votre clé d'accès.",
                  }),
                  e.jsxs("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
                    children: [
                      e.jsx("input", {
                        type: "password",
                        inputMode: "numeric",
                        pattern: "\\d*",
                        maxLength: 6,
                        value: o,
                        onChange: (n) => N(n.target.value.replace(/\D/g, "")),
                        placeholder: "Nouveau PIN",
                        className:
                          "bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-sm font-mono tracking-widest outline-none focus:border-[var(--neon-purple)]/60 focus:ring-2 focus:ring-[var(--neon-purple)]/20 transition",
                      }),
                      e.jsx("input", {
                        type: "password",
                        inputMode: "numeric",
                        pattern: "\\d*",
                        maxLength: 6,
                        value: m,
                        onChange: (n) => f(n.target.value.replace(/\D/g, "")),
                        placeholder: "Confirmer PIN",
                        className:
                          "bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-sm font-mono tracking-widest outline-none focus:border-[var(--neon-purple)]/60 focus:ring-2 focus:ring-[var(--neon-purple)]/20 transition",
                      }),
                    ],
                  }),
                ],
              }),
              l &&
                e.jsx("p", {
                  className: `text-xs font-mono text-center ${l.ok ? "text-[var(--neon-green)]" : "text-[var(--neon-orange)]"}`,
                  children: l.text,
                }),
              e.jsx("button", {
                type: "submit",
                disabled: v,
                className:
                  "relative overflow-hidden rounded-2xl py-3 font-display font-bold text-sm tracking-wider uppercase bg-gradient-to-r from-[var(--neon-blue)] to-[var(--neon-purple)] text-white disabled:opacity-50 hover:shadow-[0_0_30px_rgba(59,130,246,0.5)] transition-shadow flex items-center justify-center gap-2",
                children: v
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(S, { className: "w-4 h-4 animate-spin" }),
                        " Enregistrement…",
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(F, { className: "w-4 h-4" }),
                        " Enregistrer les modifications",
                      ],
                    }),
              }),
            ],
          }),
    ],
  });
}
function Z() {
  return e.jsxs(R, {
    children: [
      e.jsxs("header", {
        className: "glass rounded-3xl px-4 sm:px-6 py-6 text-center",
        children: [
          e.jsxs("h1", {
            className:
              "font-display font-bold text-2xl sm:text-3xl tracking-tight",
            children: [
              "MON ",
              e.jsx("span", {
                className: "text-[var(--neon-purple)] text-glow",
                children: "PROFIL",
              }),
            ],
          }),
          e.jsx("p", {
            className: "text-sm text-muted-foreground mt-2 max-w-xl mx-auto",
            children:
              "Gérez votre session, modifiez vos informations et consultez le temps restant avant expiration de votre clé.",
          }),
        ],
      }),
      e.jsx(V, {}),
      e.jsx(Y, {}),
    ],
  });
}
export { Z as component };
