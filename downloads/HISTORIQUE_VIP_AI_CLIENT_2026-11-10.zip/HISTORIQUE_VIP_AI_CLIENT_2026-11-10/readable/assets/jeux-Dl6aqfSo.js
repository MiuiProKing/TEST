import { r as p, j as e, A as w, m, Z as y, S as N } from "./index-C5ThNCN-.js";
import { u as _, P as k } from "./PremiumAccess-e9rUD6rd.js";
import { D as I } from "./DashboardLayout-XCzqIJrp.js";
import { l as b, j as L } from "./game-jetx-B-JXM8w7.js";
import { r as f } from "./game-rocketqueen-CCl9MGDg.js";
import { L as E } from "./lock-DtZN1438.js";
import { A as G } from "./arrow-right-vdV6jsVn.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const A = "/__l5e/assets-v1/52d46183-a69c-41f5-ab32-72c8336e53bb/1win-logo.png";
function O({
  open: t,
  gameName: s,
  gameImage: l,
  onComplete: a,
  duration: o = 2200,
}) {
  const [n, i] = p.useState(0);
  return (
    p.useEffect(() => {
      if (!t) {
        i(0);
        return;
      }
      const d = performance.now();
      let r = 0;
      const u = (c) => {
        const x = Math.min(100, ((c - d) / o) * 100);
        (i(x), x < 100 ? (r = requestAnimationFrame(u)) : setTimeout(a, 200));
      };
      return ((r = requestAnimationFrame(u)), () => cancelAnimationFrame(r));
    }, [t, o, a]),
    e.jsx(w, {
      children:
        t &&
        e.jsxs(m.div, {
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
          transition: { duration: 0.25 },
          className:
            "fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#0a0e27] overflow-hidden",
          children: [
            e.jsx("div", {
              className: "absolute inset-0 opacity-40",
              children: e.jsx("div", {
                className:
                  "absolute -top-1/2 -left-1/2 w-[200%] h-[200%] bg-[radial-gradient(circle_at_center,var(--neon-blue)_0%,transparent_50%)] animate-pulse",
              }),
            }),
            l &&
              e.jsxs(m.div, {
                initial: { scale: 0.8, opacity: 0, y: 20 },
                animate: { scale: 1, opacity: 1, y: 0 },
                transition: {
                  delay: 0.1,
                  type: "spring",
                  stiffness: 200,
                  damping: 20,
                },
                className:
                  "relative mb-6 rounded-2xl overflow-hidden shadow-[0_0_60px_rgba(59,130,246,0.5)] border border-white/10",
                children: [
                  e.jsx("img", {
                    src: l,
                    alt: s,
                    className: "w-40 h-52 sm:w-48 sm:h-64 object-cover",
                  }),
                  e.jsx("div", {
                    className:
                      "absolute inset-0 bg-gradient-to-t from-black/60 to-transparent",
                  }),
                ],
              }),
            e.jsx(m.h2, {
              initial: { opacity: 0, y: 10 },
              animate: { opacity: 1, y: 0 },
              transition: { delay: 0.25 },
              className:
                "font-display font-black text-2xl sm:text-3xl text-white mb-2 tracking-tight",
              children: s,
            }),
            e.jsxs(m.div, {
              initial: { opacity: 0 },
              animate: { opacity: 1 },
              transition: { delay: 0.35 },
              className: "flex items-center gap-2 mb-8",
              children: [
                e.jsx("span", {
                  className: "text-xs uppercase tracking-[0.2em] text-white/50",
                  children: "by",
                }),
                e.jsx("img", {
                  src: A,
                  alt: "1Win",
                  className: "h-5 w-auto opacity-90",
                }),
              ],
            }),
            e.jsx("div", {
              className:
                "relative w-64 sm:w-80 h-1.5 rounded-full bg-white/10 overflow-hidden",
              children: e.jsx(m.div, {
                className:
                  "absolute inset-y-0 left-0 bg-gradient-to-r from-[var(--neon-blue)] via-[var(--neon-purple)] to-[var(--neon-orange)] shadow-[0_0_12px_var(--neon-blue)]",
                style: { width: `${n}%` },
              }),
            }),
            e.jsxs("div", {
              className: "mt-3 font-mono text-xs text-white/70 tabular-nums",
              children: [Math.floor(n), "%"],
            }),
            e.jsx("div", {
              className:
                "mt-4 text-[11px] uppercase tracking-[0.2em] text-white/40",
              children: "Chargement du jeu…",
            }),
          ],
        }),
    })
  );
}
const B = "/assets/highflyer-logo-DO-ESu9T.jpg",
  C = "/assets/wild-west-gold-DAtjWciE.jpg",
  S = "/assets/game-crash-DZvZhlN0.jpg",
  M = "/assets/game-mines-CzpWtwgO.jpg",
  P = "/assets/game-crash2-HIvoexRE.jpg",
  R = "/assets/game-apple-B6PG5JMB.jpg",
  T = "/__l5e/assets-v1/52d46183-a69c-41f5-ab32-72c8336e53bb/1win-logo.png",
  W = "/__l5e/assets-v1/48974847-cc9f-428d-bf5b-717b2d1cd347/1xbet-logo.png",
  J =
    "/__l5e/assets-v1/82f6e81d-ae8c-475c-a3da-bbe18750b285/betclic-logo-new.png",
  h = "/__l5e/assets-v1/fce7f57b-6c3c-4e6c-acfe-d1a01b0f4d30/jetx-logo.png",
  V =
    "/__l5e/assets-v1/2501fd19-7197-43ba-9f04-83c9e4c74b64/betclic-aviator.png",
  v =
    "/__l5e/assets-v1/3d3f809d-d40f-4ceb-8264-53993261ffe3/jetx-1win-logo.png",
  z =
    "/__l5e/assets-v1/d31cbcbc-8f61-4d88-9c80-d38676f33266/aviator-1win-logo.png",
  j =
    "https://1wlucb.life/resources/v1/optimizeimages/unsafe/casino_game_card_x1/plain/https://v1.bundlecdn.com/casino-images/v/f640dd82-890e-4f6c-954b-0c28eccfa0ec_vertical.png@avif",
  D = [
    {
      id: "luckyjet",
      name: "Lucky Jet",
      image: b,
      tag: "LIVE",
      to: "/",
      available: !0,
    },
    { id: "crash", name: "Crash", image: S, available: !1 },
    {
      id: "rocketqueen",
      name: "Rocket Queen",
      image: f,
      tag: "LIVE",
      to: "/rocketqueen",
      available: !0,
    },
    { id: "mines", name: "Mines", image: M, available: !1 },
    {
      id: "jetx-1win",
      name: "JetX",
      image: v,
      tag: "LIVE",
      to: "/jetx-1win",
      available: !0,
    },
    { id: "aviator-1win", name: "Aviator", image: z, available: !1 },
    {
      id: "astronaut",
      name: "Astronaut",
      image: j,
      tag: "LIVE",
      to: "/astronaut",
      available: !0,
    },
  ],
  X = [
    { id: "jetx", name: "JetX", image: L, tag: "PROMO", available: !1 },
    { id: "crash2", name: "Crash", image: P, available: !1 },
    {
      id: "apple",
      name: "Apple of Fortune",
      image: R,
      tag: "DEMO",
      available: !1,
    },
  ],
  $ =
    "https://dam.begmedia.com/casino/betclic/games/487152e6-707c-4b04-b0d8-b85e8f2927ba_2b.jpg",
  F =
    "https://dam.begmedia.com/casino/betclic/games/C73596FA-755E-407C-97B1-B509FEF4E415_2b.jpg",
  U = [
    {
      id: "betclic-jetx",
      name: "JetX",
      image: h,
      tag: "LIVE",
      to: "/jetx",
      available: !0,
    },
    {
      id: "betclic-dragonscrash",
      name: "Dragon's Crash",
      image: F,
      available: !1,
    },
    {
      id: "betclic-splinko",
      name: "Splinko Deluxe",
      image: $,
      tag: "BEST",
      to: "/splinko",
      available: !0,
    },
    {
      id: "betclic-aviator",
      name: "Aviator",
      image: V,
      tag: "LIVE",
      to: "/aviator",
      available: !0,
    },
    { id: "betclic-highflyer", name: "High Flyer", image: B, available: !1 },
  ],
  q = [
    {
      id: "melbet-wildwestgold",
      name: "Wild West Gold",
      image: C,
      available: !1,
    },
  ],
  H = [
    {
      id: "premium-luckyjet",
      name: "Lucky Jet",
      image: b,
      tag: "LIVE",
      to: "/premium/luckyjet",
      available: !0,
    },
    {
      id: "premium-rocketqueen",
      name: "Rocket Queen",
      image: f,
      tag: "LIVE",
      to: "/premium/rocketqueen",
      available: !0,
    },
    {
      id: "premium-jetx-1win",
      name: "JetX",
      image: v,
      tag: "LIVE",
      to: "/premium/jetx-1win",
      available: !0,
    },
    {
      id: "premium-astronaut",
      name: "Astronaut",
      image: j,
      tag: "LIVE",
      to: "/premium/astronaut",
      available: !0,
    },
    {
      id: "premium-jetx-betclic",
      name: "JetX Betclic",
      image: h,
      tag: "LIVE",
      to: "/premium/jetx",
      available: !0,
    },
  ];
function Z({ tag: t }) {
  const s = {
    BEST: "bg-[var(--neon-orange)] text-black",
    PROMO: "bg-[var(--neon-purple)] text-white",
    DEMO: "bg-[var(--neon-blue)] text-white",
    LIVE: "bg-[var(--neon-green)] text-black",
  };
  return e.jsxs("span", {
    className: `absolute top-2.5 right-2.5 z-10 px-2 py-0.5 rounded-full text-[9px] font-black tracking-[0.08em] uppercase ${s[t]} shadow-[0_0_12px_currentColor]`,
    children: [
      t === "LIVE" &&
        e.jsx("span", {
          className:
            "inline-block w-1 h-1 rounded-full bg-current mr-1 align-middle",
        }),
      t,
    ],
  });
}
function Q({ game: t, accent: s, onPlay: l }) {
  const a = e.jsxs(m.div, {
    whileHover: t.available ? { y: -6, scale: 1.03 } : { y: -2 },
    transition: { type: "spring", stiffness: 400, damping: 20 },
    className: `group relative rounded-2xl overflow-hidden border border-white/[0.08] bg-gradient-to-b from-white/[0.07] to-transparent shadow-lg shadow-black/20 ${t.available ? "cursor-pointer hover:shadow-[0_0_28px_var(--neon-purple-glow)] hover:border-[var(--neon-purple)]/40" : "cursor-not-allowed opacity-80"}`,
    children: [
      e.jsxs("div", {
        className: "relative aspect-square overflow-hidden",
        children: [
          t.tag && e.jsx(Z, { tag: t.tag }),
          e.jsx("img", {
            src: t.image,
            alt: t.name,
            loading: "lazy",
            width: 384,
            height: 512,
            className: `w-full h-full object-cover transition-all duration-500 ${t.available ? "group-hover:scale-110 group-hover:saturate-110" : "opacity-50 grayscale-[50%]"}`,
          }),
          !t.available &&
            e.jsxs("div", {
              className:
                "absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm",
              children: [
                e.jsx("div", {
                  className:
                    "w-10 h-10 rounded-full bg-white/10 flex items-center justify-center mb-2 border border-white/10",
                  children: e.jsx(E, { className: "w-4 h-4 text-white/70" }),
                }),
                e.jsx("span", {
                  className:
                    "text-[10px] font-black uppercase tracking-[0.15em] text-white/80",
                  children: "Bientôt",
                }),
              ],
            }),
          e.jsx("div", {
            className: `absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t ${s} pointer-events-none opacity-90`,
          }),
        ],
      }),
      e.jsxs("div", {
        className:
          "flex items-center justify-between px-3 py-2.5 bg-black/60 border-t border-white/[0.06]",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-1.5 min-w-0",
            children: [
              e.jsx("span", {
                className:
                  "font-display font-bold text-xs sm:text-sm text-white truncate",
                children: t.name,
              }),
              t.available &&
                e.jsx("span", { className: "text-[10px]", children: "🔥" }),
            ],
          }),
          t.available
            ? e.jsx(G, {
                className:
                  "w-3.5 h-3.5 text-[var(--neon-purple)] shrink-0 group-hover:translate-x-1 transition-transform",
              })
            : e.jsx(N, {
                className: "w-3.5 h-3.5 text-yellow-500/70 shrink-0",
              }),
        ],
      }),
    ],
  });
  return t.available && t.to && l
    ? e.jsx("button", {
        type: "button",
        onClick: () => l(t),
        className: "block text-left w-full",
        children: a,
      })
    : a;
}
function g({
  title: t,
  badge: s,
  badgeGradient: l,
  logoUrl: a,
  logoAlt: o,
  description: n,
  games: i,
  accent: d,
  cols: r,
  onPlay: u,
}) {
  return e.jsxs("section", {
    className: "glass rounded-2xl p-3 sm:p-5",
    children: [
      e.jsxs("div", {
        className: "flex items-center justify-between flex-wrap gap-3 mb-4",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2.5 min-w-0",
            children: [
              a
                ? e.jsx("div", {
                    className:
                      "shrink-0 h-7 sm:h-8 px-2 py-1 rounded-lg bg-white/[0.06] border border-white/[0.08] flex items-center justify-center shadow-md",
                    children: e.jsx("img", {
                      src: a,
                      alt: o ?? t,
                      className: "h-full w-auto object-contain",
                      loading: "lazy",
                    }),
                  })
                : e.jsx("div", {
                    className: `shrink-0 px-2.5 py-1 rounded-lg font-display font-black text-xs text-white shadow-lg ${l}`,
                    children: s,
                  }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsx("h2", {
                    className:
                      "font-display font-bold text-base sm:text-xl tracking-tight truncate",
                    children: t,
                  }),
                  e.jsx("p", {
                    className: "text-[11px] sm:text-xs text-muted-foreground",
                    children: n,
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("span", {
            className:
              "text-[10px] font-mono text-muted-foreground bg-white/[0.04] px-2 py-1 rounded-full border border-white/[0.06]",
            children: [
              i.filter((c) => c.available).length,
              "/",
              i.length,
              " actif",
            ],
          }),
        ],
      }),
      e.jsx("div", {
        className: `grid ${r} gap-2.5 sm:gap-3.5`,
        children: i.map((c) =>
          e.jsx(Q, { game: c, accent: d, onPlay: u }, c.id),
        ),
      }),
    ],
  });
}
function ne() {
  const t = y(),
    [s, l] = p.useState(null),
    [a, o] = p.useState("games"),
    n = _(),
    i = (r) => l(r),
    d = () => {
      (s?.to && t({ to: s.to }), l(null));
    };
  return e.jsxs(I, {
    children: [
      e.jsxs("div", {
        className: "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5",
        children: [
          e.jsx("h1", {
            className:
              "font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight bg-gradient-to-r from-[var(--neon-purple)] via-[var(--neon-blue)] to-[var(--neon-orange)] bg-clip-text text-transparent",
            children: "Choisissez votre plateforme",
          }),
          e.jsx("p", {
            className: "text-xs text-muted-foreground mt-1",
            children:
              "Sélectionnez un jeu pour accéder à son analyseur temps réel.",
          }),
        ],
      }),
      e.jsx("div", {
        className: "flex justify-center",
        children: e.jsxs("div", {
          role: "tablist",
          className:
            "relative grid grid-cols-2 w-full max-w-sm rounded-full glass p-1",
          children: [
            e.jsx("span", {
              "aria-hidden": !0,
              className: `absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-full transition-all duration-300 ${a === "premium" ? "left-[calc(50%+2px)] bg-gradient-to-r from-yellow-400 to-amber-600" : "left-1 bg-gradient-to-r from-[var(--neon-purple)] to-[var(--neon-blue)]"}`,
            }),
            e.jsx("button", {
              role: "tab",
              "aria-selected": a === "games",
              onClick: () => o("games"),
              className: `relative z-10 py-2 text-sm font-bold rounded-full ${a === "games" ? "text-foreground" : "text-muted-foreground"}`,
              children: "🎮 Jeux",
            }),
            e.jsx("button", {
              role: "tab",
              "aria-selected": a === "premium",
              onClick: () => o("premium"),
              className: `relative z-10 py-2 text-sm font-bold rounded-full ${a === "premium" ? "text-foreground" : "text-muted-foreground"}`,
              children: "★ Premium",
            }),
          ],
        }),
      }),
      a === "premium" && n !== "ok"
        ? e.jsx(k, { loading: n === "loading" })
        : a === "premium"
          ? e.jsx(g, {
              title: "Signaux Premium",
              badge: "★",
              badgeGradient: "bg-gradient-to-br from-yellow-400 to-amber-600",
              description: "Lucky Jet, JetX 1Win et JetX Betclic",
              games: H.filter((r) =>
                [
                  "premium-luckyjet",
                  "premium-jetx-1win",
                  "premium-jetx-betclic",
                ].includes(r.id),
              ),
              accent: "from-amber-900/80 to-transparent",
              cols: "grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5",
              onPlay: i,
            })
          : e.jsxs(e.Fragment, {
              children: [
                e.jsx(g, {
                  title: "Games",
                  badge: "1W",
                  badgeGradient: "bg-gradient-to-br from-blue-500 to-blue-700",
                  logoUrl: T,
                  logoAlt: "Logo 1Win Games",
                  description: "Suite officielle 1Win",
                  games: D,
                  accent: "from-purple-900/80 to-transparent",
                  cols: "grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-7 xl:grid-cols-8",
                  onPlay: i,
                }),
                e.jsx(g, {
                  title: "Games",
                  badge: "1×",
                  badgeGradient:
                    "bg-gradient-to-br from-emerald-500 to-emerald-700",
                  logoUrl: W,
                  logoAlt: "Logo 1xBet Games",
                  description: "Suite officielle 1xBet",
                  games: X,
                  accent: "from-black/80 to-transparent",
                  cols: "grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-7",
                  onPlay: i,
                }),
                e.jsx(g, {
                  title: "Games",
                  badge: "BC",
                  badgeGradient: "bg-gradient-to-br from-red-500 to-red-700",
                  logoUrl: J,
                  logoAlt: "Logo Betclic Games",
                  description: "Suite officielle Betclic",
                  games: U,
                  accent: "from-red-900/80 to-transparent",
                  cols: "grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-7",
                  onPlay: i,
                }),
                e.jsx(g, {
                  title: "Games",
                  badge: "MB",
                  badgeGradient:
                    "bg-gradient-to-br from-yellow-400 to-yellow-600",
                  logoUrl: "/logos/melbet-logo.svg",
                  logoAlt: "Logo MelBet",
                  description: "Suite officielle MelBet",
                  games: q,
                  accent: "from-yellow-900/80 to-transparent",
                  cols: "grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-7",
                  onPlay: i,
                }),
              ],
            }),
      e.jsx("footer", {
        className:
          "glass rounded-2xl px-4 py-3 text-center text-[10px] text-muted-foreground",
        children:
          "⚡ De nouveaux jeux seront ajoutés prochainement. Restez connectés !",
      }),
      e.jsx(O, {
        open: !!s,
        gameName: s?.name ?? "",
        gameImage: s?.image,
        onComplete: d,
      }),
    ],
  });
}
export { ne as component };
