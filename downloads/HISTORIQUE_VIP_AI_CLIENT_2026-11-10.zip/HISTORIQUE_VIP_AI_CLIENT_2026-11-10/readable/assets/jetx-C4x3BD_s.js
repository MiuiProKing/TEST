import { r as i, X as m, j as e } from "./index-C5ThNCN-.js";
import { R as x } from "./RoundCard-CZ-rEJ_D.js";
import { S as g, P as p } from "./PredictionPanel-BwmEfDz4.js";
import { D as u } from "./DashboardLayout-XCzqIJrp.js";
import "./analysis-data-BaiXRb_2.js";
import "./triangle-alert-CzDFXfJ_.js";
import "./database-80brKRBJ.js";
import "./trending-up-B5K2KKMW.js";
import "./activity-D198U5P3.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const f = "/__l5e/assets-v1/fce7f57b-6c3c-4e6c-acfe-d1a01b0f4d30/jetx-logo.png",
  h = { url: f };
function E() {
  const [r, d] = i.useState(!1);
  i.useEffect(() => {
    (localStorage.setItem("lj_current_game", "jetx"), d(!0));
  }, []);
  const { rounds: s, status: a, newestId: c, errorMsg: t } = m(),
    n = !!(
      t?.includes("ws_error") ||
      t?.includes("ws_closed") ||
      t?.includes("ws_connection_timeout") ||
      t?.includes("negotiate_404")
    );
  return e.jsxs(u, {
    children: [
      e.jsxs("div", {
        className:
          "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between flex-wrap gap-3 relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "absolute inset-0 bg-gradient-to-r from-red-600/10 via-transparent to-orange-500/10 pointer-events-none",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-3 min-w-0 relative",
            children: [
              e.jsx("img", {
                src: h.url,
                alt: "JetX",
                className:
                  "shrink-0 w-11 h-11 rounded-xl object-cover shadow-[0_0_20px_rgba(249,115,22,0.4)]",
              }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 flex-wrap",
                    children: [
                      e.jsx("h1", {
                        className:
                          "font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight bg-gradient-to-r from-orange-400 via-[var(--neon-orange)] to-red-500 bg-clip-text text-transparent",
                        children: "JetX",
                      }),
                      e.jsx("span", {
                        className:
                          "text-muted-foreground font-light text-lg sm:text-xl",
                        children: "×",
                      }),
                      e.jsx("div", {
                        className:
                          "inline-flex items-center px-2.5 py-1 rounded-lg bg-gradient-to-br from-red-600 to-red-800 shadow-[0_0_18px_rgba(220,38,38,0.5)] border border-red-400/30",
                        children: e.jsx("img", {
                          src: "/__l5e/assets-v1/82f6e81d-ae8c-475c-a3da-bbe18750b285/betclic-logo-new.png",
                          alt: "Betclic",
                          className: "h-5 sm:h-6 w-auto object-contain",
                        }),
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    children: "Historique des 20 derniers tours en temps réel",
                  }),
                ],
              }),
            ],
          }),
          r &&
            e.jsxs("div", {
              className: "flex items-center gap-2 text-xs font-mono",
              children: [
                e.jsx("span", {
                  className: `w-2 h-2 rounded-full animate-pulse ${a === "live" ? "bg-[var(--neon-green)]" : a === "error" ? "bg-[var(--neon-orange)]" : "bg-[var(--neon-blue)]"}`,
                }),
                e.jsx("span", {
                  className: "text-muted-foreground",
                  children:
                    a === "live"
                      ? "LIVE"
                      : a === "error"
                        ? n
                          ? "Flux Betclic refusé"
                          : `Erreur API${t ? ` : ${t}` : ""}`
                        : "Connexion…",
                }),
              ],
            }),
        ],
      }),
      r &&
        a === "error" &&
        n &&
        e.jsxs("div", {
          className:
            "glass rounded-2xl border border-[var(--neon-orange)]/30 px-4 py-3 text-xs sm:text-sm text-muted-foreground",
          children: [
            e.jsx("span", {
              className: "font-display font-bold text-[var(--neon-orange)]",
              children: "JetX Betclic :",
            }),
            " ",
            "Betclic refuse la connexion serveur actuelle. Le direct repart via le collecteur navigateur Betclic dès que JetX est ouvert avec le script actif.",
          ],
        }),
      r && s.length > 0 && e.jsx(g, { rounds: s }),
      r && s.length > 0 && e.jsx(p, { rounds: s, table: "jetx_rounds" }),
      e.jsxs("main", {
        className: "glass rounded-3xl p-4 sm:p-6 lg:p-8",
        children: [
          e.jsx("div", {
            className: "flex items-end justify-between flex-wrap gap-2 mb-5",
            children: e.jsxs("div", {
              children: [
                e.jsx("h2", {
                  className:
                    "font-display font-bold text-xl sm:text-2xl tracking-tight",
                  children: "20 derniers tours",
                }),
                e.jsx("p", {
                  className: "text-xs sm:text-sm text-muted-foreground mt-1",
                  children:
                    "Mise à jour en temps réel depuis l'API officielle JetX",
                }),
              ],
            }),
          }),
          r && s.length === 0
            ? e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: Array.from({ length: 20 }).map((l, o) =>
                  e.jsx(
                    "div",
                    {
                      className:
                        "rounded-2xl h-[56px] sm:h-[64px] glass animate-pulse",
                      style: { animationDelay: `${o * 50}ms` },
                    },
                    o,
                  ),
                ),
              })
            : e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: s.map((l) =>
                  e.jsx(x, { round: l, isNew: l.id === c }, l.id),
                ),
              }),
        ],
      }),
    ],
  });
}
export { E as component };
