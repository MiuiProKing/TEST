import {
  c as b,
  f as k,
  _,
  r,
  j as e,
  N as C,
  G as f,
  S as j,
  C as S,
  a as I,
} from "./index-C5ThNCN-.js";
import { D as R } from "./DashboardLayout-XCzqIJrp.js";
import { L as E } from "./lock-DtZN1438.js";
import { S as P } from "./wrench-DMPf9Lxe.js";
import { U as T } from "./users-DGoEMYbj.js";
import { T as L } from "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
const D = [
    [
      "path",
      {
        d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
        key: "1sd12s",
      },
    ],
  ],
  q = b("message-circle", D);
const A = [
    ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }],
    ["circle", { cx: "6", cy: "12", r: "3", key: "w7nqdw" }],
    ["circle", { cx: "18", cy: "19", r: "3", key: "1xt0gg" }],
    [
      "line",
      { x1: "8.59", x2: "15.42", y1: "13.51", y2: "17.49", key: "47mynk" },
    ],
    [
      "line",
      { x1: "15.41", x2: "8.59", y1: "6.51", y2: "10.49", key: "1n3mei" },
    ],
  ],
  F = b("share-2", A),
  O = "lj_access_token",
  $ = "https://historique-luckyjet.shop",
  d = [
    { count: 10, label: "Bronze", color: "#CD7F32" },
    { count: 50, label: "Argent", color: "#C0C0C0" },
    { count: 100, label: "Or", color: "#FFD700" },
  ];
function U() {
  const x = k(_),
    [t, v] = r.useState(null),
    [m, o] = r.useState(null),
    [N, u] = r.useState(!0),
    [w, p] = r.useState(!1);
  r.useEffect(() => {
    const s = typeof window < "u" ? localStorage.getItem(O) : null;
    if (!s) {
      (u(!1), o("Session invalide"));
      return;
    }
    x({ data: { token: s } })
      .then((n) => {
        n.ok ? v(n) : o(n.error ?? "Indisponible");
      })
      .catch(() => o("Erreur réseau"))
      .finally(() => u(!1));
  }, [x]);
  const a = r.useMemo(() => (t?.code ? `${$}/?ref=${t.code}` : ""), [t?.code]),
    g = r.useMemo(
      () => `🚀 Salut ! J'utilise GOD PREDITOR pour mes prédictions Lucky Jet, Aviator, JetX et Sport (foot). Les analyses IA sont vraiment fiables.

Utilise mon lien pour t'inscrire : ${a}`,
      [a],
    );
  async function h() {
    if (a)
      try {
        (await navigator.clipboard.writeText(a),
          p(!0),
          setTimeout(() => p(!1), 2e3));
      } catch {}
  }
  function l(s) {
    if (!a) return;
    const n = encodeURIComponent(g);
    s === "whatsapp"
      ? window.open(`https://wa.me/?text=${n}`, "_blank", "noopener")
      : s === "telegram"
        ? window.open(
            `https://t.me/share/url?url=${encodeURIComponent(a)}&text=${n}`,
            "_blank",
            "noopener",
          )
        : navigator.share
          ? navigator
              .share({ title: "GOD PREDITOR", text: g, url: a })
              .catch(() => {})
          : h();
  }
  if (N)
    return e.jsxs("section", {
      className:
        "glass rounded-3xl p-8 flex items-center justify-center gap-2 text-muted-foreground",
      children: [
        e.jsx(C, { className: "w-5 h-5 animate-spin" }),
        " Chargement…",
      ],
    });
  if (m || !t)
    return e.jsxs("section", {
      className: "glass rounded-3xl p-8 text-center flex flex-col gap-3",
      children: [
        e.jsx(E, { className: "w-8 h-8 mx-auto text-[var(--neon-orange)]" }),
        e.jsx("h2", {
          className: "font-display font-bold text-lg",
          children: "Parrainage indisponible",
        }),
        e.jsx("p", {
          className: "text-sm text-muted-foreground",
          children: m ?? "Session expirée",
        }),
      ],
    });
  if (!t.eligible || !t.code)
    return e.jsxs("section", {
      className: "glass rounded-3xl p-8 text-center flex flex-col gap-4",
      children: [
        e.jsx("div", {
          className:
            "w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-[var(--neon-orange)] to-[var(--neon-purple)] flex items-center justify-center shadow-[0_0_35px_rgba(249,115,22,0.4)]",
          children: e.jsx(f, { className: "w-8 h-8 text-white" }),
        }),
        e.jsx("h2", {
          className: "font-display font-bold text-xl",
          children: "Le parrainage est réservé aux abonnés",
        }),
        e.jsxs("p", {
          className: "text-sm text-muted-foreground max-w-md mx-auto",
          children: [
            "Prenez un abonnement VIP pour activer votre lien de parrainage et gagner",
            e.jsx("strong", {
              className: "text-[var(--neon-orange)]",
              children: " +1 jour gratuit par ami parrainé",
            }),
            " (jusqu'à 100 jours bonus).",
          ],
        }),
        e.jsxs("a", {
          href: "/boutique",
          className:
            "mx-auto inline-flex items-center gap-2 rounded-2xl px-5 py-2.5 font-display font-bold text-sm tracking-wider uppercase bg-gradient-to-r from-[var(--neon-orange)] to-[var(--neon-purple)] text-white shadow-[0_0_25px_rgba(249,115,22,0.4)]",
          children: [
            e.jsx(j, { className: "w-4 h-4" }),
            " Débloquer maintenant",
          ],
        }),
      ],
    });
  const y = Math.min(100, (t.count / t.max) * 100),
    i = d.find((s) => t.count < s.count),
    c = [...d].reverse().find((s) => t.count >= s.count);
  return e.jsxs("div", {
    className: "flex flex-col gap-4",
    children: [
      e.jsxs("section", {
        className:
          "glass rounded-3xl p-5 sm:p-7 flex flex-col gap-5 relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "pointer-events-none absolute -top-24 -right-24 w-72 h-72 rounded-full bg-[var(--neon-purple)] opacity-20 blur-3xl",
          }),
          e.jsx("div", {
            className:
              "pointer-events-none absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-[var(--neon-orange)] opacity-20 blur-3xl",
          }),
          e.jsxs("div", {
            className: "relative flex items-center gap-3",
            children: [
              e.jsx("div", {
                className:
                  "w-12 h-12 rounded-2xl bg-gradient-to-br from-[var(--neon-orange)] to-[var(--neon-purple)] flex items-center justify-center shadow-[0_0_30px_rgba(249,115,22,0.4)]",
                children: e.jsx(f, { className: "w-6 h-6 text-white" }),
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("h2", {
                    className: "font-display font-bold text-xl tracking-tight",
                    children: "Votre lien de parrainage",
                  }),
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      e.jsx("strong", {
                        className: "text-[var(--neon-orange)]",
                        children: "+1 jour",
                      }),
                      " pour vous et pour votre filleul, à chaque abonnement.",
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "relative flex flex-col sm:flex-row gap-2",
            children: [
              e.jsxs("div", {
                className:
                  "flex-1 flex items-center gap-3 bg-black/40 border border-white/10 rounded-2xl px-4 py-3 min-w-0",
                children: [
                  e.jsx("span", {
                    className:
                      "text-[10px] uppercase tracking-widest text-muted-foreground shrink-0",
                    children: "Lien",
                  }),
                  e.jsx("code", {
                    className:
                      "font-mono text-sm text-foreground truncate flex-1",
                    children: a,
                  }),
                ],
              }),
              e.jsx("button", {
                onClick: h,
                className:
                  "inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3 bg-gradient-to-r from-[var(--neon-blue)] to-[var(--neon-purple)] font-display font-bold text-sm uppercase tracking-wider text-white shadow-[0_0_20px_rgba(59,130,246,0.4)]",
                children: w
                  ? e.jsxs(e.Fragment, {
                      children: [e.jsx(S, { className: "w-4 h-4" }), " Copié"],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [e.jsx(I, { className: "w-4 h-4" }), " Copier"],
                    }),
              }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-3 gap-2",
            children: [
              e.jsxs("button", {
                onClick: () => l("whatsapp"),
                className:
                  "flex items-center justify-center gap-1.5 rounded-xl py-2.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold hover:bg-emerald-500/25 transition",
                children: [e.jsx(q, { className: "w-4 h-4" }), " WhatsApp"],
              }),
              e.jsxs("button", {
                onClick: () => l("telegram"),
                className:
                  "flex items-center justify-center gap-1.5 rounded-xl py-2.5 bg-sky-500/15 border border-sky-500/30 text-sky-300 text-xs font-bold hover:bg-sky-500/25 transition",
                children: [e.jsx(P, { className: "w-4 h-4" }), " Telegram"],
              }),
              e.jsxs("button", {
                onClick: () => l("native"),
                className:
                  "flex items-center justify-center gap-1.5 rounded-xl py-2.5 bg-white/5 border border-white/10 text-white text-xs font-bold hover:bg-white/10 transition",
                children: [e.jsx(F, { className: "w-4 h-4" }), " Partager"],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
        children: [
          e.jsxs("div", {
            className: "glass rounded-2xl p-4 flex items-center gap-3",
            children: [
              e.jsx(T, { className: "w-6 h-6 text-[var(--neon-blue)]" }),
              e.jsxs("div", {
                children: [
                  e.jsx("p", {
                    className:
                      "text-[10px] uppercase tracking-widest text-muted-foreground",
                    children: "Filleuls confirmés",
                  }),
                  e.jsxs("p", {
                    className: "font-display font-black text-2xl text-glow",
                    children: [
                      t.count,
                      e.jsxs("span", {
                        className: "text-sm text-muted-foreground",
                        children: [" / ", t.max],
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "glass rounded-2xl p-4 flex items-center gap-3",
            children: [
              e.jsx(j, { className: "w-6 h-6 text-[var(--neon-orange)]" }),
              e.jsxs("div", {
                children: [
                  e.jsx("p", {
                    className:
                      "text-[10px] uppercase tracking-widest text-muted-foreground",
                    children: "Jours bonus gagnés",
                  }),
                  e.jsxs("p", {
                    className:
                      "font-display font-black text-2xl text-[var(--neon-orange)] text-glow",
                    children: ["+", t.daysEarned],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "glass rounded-2xl p-4 flex items-center gap-3",
            children: [
              e.jsx(L, {
                className: "w-6 h-6",
                style: { color: c?.color ?? "#666" },
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("p", {
                    className:
                      "text-[10px] uppercase tracking-widest text-muted-foreground",
                    children: "Palier actuel",
                  }),
                  e.jsx("p", {
                    className: "font-display font-black text-lg",
                    style: { color: c?.color ?? "#999" },
                    children: c?.label ?? "—",
                  }),
                  i &&
                    e.jsxs("p", {
                      className: "text-[10px] text-muted-foreground",
                      children: [i.count - t.count, " de plus → ", i.label],
                    }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        className: "glass rounded-2xl p-4",
        children: [
          e.jsxs("div", {
            className: "flex justify-between items-center mb-2",
            children: [
              e.jsx("span", {
                className:
                  "text-[10px] uppercase tracking-widest text-muted-foreground",
                children: "Progression vers 100 parrainages",
              }),
              e.jsxs("span", {
                className: "text-xs font-mono",
                children: [t.count, " / ", t.max],
              }),
            ],
          }),
          e.jsx("div", {
            className:
              "h-3 rounded-full bg-black/40 overflow-hidden border border-white/5",
            children: e.jsx("div", {
              className:
                "h-full bg-gradient-to-r from-[var(--neon-blue)] via-[var(--neon-purple)] to-[var(--neon-orange)] transition-all",
              style: { width: `${y}%` },
            }),
          }),
          e.jsx("div", {
            className:
              "flex justify-between mt-2 text-[10px] text-muted-foreground",
            children: d.map((s) =>
              e.jsxs(
                "span",
                {
                  style:
                    t.count >= s.count
                      ? { color: s.color, fontWeight: 700 }
                      : void 0,
                  children: ["🏆 ", s.count, " ", s.label],
                },
                s.label,
              ),
            ),
          }),
        ],
      }),
      e.jsxs("section", {
        className: "glass rounded-2xl p-5",
        children: [
          e.jsx("h3", {
            className: "font-display font-bold text-base mb-4",
            children: "Comment ça marche ?",
          }),
          e.jsx("div", {
            className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
            children: [
              {
                n: "1",
                t: "Partagez",
                d: "Envoyez votre lien à vos amis via WhatsApp ou Telegram.",
              },
              {
                n: "2",
                t: "Ils s'abonnent",
                d: "Votre filleul prend un abonnement via votre lien.",
              },
              {
                n: "3",
                t: "Vous gagnez",
                d: "+1 jour ajouté à votre clé (et +1 pour lui aussi 🎁).",
              },
            ].map((s) =>
              e.jsxs(
                "div",
                {
                  className:
                    "rounded-xl bg-black/30 border border-white/5 p-4 flex flex-col gap-2",
                  children: [
                    e.jsx("div", {
                      className:
                        "w-8 h-8 rounded-full bg-gradient-to-br from-[var(--neon-purple)] to-[var(--neon-blue)] flex items-center justify-center font-display font-black text-white",
                      children: s.n,
                    }),
                    e.jsx("p", {
                      className: "font-display font-bold text-sm",
                      children: s.t,
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children: s.d,
                    }),
                  ],
                },
                s.n,
              ),
            ),
          }),
        ],
      }),
      t.events.length > 0 &&
        e.jsxs("section", {
          className: "glass rounded-2xl p-5",
          children: [
            e.jsx("h3", {
              className: "font-display font-bold text-base mb-3",
              children: "Vos derniers parrainages",
            }),
            e.jsx("ul", {
              className: "flex flex-col gap-2",
              children: t.events.map((s, n) =>
                e.jsxs(
                  "li",
                  {
                    className:
                      "flex items-center justify-between text-xs bg-black/20 rounded-lg px-3 py-2",
                    children: [
                      e.jsx("span", {
                        className: "text-muted-foreground font-mono",
                        children: new Date(s.created_at).toLocaleString(
                          "fr-FR",
                        ),
                      }),
                      e.jsxs("span", {
                        className: "text-[var(--neon-orange)] font-bold",
                        children: ["+", s.days_awarded, " jour"],
                      }),
                    ],
                  },
                  n,
                ),
              ),
            }),
          ],
        }),
    ],
  });
}
function B() {
  return e.jsxs(R, {
    children: [
      e.jsxs("header", {
        className:
          "glass rounded-3xl px-4 sm:px-6 py-6 text-center relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(249,115,22,0.2),transparent_60%)]",
          }),
          e.jsxs("h1", {
            className:
              "relative font-display font-bold text-2xl sm:text-3xl tracking-tight",
            children: [
              "PARRAINAGE ",
              e.jsx("span", {
                className: "text-[var(--neon-orange)] text-glow",
                children: "VIP",
              }),
            ],
          }),
          e.jsxs("p", {
            className:
              "relative text-sm text-muted-foreground mt-2 max-w-2xl mx-auto",
            children: [
              "Recommandez GOD PREDITOR à vos amis. À chaque abonnement via votre lien, ",
              e.jsx("strong", {
                className: "text-[var(--neon-orange)]",
                children: "+1 jour gratuit",
              }),
              " est ajouté à votre clé (jusqu'à 100 jours bonus).",
            ],
          }),
        ],
      }),
      e.jsx(U, {}),
    ],
  });
}
export { B as component };
