import {
  c as x,
  r,
  f as k,
  j as e,
  C as j,
  W as w,
  N as M,
  g as E,
} from "./index-C5ThNCN-.js";
import { D as B } from "./DashboardLayout-XCzqIJrp.js";
import { c as S } from "./geniuspay.functions-D_URgro5.js";
import { L as p } from "./lock-DtZN1438.js";
import { C as _ } from "./wrench-DMPf9Lxe.js";
import { Z as C, T as A } from "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
const P = [
    ["path", { d: "M10 12h4", key: "a56b0p" }],
    ["path", { d: "M10 8h4", key: "1sr2af" }],
    ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
    [
      "path",
      {
        d: "M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",
        key: "secmi2",
      },
    ],
    ["path", { d: "M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16", key: "16ra0t" }],
  ],
  I = x("building-2", P);
const R = [
    [
      "rect",
      { width: "20", height: "14", x: "2", y: "5", rx: "2", key: "ynyp8z" },
    ],
    ["line", { x1: "2", x2: "22", y1: "10", y2: "10", key: "1b3vmo" }],
  ],
  T = x("credit-card", R);
const L = [
    [
      "path",
      {
        d: "M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3",
        key: "1xhozi",
      },
    ],
  ],
  U = x("headphones", L);
const O = [
    [
      "rect",
      {
        width: "14",
        height: "20",
        x: "5",
        y: "2",
        rx: "2",
        ry: "2",
        key: "1yt0o3",
      },
    ],
    ["path", { d: "M12 18h.01", key: "mhygvu" }],
  ],
  d = x("smartphone", O),
  z = "/assets/vip-crown-BU0XEJv3.png",
  N = 1e4,
  F = [
    { key: "premium_1m", label: "1 Mois", months: 1, price: N },
    { key: "premium_3m", label: "3 Mois", months: 3, price: 25e3 },
    {
      key: "premium_6m",
      label: "6 Mois",
      months: 6,
      price: 48e3,
      badge: "Best",
    },
  ].map((s) => {
    if (s.months <= 1) return s;
    const l = N * s.months,
      n = l - s.price,
      h = n > 0 ? Math.round((n / l) * 100) : 0;
    return { ...s, save: n > 0 ? `-${h}%` : void 0 };
  }),
  b = (s) => `${s.toLocaleString("fr-FR")} FCFA`,
  $ = [
    "Prédictions avancées",
    "Analyses en temps réel",
    "Historique complet",
    "Statistiques illimitées",
    "Support prioritaire",
  ],
  D = [
    {
      title: "CARTES BANCAIRES",
      methods: [
        {
          id: "card",
          label: "Carte bancaire",
          sub: "Visa, Mastercard, Maestro…",
          icon: T,
        },
      ],
    },
    {
      title: "PORTEFEUILLES MOBILE",
      methods: [
        { id: "orange", label: "Orange Money", sub: "Mobile Money", icon: d },
        { id: "mtn", label: "MTN Mobile Money", sub: "Mobile Money", icon: d },
        { id: "moov", label: "Moov Money", sub: "Mobile Money", icon: d },
        { id: "wave", label: "Wave", sub: "Mobile Money", icon: w },
        { id: "airtel", label: "Airtel Money", sub: "Mobile Money", icon: d },
      ],
    },
    {
      title: "AUTRES MOYENS",
      methods: [
        { id: "usdt", label: "USDT (TRC20)", sub: "Cryptomonnaie", icon: w },
        {
          id: "bank",
          label: "Virement bancaire",
          sub: "Virement direct",
          icon: I,
        },
      ],
    },
  ],
  V = [
    { icon: E, title: "Paiement sécurisé", sub: "Protection SSL 256 bits" },
    {
      icon: C,
      title: "Livraison immédiate",
      sub: "Accès instantané après paiement",
    },
    {
      icon: A,
      title: "Satisfait ou remboursé",
      sub: "Remboursement sous 7 jours",
    },
    { icon: U, title: "Support 24/7", sub: "Assistance dédiée" },
  ];
function J() {
  const [s, l] = r.useState("premium_1m"),
    [n, h] = r.useState("card"),
    [u, m] = r.useState(!1),
    [f, g] = r.useState(null),
    v = k(S),
    o = r.useMemo(() => F.find((t) => t.key === s), [s]);
  async function y() {
    (g(null), m(!0));
    try {
      const t =
          typeof window < "u"
            ? (() => {
                try {
                  return window.top?.location.origin ?? window.location.origin;
                } catch {
                  return window.location.origin;
                }
              })()
            : "",
        a =
          (typeof window < "u" && localStorage.getItem("lj_ref_code")) ||
          void 0,
        i = await v({ data: { planId: s, origin: t, refCode: a } });
      try {
        localStorage.setItem("lj_pending_ref", i.reference);
      } catch {}
      if (!window.open(i.checkoutUrl, "_blank", "noopener,noreferrer"))
        try {
          window.top && window.top !== window.self
            ? (window.top.location.href = i.checkoutUrl)
            : (window.location.href = i.checkoutUrl);
        } catch {
          window.location.href = i.checkoutUrl;
        }
      m(!1);
    } catch (t) {
      (g(t?.message ?? "Impossible d'initier le paiement"), m(!1));
    }
  }
  return e.jsxs(B, {
    children: [
      e.jsxs("header", {
        className:
          "rounded-3xl border border-white/[0.08] bg-gradient-to-br from-[#1a0b2e] via-[#0f0a1f] to-[#0b0916] px-4 sm:px-6 py-6 text-center relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(123,47,255,0.25),transparent_60%)]",
          }),
          e.jsxs("h1", {
            className:
              "relative font-display font-black text-2xl sm:text-3xl tracking-tight",
            children: [
              "Finalisez votre ",
              e.jsx("span", {
                className:
                  "italic text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                children: "PAIEMENT",
              }),
            ],
          }),
          e.jsx("p", {
            className: "relative text-sm text-white/60 mt-2",
            children: "Accédez à tous nos outils premium",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-3",
        children: [
          e.jsxs("aside", {
            className:
              "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-4 flex flex-col gap-4",
            children: [
              e.jsxs("div", {
                className: "flex flex-col items-center gap-2",
                children: [
                  e.jsxs("div", {
                    className: "relative",
                    children: [
                      e.jsx("div", {
                        className:
                          "absolute inset-0 rounded-full bg-[#7B2FFF]/30 blur-2xl",
                      }),
                      e.jsx("img", {
                        src: z,
                        alt: "VIP",
                        width: 64,
                        height: 64,
                        className: "relative w-16 h-16 object-contain",
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "text-center",
                    children: [
                      e.jsx("p", {
                        className: "text-[10px] tracking-[0.2em] text-white/50",
                        children: "ABONNEMENT VIP",
                      }),
                      e.jsx("p", {
                        className:
                          "font-display font-black text-xl bg-clip-text text-transparent bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                        children: "PREMIUM",
                      }),
                    ],
                  }),
                ],
              }),
              e.jsx("div", {
                className: "grid grid-cols-3 gap-2",
                children: F.map((t) => {
                  const a = t.key === s;
                  return e.jsxs(
                    "button",
                    {
                      onClick: () => l(t.key),
                      className: `relative rounded-xl border p-2 text-center transition ${a ? "border-[#7B2FFF] bg-[#7B2FFF]/15 shadow-[0_0_20px_rgba(123,47,255,0.35)]" : "border-white/10 bg-white/[0.02] hover:border-white/20"}`,
                      children: [
                        t.badge &&
                          e.jsx("span", {
                            className:
                              "absolute -top-2 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded-full bg-[var(--neon-orange)] text-black text-[8px] font-black uppercase tracking-wider whitespace-nowrap animate-pulse",
                            children: t.badge,
                          }),
                        e.jsx("p", {
                          className: "text-[10px] font-bold text-white/80",
                          children: t.label,
                        }),
                        t.oldPrice &&
                          e.jsx("p", {
                            className:
                              "text-[9px] text-white/40 line-through leading-tight",
                            children: t.oldPrice.toLocaleString("fr-FR"),
                          }),
                        e.jsx("p", {
                          className: `font-display font-black text-[13px] leading-tight ${t.oldPrice ? "text-[var(--neon-orange)]" : ""}`,
                          children: t.price.toLocaleString("fr-FR"),
                        }),
                        e.jsx("p", {
                          className: "text-[9px] text-white/50",
                          children: "FCFA",
                        }),
                        t.save &&
                          e.jsx("p", {
                            className:
                              "text-[9px] text-emerald-400 font-bold mt-0.5",
                            children: t.save,
                          }),
                      ],
                    },
                    t.key,
                  );
                }),
              }),
              e.jsx("p", {
                className: "text-xs text-white/60 text-center",
                children: "Accès complet à toutes les fonctionnalités",
              }),
              e.jsx("ul", {
                className: "flex flex-col gap-1.5",
                children: $.map((t) =>
                  e.jsxs(
                    "li",
                    {
                      className:
                        "flex items-center gap-2 text-xs text-white/85",
                      children: [
                        e.jsx(j, {
                          className: "w-3.5 h-3.5 text-emerald-400 shrink-0",
                        }),
                        t,
                      ],
                    },
                    t,
                  ),
                ),
              }),
              e.jsxs("div", {
                className:
                  "mt-auto pt-3 border-t border-white/[0.06] flex items-start gap-2",
                children: [
                  e.jsx(p, {
                    className: "w-4 h-4 text-[#7B2FFF] shrink-0 mt-0.5",
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("p", {
                        className: "text-[11px] font-bold",
                        children: "Paiement 100% sécurisé",
                      }),
                      e.jsx("p", {
                        className: "text-[10px] text-white/50",
                        children: "Chiffrement SSL 256 bits",
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("section", {
            className:
              "rounded-2xl border border-white/[0.08] bg-[#0F0B1F] p-4 flex flex-col gap-4",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between flex-wrap gap-2",
                children: [
                  e.jsx("h2", {
                    className: "font-display font-bold text-base",
                    children: "Choisissez votre méthode de paiement",
                  }),
                  e.jsxs("span", {
                    className:
                      "inline-flex items-center gap-1.5 text-[11px] text-white/60",
                    children: [
                      e.jsx(p, { className: "w-3 h-3" }),
                      " Paiement sécurisé",
                    ],
                  }),
                ],
              }),
              D.map((t) =>
                e.jsxs(
                  "div",
                  {
                    className: "flex flex-col gap-1.5",
                    children: [
                      e.jsx("p", {
                        className:
                          "text-[10px] font-bold tracking-[0.18em] text-white/40",
                        children: t.title,
                      }),
                      e.jsx("div", {
                        className: `grid gap-2 ${t.methods.length === 1 ? "grid-cols-1" : "grid-cols-2 sm:grid-cols-3"}`,
                        children: t.methods.map((a) => {
                          const i = a.icon,
                            c = n === a.id;
                          return e.jsxs(
                            "button",
                            {
                              onClick: () => h(a.id),
                              className: `flex items-center gap-2.5 rounded-xl border p-2.5 text-left transition ${c ? "border-[#7B2FFF] bg-[#7B2FFF]/10 shadow-[0_0_18px_rgba(123,47,255,0.3)]" : "border-white/10 bg-white/[0.02] hover:border-white/25"}`,
                              children: [
                                e.jsx("span", {
                                  className: `h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${c ? "bg-[#7B2FFF]/25 text-[#E040FB]" : "bg-white/[0.05] text-white/70"}`,
                                  children: e.jsx(i, { size: 14 }),
                                }),
                                e.jsxs("span", {
                                  className: "min-w-0 flex-1",
                                  children: [
                                    e.jsx("span", {
                                      className:
                                        "block text-[13px] font-semibold truncate",
                                      children: a.label,
                                    }),
                                    e.jsx("span", {
                                      className:
                                        "block text-[10px] text-white/50 truncate",
                                      children: a.sub,
                                    }),
                                  ],
                                }),
                                c &&
                                  e.jsx(j, {
                                    size: 12,
                                    className: "text-[#E040FB] shrink-0",
                                  }),
                              ],
                            },
                            a.id,
                          );
                        }),
                      }),
                    ],
                  },
                  t.title,
                ),
              ),
              e.jsxs("div", {
                className: "flex flex-col gap-1.5",
                children: [
                  e.jsx("p", {
                    className:
                      "text-[10px] font-bold tracking-[0.18em] text-white/40",
                    children: "RÉSUMÉ DE LA COMMANDE",
                  }),
                  e.jsxs("div", {
                    className:
                      "rounded-xl border border-white/[0.08] bg-black/40 p-3 flex flex-col gap-2.5",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-center gap-2.5",
                        children: [
                          e.jsx("span", {
                            className:
                              "h-9 w-9 rounded-lg bg-[#7B2FFF]/20 flex items-center justify-center text-[#E040FB]",
                            children: e.jsx(_, { size: 16 }),
                          }),
                          e.jsxs("div", {
                            className: "flex-1 min-w-0",
                            children: [
                              e.jsx("p", {
                                className: "font-semibold text-[13px] truncate",
                                children: "Abonnement VIP",
                              }),
                              e.jsxs("p", {
                                className: "text-[10px] text-white/50 truncate",
                                children: ["Plan Premium — ", o.label],
                              }),
                            ],
                          }),
                          e.jsx("span", {
                            className: "font-display font-bold text-sm",
                            children: b(o.price),
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className:
                          "border-t border-white/[0.06] pt-2.5 space-y-1 text-[13px]",
                        children: [
                          e.jsxs("div", {
                            className: "flex justify-between text-white/70",
                            children: [
                              e.jsx("span", { children: "Sous-total" }),
                              e.jsx("span", { children: b(o.price) }),
                            ],
                          }),
                          e.jsxs("div", {
                            className: "flex justify-between text-white/70",
                            children: [
                              e.jsx("span", {
                                children: "Frais de transaction",
                              }),
                              e.jsx("span", { children: "0 FCFA" }),
                            ],
                          }),
                          e.jsxs("div", {
                            className:
                              "flex justify-between items-center pt-2 border-t border-white/[0.06]",
                            children: [
                              e.jsx("span", {
                                className: "font-semibold",
                                children: "Total à payer",
                              }),
                              e.jsx("span", {
                                className:
                                  "font-display font-black text-xl text-transparent bg-clip-text bg-gradient-to-r from-[#7B2FFF] to-[#E040FB]",
                                children: b(o.price),
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              f &&
                e.jsx("div", {
                  className:
                    "rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200",
                  children: f,
                }),
              e.jsx("button", {
                onClick: y,
                disabled: u,
                className:
                  "relative h-11 w-full rounded-xl bg-gradient-to-r from-[#3D5AFE] via-[#7B2FFF] to-[#E040FB] font-display font-black tracking-wider text-white text-sm shadow-lg shadow-[#7B2FFF]/40 hover:shadow-[#7B2FFF]/60 disabled:opacity-60 transition flex items-center justify-center gap-2",
                children: u
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(M, { className: "w-4 h-4 animate-spin" }),
                        "REDIRECTION…",
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(p, { className: "w-4 h-4" }),
                        "PAYER MAINTENANT",
                      ],
                    }),
              }),
              e.jsxs("p", {
                className: "text-center text-[11px] text-white/50",
                children: [
                  "En poursuivant, vous acceptez nos ",
                  e.jsx("span", {
                    className: "text-[#E040FB]",
                    children: "Conditions d'utilisation",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsx("div", {
        className:
          "rounded-2xl border border-white/[0.08] bg-[#0B0916]/80 backdrop-blur px-4 py-4 grid grid-cols-2 sm:grid-cols-4 gap-4",
        children: V.map((t) => {
          const a = t.icon;
          return e.jsxs(
            "div",
            {
              className: "flex items-center gap-2.5",
              children: [
                e.jsx("span", {
                  className:
                    "h-9 w-9 shrink-0 rounded-xl bg-gradient-to-br from-[#3D5AFE]/20 to-[#7B2FFF]/20 text-[#E040FB] flex items-center justify-center",
                  children: e.jsx(a, { size: 16 }),
                }),
                e.jsxs("div", {
                  className: "min-w-0",
                  children: [
                    e.jsx("p", {
                      className: "text-xs font-bold truncate",
                      children: t.title,
                    }),
                    e.jsx("p", {
                      className: "text-[10px] text-white/50 truncate",
                      children: t.sub,
                    }),
                  ],
                }),
              ],
            },
            t.title,
          );
        }),
      }),
    ],
  });
}
export { J as component };
