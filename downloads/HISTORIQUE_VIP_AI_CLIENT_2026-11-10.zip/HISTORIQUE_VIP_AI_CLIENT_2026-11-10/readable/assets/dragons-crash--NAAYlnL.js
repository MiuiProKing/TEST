import {
  d as y,
  e as S,
  r as n,
  f as D,
  J as b,
  M as v,
  j as e,
  U as E,
} from "./index-C5ThNCN-.js";
import { R as C } from "./RoundCard-CZ-rEJ_D.js";
import { S as M, P as R } from "./PredictionPanel-BwmEfDz4.js";
import { D as k } from "./DashboardLayout-XCzqIJrp.js";
import "./analysis-data-BaiXRb_2.js";
import "./triangle-alert-CzDFXfJ_.js";
import "./database-80brKRBJ.js";
import "./trending-up-B5K2KKMW.js";
import "./activity-D198U5P3.js";
import "./god-character.png.asset-BWFGzeh1.js";
import "./history-DU1SVBVB.js";
import "./wrench-DMPf9Lxe.js";
const I = y({ method: "GET" }).handler(
    S("61b62dc32e074bfb7faf2567a554664ee07eba12e0d1b0a572da9574efc9ea9a"),
  ),
  x = 20,
  L = 1e3,
  P = 12e3,
  N = "dragonscrash_rounds";
function _(a, d) {
  return a.some(
    (r) =>
      r.coefficient === d.coefficient &&
      Math.abs(r.timestamp - d.timestamp) < P,
  );
}
function T() {
  const [a, d] = n.useState([]),
    [r, o] = n.useState("connecting"),
    [p, i] = n.useState(null),
    [f, m] = n.useState(!1),
    [g, w] = n.useState(null),
    h = n.useRef(new Set()),
    j = D(I);
  return (
    n.useEffect(() => {
      let c = !1;
      return (
        (async () => {
          const { data: l } = await b
            .from(N)
            .select("id,coefficient,color,played_at")
            .order("played_at", { ascending: !1 })
            .limit(x * 2);
          if (c || !l) return;
          const t = [];
          for (const s of l) {
            const u = {
              id: s.id,
              coefficient: Number(s.coefficient),
              color: v(Number(s.coefficient)),
              timestamp: new Date(s.played_at).getTime(),
            };
            if (!_(t, u) && (t.push(u), t.length >= x)) break;
          }
          (t.forEach((s) => h.current.add(s.id)), d(t));
        })(),
        () => {
          c = !0;
        }
      );
    }, []),
    n.useEffect(() => {
      const c = b
        .channel(
          `dragonscrash_rounds_rt_${Math.random().toString(36).slice(2)}`,
        )
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: N },
          (l) => {
            const t = l.new;
            if (h.current.has(t.id)) return;
            h.current.add(t.id);
            const s = {
              id: t.id,
              coefficient: Number(t.coefficient),
              color: v(Number(t.coefficient)),
              timestamp: new Date(t.played_at).getTime(),
            };
            d((u) => (_(u, s) ? u : (w(s.id), [s, ...u].slice(0, x))));
          },
        )
        .subscribe();
      return () => {
        b.removeChannel(c);
      };
    }, []),
    n.useEffect(() => {
      let c = !1,
        l;
      const t = async () => {
        try {
          const s = await j();
          if (c) return;
          s?.ok
            ? (o("live"), i(null), m(!!s.waiting))
            : (o("error"), i(s?.error ?? "unknown"));
        } catch (s) {
          c || (o("error"), i(s.message));
        } finally {
          c || (l = setTimeout(t, L));
        }
      };
      return (
        t(),
        () => {
          ((c = !0), l && clearTimeout(l));
        }
      );
    }, [j]),
    { rounds: a, status: r, waiting: f, newestId: g, errorMsg: p, max: x }
  );
}
function X() {
  const [a, d] = n.useState(!1);
  n.useEffect(() => {
    (localStorage.setItem("lj_current_game", "dragonscrash"), d(!0));
  }, []);
  const { rounds: r, status: o, newestId: p, errorMsg: i } = T(),
    f = !!(
      i?.includes("ws_connect_failed") ||
      i?.includes("no_websocket_status") ||
      i?.includes("missing_credentials")
    );
  return e.jsxs(k, {
    children: [
      e.jsxs("div", {
        className:
          "glass rounded-2xl px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between flex-wrap gap-3 relative overflow-hidden",
        children: [
          e.jsx("div", {
            className:
              "absolute inset-0 bg-gradient-to-r from-red-600/10 via-transparent to-emerald-500/10 pointer-events-none",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-3 min-w-0 relative",
            children: [
              e.jsx("img", {
                src: E,
                alt: "Dragon's Crash",
                className:
                  "shrink-0 w-11 h-11 rounded-xl object-cover shadow-[0_0_20px_rgba(16,185,129,0.4)]",
              }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2 flex-wrap",
                    children: [
                      e.jsx("h1", {
                        className:
                          "font-display font-black text-xl sm:text-2xl lg:text-3xl tracking-tight bg-gradient-to-r from-emerald-400 via-[var(--neon-green)] to-red-500 bg-clip-text text-transparent",
                        children: "Dragon's Crash",
                      }),
                      e.jsx("span", {
                        className:
                          "text-muted-foreground font-light text-lg sm:text-xl",
                        children: "×",
                      }),
                      e.jsx("div", {
                        className:
                          "inline-flex items-center px-2.5 py-1 rounded-lg bg-gradient-to-br from-red-600 to-red-800 shadow-[0_0_18px_rgba(220,38,38,0.5)] border border-red-400/30",
                        children: e.jsx("img", {
                          src: "/__l5e/assets-v1/82f6e81d-ae8c-475c-a3da-bbe18750b285/betclic-logo-new.png",
                          alt: "Betclic",
                          className: "h-5 sm:h-6 w-auto object-contain",
                        }),
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    children: "Historique des 20 derniers tours en temps réel",
                  }),
                ],
              }),
            ],
          }),
          a &&
            e.jsxs("div", {
              className: "flex items-center gap-2 text-xs font-mono",
              children: [
                e.jsx("span", {
                  className: `w-2 h-2 rounded-full animate-pulse ${o === "live" ? "bg-[var(--neon-green)]" : o === "error" ? "bg-[var(--neon-orange)]" : "bg-[var(--neon-blue)]"}`,
                }),
                e.jsx("span", {
                  className: "text-muted-foreground",
                  children:
                    o === "live"
                      ? "LIVE"
                      : o === "error"
                        ? f
                          ? "Flux Betclic refusé"
                          : `Erreur API${i ? ` : ${i}` : ""}`
                        : "Connexion…",
                }),
              ],
            }),
        ],
      }),
      a &&
        o === "error" &&
        f &&
        e.jsxs("div", {
          className:
            "glass rounded-2xl border border-[var(--neon-orange)]/30 px-4 py-3 text-xs sm:text-sm text-muted-foreground",
          children: [
            e.jsx("span", {
              className: "font-display font-bold text-[var(--neon-orange)]",
              children: "Dragon's Crash :",
            }),
            " ",
            "Le jeton de session Betclic est expiré ou refusé. Le direct reprend dès qu'un jeton valide est enregistré dans l'administration.",
          ],
        }),
      a && r.length > 0 && e.jsx(M, { rounds: r }),
      a &&
        r.length > 0 &&
        e.jsx(R, { rounds: r, table: "dragonscrash_rounds" }),
      e.jsxs("main", {
        className: "glass rounded-3xl p-4 sm:p-6 lg:p-8",
        children: [
          e.jsx("div", {
            className: "flex items-end justify-between flex-wrap gap-2 mb-5",
            children: e.jsxs("div", {
              children: [
                e.jsx("h2", {
                  className:
                    "font-display font-bold text-xl sm:text-2xl tracking-tight",
                  children: "20 derniers tours",
                }),
                e.jsx("p", {
                  className: "text-xs sm:text-sm text-muted-foreground mt-1",
                  children:
                    "Mise à jour en temps réel depuis le flux officiel Dragon's Crash",
                }),
              ],
            }),
          }),
          a && r.length === 0
            ? e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: Array.from({ length: 20 }).map((m, g) =>
                  e.jsx(
                    "div",
                    {
                      className:
                        "rounded-2xl h-[56px] sm:h-[64px] glass animate-pulse",
                      style: { animationDelay: `${g * 50}ms` },
                    },
                    g,
                  ),
                ),
              })
            : e.jsx("div", {
                className:
                  "grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-1.5 sm:gap-2",
                children: r.map((m) =>
                  e.jsx(C, { round: m, isNew: m.id === p }, m.id),
                ),
              }),
        ],
      }),
    ],
  });
}
export { X as component };
