import { d as e, e as a } from "./index-C5ThNCN-.js";
const c = e({ method: "POST" }).handler(
    a("270dc4727e48f90e8eb0d89dbfd1ebbb3af64d6d1c5678db5147b24b99f1cca4"),
  ),
  b = e({ method: "POST" }).handler(
    a("7db5d1d6bd74a1b4bb9c492b857d94f3d6e593ef88ac20ffa6688e5a1ea4aaf1"),
  );
export { b as a, c };
