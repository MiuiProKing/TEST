const s="/assets/game-luckyjet-CRaaNqCV.jpg",t="/assets/game-jetx-DKXuFbyt.jpg";export{t as j,s as l};
