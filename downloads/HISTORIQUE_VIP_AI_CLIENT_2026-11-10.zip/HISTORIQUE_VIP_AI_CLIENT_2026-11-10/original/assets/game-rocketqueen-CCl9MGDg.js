const e="/assets/game-rocketqueen-DgsPCcOa.jpg";export{e as r};
