const _="lj_admin_token";export{_ as A};
