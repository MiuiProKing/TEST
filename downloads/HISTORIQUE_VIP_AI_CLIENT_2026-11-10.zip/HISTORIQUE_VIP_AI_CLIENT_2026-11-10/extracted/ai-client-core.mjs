// Source-extracted public AI CLIENT helpers, not an AI model.
// Helper bodies and category/style expressions are copied from the public modules.
// Only public export aliases/constants are added; no request transport or model is implemented.
function m(s, i = 300, e = 1 / 0) {
  const n = new Set();
  return [...s]
    .sort((t, a) => a.timestamp - t.timestamp)
    .filter((t) =>
      !Number.isFinite(t.coefficient) ||
      t.coefficient < 1 ||
      !Number.isFinite(t.timestamp) ||
      t.timestamp <= 0 ||
      t.timestamp > e ||
      (t.id && n.has(t.id))
        ? !1
        : (t.id && n.add(t.id), !0),
    )
    .slice(0, i);
}
function f(s, i = Date.now()) {
  const e = s[0]?.timestamp;
  return e !== void 0 && e <= i + 3e4 && i - e <= 18e4;
}

const k = 45e3,
  M = (t) =>
    t === "low"
      ? "Faible (<2x)"
      : t === "mid"
        ? "Moyen (2-10x)"
        : t === "high"
          ? "Élevé (10-100x)"
          : "Mega (≥100x)",
  L = (t) =>
    t === "low"
      ? "from-slate-500/20 to-slate-700/20 border-slate-500/30"
      : t === "mid"
        ? "from-blue-500/20 to-cyan-500/20 border-blue-500/30"
        : t === "high"
          ? "from-orange-500/20 to-red-500/20 border-orange-500/30"
          : "from-fuchsia-500/30 to-purple-600/30 border-fuchsia-500/40";

export const AI_SERVER_FUNCTION = 'ddbd425daedaba6871a9a8a60c6c943415250e22750ffa1255ea8a5406ee7d49';
export const AI_REQUEST_METHOD = 'POST';
export const AI_MIN_ROUNDS = 20;
export const AI_MAX_ROUNDS = 200;

export { m as normalizeAiRounds, f as aiRoundsAreFresh, k as AI_POLL_MS,
  M as aiCategoryLabel, L as aiCategoryStyle };
